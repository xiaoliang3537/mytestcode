#include "stdafx.h"
#include "ServiceSocket.h"
#include "DataSocket.h"
#include <winsock2.h>
#include <Windows.h>
#include <iostream>
#include "loger.h"
#include "Public.h"
#pragma comment(lib,"ws2_32.lib")
using std::cout;
using std::cin;
using std::endl;
using std::ends;

#define BUFFERSIZE 4096

CDataScoket::CDataScoket()
{
    m_bLoggedon = FALSE;
    m_bRenameFile = FALSE;
    m_pDataSocket = NULL;
    m_strRemoteHost = "";
    m_nRemotePort = -1;
    m_dwRestartOffset = 0;
    m_bPassiveMode = FALSE;
}

CDataScoket::~CDataScoket()
{
    //DestroyDataConnection();
    TRACE0("CConnectSocket destroyed.\n");
    ::closesocket(m_socket);
}

void CDataScoket::OnClose(int nErrorCode)
{
    //Close();
    // destroy connection
    //m_pThread->PostThreadMessage(WM_THREADMSG, 1, 0);
    TRACE("CConnectSocketEx() OnClose()\n");

    //CSocket::OnClose(nErrorCode);
}

void CDataScoket::Close()
{
    ::closesocket(m_socket);
}

/********************************************************************/
/*																	*/
/* Function name : OnReceive										*/
/* Description   : Called by the framework to notify this socket	*/
/*                 that there is data in the buffer.				*/
/*																	*/
/********************************************************************/
void CDataScoket::OnReceive(int nErrorCode)
{
    char buff[BUFFERSIZE];

    int nRead = recv(m_socket, buff, BUFFERSIZE, 0);
    switch (nRead)
    {
    case 0:
        Close();
        break;

    case SOCKET_ERROR:
        if (GetLastError() != WSAEWOULDBLOCK)
        {
            TCHAR szError[256];
            wsprintf(szError, _T("OnReceive error: %d"), GetLastError());

            AfxMessageBox(szError);
        }
        break;

    default:
        if (nRead != SOCKET_ERROR && nRead != 0)
        {
            if (nRead > 0)
            {
                buff[0] == '!';
                // �����ն˿ͻ�����Ϣ
            }
            //else
            //{
            //    //buff[nRead] = 0;
            //    //m_RxBuffer += CString(buff);
            //    // �������Ϣ
            //    GetRxLine();
            //}
        }
        break;
    }
}


BOOL CDataScoket::GetRxCommand(CString &strCommand, CString &strArguments)
{
    if (!m_strCommands.IsEmpty())
    {
        CString strBuff = m_strCommands.RemoveHead();
        int nIndex = strBuff.Find(_T(" "));
        if (nIndex != -1)
        {
            CString strPassword = strBuff;
            strPassword.MakeUpper();
            // make password invisible
            if (strPassword.Left(5) == "PASS ")
            {
                for (int i = 5; i < strPassword.GetLength(); i++)
                {
                    strPassword.SetAt(i, '*');
                }
                FireStatusMessage(strPassword, 1);
            }
            else
            {
                FireStatusMessage(strBuff, 1);
            }
            strCommand = strBuff.Left(nIndex);
            strArguments = strBuff.Mid(nIndex + 1);
        }
        else
        {
            FireStatusMessage(strBuff, 1);
            strCommand = strBuff;
        }

        if (strCommand != "")
        {
            strCommand.MakeUpper();

            // who screwed up ???
            if (strCommand.Right(4) == "ABOR")
            {
                strCommand = "ABOR";
            }

            TRACE2("COMMAND: %s, ARGS: %s\n", strCommand, strArguments);
            return TRUE;
        }
    }
    return FALSE;
}

void CDataScoket::GetRxLine()
{
    CString strTemp;
    int nIndex;

    while (!m_RxBuffer.IsEmpty())
    {
        nIndex = m_RxBuffer.Find(_T("\r\n"));
        if (nIndex != -1)
        {
            strTemp = m_RxBuffer.Left(nIndex);
            m_RxBuffer = m_RxBuffer.Mid(nIndex + 2);
            if (!strTemp.IsEmpty())
            {
                m_strCommands.AddTail(strTemp);
                ParseCommand();
            }
        }
        else
            break;
    }
}

void CDataScoket::OnConnect(int nErrorCode)
{
    //CSocket::OnConnect(nErrorCode);
}

BOOL CDataScoket::HasConnectionDropped(void)
{
    BOOL bConnDropped = FALSE;
    /*INT iRet = 0;
    BOOL bOK = TRUE;

    if (m_hSocket == INVALID_SOCKET)
    return TRUE;

    struct timeval timeout = { 0, 0 };
    fd_set readSocketSet;

    FD_ZERO(&readSocketSet);
    FD_SET(m_hSocket, &readSocketSet);

    iRet = ::select(0, &readSocketSet, NULL, NULL, &timeout);
    bOK = (iRet > 0);

    if(bOK)
    {
    bOK = FD_ISSET(m_hSocket, &readSocketSet);
    }

    if(bOK)
    {
    CHAR szBuffer[1] = "";
    iRet = ::recv(m_hSocket, szBuffer, 1, MSG_PEEK);
    bOK = (iRet > 0);
    if(!bOK)
    {
    INT iError = ::WSAGetLastError();
    bConnDropped = (( iError == WSAENETRESET) ||
    (iError == WSAECONNABORTED) ||
    (iError == WSAECONNRESET) ||
    (iError == WSAEINVAL) ||
    (iRet == 0));
    }
    }*/
    return(bConnDropped);
}


void CDataScoket::Attach(SOCKET sock)
{
    this->m_socket = sock;
    m_scoketEvent = ::WSACreateEvent();
    ::WSAEventSelect(sock, m_scoketEvent, FD_READ | FD_CLOSE | FD_WRITE);
    HANDLE thread = ::CreateThread(0, 0, RecvThreadProc, (void *)this, 0, 0);

}

DWORD WINAPI CDataScoket::RecvThreadProc(LPVOID lpParam)
{
    if (lpParam == NULL)
        return 0;
    CDataScoket *client = (CDataScoket *)lpParam;
    DWORD ret = 0;
    int index = 0;
    int nEvent = 0;

    HANDLE events[2];
    events[0] = client->m_scoketEvent;
    nEvent++;

    while (true)
    {
        int nIndex = ::WSAWaitForMultipleEvents(nEvent, events, false, WSA_INFINITE, false);
        if (nIndex == WSA_WAIT_IO_COMPLETION || nIndex == WSA_WAIT_TIMEOUT)
        {
            LOG(ERROR) << "wait error ! error code :" << WSAGetLastError() << endl;
            break;
        }
        nIndex = nIndex - WSA_WAIT_EVENT_0;
        WSANETWORKEVENTS event;
        SOCKET sock = client->m_socket;

        ::WSAEnumNetworkEvents(sock, events[nIndex], &event);
        if (event.lNetworkEvents & FD_READ)
        {
            if (event.iErrorCode[FD_READ_BIT] == 0)
            {
                client->OnReceive(1);
            }
        }
        if (event.lNetworkEvents & FD_CLOSE)
        {
            if (event.iErrorCode[FD_CLOSE_BIT] == 0)
            {
                LOG(INFO) << "A Client has disconnect" << endl;
                client->Close();
                delete client;
            }
        }
    }
    return 0;
}

BOOL CDataScoket::SendResponse(LPCTSTR pstrFormat, ...)
{
    if (m_socket == INVALID_SOCKET)
    {
        LOG(ERROR) << "current socket invalid" << endl;
        return FALSE;
    }
    CString str;

    // format arguments and put them in CString
    va_list args;
    va_start(args, pstrFormat);
    str.FormatV(pstrFormat, args);

    // is connection still active ?
    if (HasConnectionDropped())
    {
        //Close();
        // tell our thread we have been closed
        // destroy connection
        //m_pThread->PostThreadMessage(WM_THREADMSG, 1, 0);
        return FALSE;
    }
    std::string strInfo = CPublic::TCharToString(str);
    int nBytes = send(this->m_socket, strInfo.c_str(), strInfo.length() , 0);
    if (nBytes == SOCKET_ERROR)
    {
        //Close();
        // tell our thread we have been closed
        //m_pThread->PostThreadMessage(WM_THREADMSG, 1, 0);
        LOG(ERROR) << "send to client failed,code:" << GetLastError() << endl;
        return FALSE;
    }

    FireStatusMessage(str, 2);

    //((CConnectThread *)AfxGetThread())->IncSentBytes(nBytes);
    return TRUE;
}

void CDataScoket::ParseCommand()
{

}


void CDataScoket::FireStatusMessage(LPCTSTR lpszStatus, int nType)
{
    //CConnectThread *pThread = (CConnectThread *)m_pThread;
    //((CFTPServer *)pThread->m_pWndServer)->AddTraceLine(nType, "[%d] %s", m_pThread->m_nThreadID, lpszStatus);
}



//ͨ���׽��ֻ�ȡIP��Port�ȵ�ַ��Ϣ
bool CDataScoket::GetPeerName(CString &strPeerAddress, UINT &nPeerPort)
{
    SOCKADDR_IN address;
    memset(&address, 0, sizeof(address));
    int nAddrLen = sizeof(address);

    //�����׽��ֻ�ȡ��ַ��Ϣ
    if (::getpeername(m_socket, (SOCKADDR*)&address, &nAddrLen) != 0)
    {
        printf("Get IP address by socket failed!n");
        return false;
    }
    //��ȡIP��Port
    strPeerAddress.Format(_T("%s"), ::inet_ntoa(address.sin_addr));
    nPeerPort = ntohs(address.sin_port);

    return true;
}

