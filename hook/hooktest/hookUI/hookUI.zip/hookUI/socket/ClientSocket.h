#pragma once

#include <afxwin.h>
#include <afxsock.h>
#include "thread/Thread.h"

// �������ݽ���
class CClientSocket : public Thread
{
public:
    int m_nRemotePort;
    CString m_strRemoteHost;
    SOCKET m_socket;
    WSAEVENT m_scoketEvent;
public:
    int connectServer(CString strIP, int port);
    int sendToServer(CString &str);
    int close();
    virtual void execute();
public:
    CClientSocket(HWND h );
    virtual ~CClientSocket();

protected:
    bool m_bClose;
    HWND m_hwnd;                // �����ھ��
};


