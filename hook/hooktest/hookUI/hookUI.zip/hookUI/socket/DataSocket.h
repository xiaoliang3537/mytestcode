#pragma once

#include <afxwin.h>
#include <afxsock.h>

class CDataSocketEx;

// �������ݽ���
class CDataScoket
{
public:
    int m_bPassiveMode;
    int m_nRemotePort;
    CString m_strRemoteHost;
    CDataSocketEx *m_pDataSocket;
    SOCKET m_socket;
    WSAEVENT m_scoketEvent;

    // Attributes
public:
    void Attach(SOCKET sock);
    BOOL HasConnectionDropped(void);
    BOOL SendResponse(LPCTSTR pstrFormat, ...);
    void FireStatusMessage(LPCTSTR lpszStatus, int nType);
    BOOL GetRxCommand(CString &command, CString &args);
    BOOL CreateDataConnection(int nTransferType, LPCTSTR lpszData);
    void DestroyDataConnection();
    void Close() ;
    static DWORD WINAPI RecvThreadProc(LPVOID lpParam);
    bool GetPeerName(CString &strPeerAddress, UINT &nPeerPort);
    // Operations
public:
    CDataScoket();
    virtual ~CDataScoket();

    void ParseCommand();

    // Overrides
public:
    CWinThread* m_pThread;

    BOOL m_bLoggedon;
    CString m_strUserName;
public:
    virtual void OnClose(int nErrorCode);
    virtual void OnReceive(int nErrorCode);
    virtual void OnConnect(int nErrorCode);

protected:
    CStringList m_strCommands;
    void GetRxLine();
    BOOL m_bRenameFile;
    DWORD m_dwRestartOffset;
    CString m_strRenameFile;
    CString m_RxBuffer;
    CString m_strCurrentDir;

};


