#pragma once

class CDataScoket;
// ����win32���첽socket
class CServiceSocket
{
public:
    CDataScoket* m_dataSocket;
public:
    CServiceSocket();
    ~CServiceSocket();

    int startListen();
    int sendMsg(CString szInfo);

public:
    static DWORD WINAPI RecvThreadProc(LPVOID lpParam);
    static void OnAccept();

protected:
    SOCKET m_socket;
    WSAEVENT m_socketEvent;
    HANDLE m_stopEvent;
    HANDLE m_thread;
};
