#include "stdafx.h"
#include "ClientSocket.h"
#include "DataSocket.h"
#include <winsock2.h>
#include <Windows.h>
#include <iostream>
#include "loger.h"
#include "Public.h"
#pragma comment(lib,"ws2_32.lib")
using std::cout;
using std::cin;
using std::endl;
using std::ends;

#define BUFFERSIZE 4096

CClientSocket::CClientSocket(HWND h)
    : m_hwnd(h)
{
    m_bClose = false;
}

CClientSocket::~CClientSocket()
{
}

int CClientSocket::connectServer(CString strIP, int port)
{
    m_socket = socket(AF_INET, SOCK_STREAM, 0);
    SOCKADDR_IN addrSrv;
    addrSrv.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");
    addrSrv.sin_family = AF_INET;
    addrSrv.sin_port = htons(6900);
    int iRet = connect(m_socket, (SOCKADDR*)&addrSrv, sizeof(SOCKADDR));
    if (iRet != 0 )
    {
        LOG(ERROR) << "error in connect to 127.0.0.1: code =" << GetLastError() << endl;
        return iRet;
    }
}

int CClientSocket::sendToServer(CString &str)
{
    char buff[4096] = { 0 };
    int iRet = send(m_socket, "1234567890", 10, 0);
    return iRet;
}

int CClientSocket::close()
{
    m_bClose = true;
    this->wait();
    return 0;
}

void CClientSocket::execute()
{
    TIMEVAL time = { 5,0 };
    char buf[4096];

    while (true)
    {
        if (m_bClose)
        {
            break;
        }
        fd_set socketSet;
        FD_ZERO(&socketSet);
        FD_SET(m_socket, &socketSet);

        int index = select(0, &socketSet, NULL, NULL, &time);
        if ( index > 0 )
        {
            memset(buf, 0x0, sizeof(4096));
            int iRet = recv(m_socket, buf, 4096, 0);
            LOG(INFO) << "recv info:" << buf << endl;
            if (iRet <= 0)
            {
                continue;
            }
            if (NULL != m_hwnd)
            {
                if (buf[0] == '1' )
                {
                    char *szInfo = new char[iRet + 1];
                    memcpy(szInfo, buf, iRet);
                    szInfo[iRet] = '\0';
                    PostMessage(m_hwnd, WM_USER_FTP_INFO_DONE, (WPARAM)szInfo, iRet);
                    LOG(INFO) << "post message:" << szInfo << endl;
                }
            }
            printf(buf);
        }

    }
}
