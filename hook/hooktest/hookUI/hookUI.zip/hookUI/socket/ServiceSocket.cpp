#include "stdafx.h"
#include "ServiceSocket.h"
#include "DataSocket.h"
#include "loger.h"
#include <winsock2.h>
#include <Windows.h>
#include <iostream>
#pragma comment(lib,"ws2_32.lib")
using std::cout;
using std::cin;
using std::endl;
using std::ends;

CServiceSocket::CServiceSocket()
{
    m_dataSocket = NULL;
}

CServiceSocket::~CServiceSocket()
{
    ::closesocket(m_dataSocket->m_socket);
}

int CServiceSocket::sendMsg(CString szInfo)
{
    if (NULL != m_dataSocket)
    {
        return m_dataSocket->SendResponse(szInfo);
    }
    else
        return -1;
}

int CServiceSocket::startListen()
{
    m_socket = ::socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (m_socket == INVALID_SOCKET) {
        LOG(ERROR) << "create socket error��,code =" << WSAGetLastError() << endl;
        return -1;
    }

    int error = 0;
    sockaddr_in addr_in;
    addr_in.sin_family = AF_INET;
    addr_in.sin_port = htons(6900);
    addr_in.sin_addr.s_addr = INADDR_ANY;
    error = ::bind(m_socket, (sockaddr*)&addr_in, sizeof(sockaddr_in));
    if (error == SOCKET_ERROR) {
        LOG(ERROR) << "bind port error��code =" << WSAGetLastError() << endl;
        return -1;
    }

    error = listen(m_socket, 5);
    if (error == SOCKET_ERROR) {
        LOG(ERROR) << "listen port error ��,code = " << WSAGetLastError() << endl;
        return -1;
    }
    LOG(INFO) << "listen port succ :" << ntohs(addr_in.sin_port) << endl;


    m_socketEvent = ::WSACreateEvent();
    ::WSAEventSelect(m_socket, m_socketEvent, FD_ACCEPT | FD_CLOSE);

    HANDLE thread = ::CreateThread(0, 0, RecvThreadProc, (void *)this, 0, 0);
    return 0;
}

DWORD WINAPI CServiceSocket::RecvThreadProc(LPVOID lpParam)
{
    if (lpParam == NULL)
        return 0;
    CServiceSocket *client = (CServiceSocket *)lpParam;
    WSAEVENT eventArray[WSA_MAXIMUM_WAIT_EVENTS];                   // �¼���������
    SOCKET sockArray[WSA_MAXIMUM_WAIT_EVENTS];                      // �¼����������Ӧ��SOCKET���
    DWORD ret = 0;
    int index = 0;
    int nEvent = 0;

    HANDLE events[2];
    events[0] = client->m_socketEvent;
    events[1] = client->m_stopEvent;
    sockArray[0] = client->m_socket;

    nEvent++;
    while (true) {
        int nIndex = ::WSAWaitForMultipleEvents(nEvent, events, false, WSA_INFINITE, false);
        if (nIndex == WSA_WAIT_IO_COMPLETION || nIndex == WSA_WAIT_TIMEOUT) 
        {
            LOG(ERROR) << "wait error ! error code :" << WSAGetLastError() << endl;
            break;
        }
        nIndex = nIndex - WSA_WAIT_EVENT_0;
        WSANETWORKEVENTS event;
        SOCKET sock = client->m_socket;

        ::WSAEnumNetworkEvents(sock, events[nIndex], &event);
        if (event.lNetworkEvents & FD_ACCEPT) 
        {
            if (event.iErrorCode[FD_ACCEPT_BIT] == 0) 
            {
                if (nEvent >= WSA_MAXIMUM_WAIT_EVENTS) 
                {
                    LOG(ERROR) << "client count out of range!" << endl;
                    continue;
                }
                sockaddr_in addr;
                int len = sizeof(sockaddr_in);
                SOCKET socketClient = ::accept(sock, (sockaddr*)&addr, &len);
                if (socketClient != INVALID_SOCKET)
                {
                    LOG(ERROR) << "New come from " << inet_ntoa(addr.sin_addr) << ":" << ntohs(addr.sin_port) << endl;
                    //Ϊ�����ӵ�socket�����¼�
                    //WSAEVENT e = WSACreateEvent();
                    //WSAEventSelect(client, e, FD_READ | FD_WRITE | FD_CLOSE);
                    //eventArray[nEvent] = e;
                    //sockArray[nEvent] = client;
                    //nEvent++;
                    CDataScoket* data = new CDataScoket();
                    client->m_dataSocket = data;
                    data->Attach(socketClient);
                }
            }
        }
        else if (event.lNetworkEvents & FD_CLOSE) 
        {
            ::WSACloseEvent(eventArray[nIndex]);
            ::closesocket(sockArray[nIndex]);
            LOG(INFO) << "A Client has disconnect" << endl;
            for (int j = nIndex; j < nEvent - 1; j++) 
            {
                eventArray[j] = eventArray[j + 1];
                sockArray[j] = sockArray[j + 1];
            }
            nEvent--;
        }
        /*else if (event.lNetworkEvents & FD_READ)
        {
            if (event.iErrorCode[FD_READ_BIT] == 0)
            {
                char buf[4096];
                int res = recv(sockArray[nIndex], buf, 4096, 0);
                if (res == 0)
                {
                    closesocket(sockArray[nIndex]);
                    break;
                }
                buf[res] = 0;
                cout << buf << endl;
            }
        }
        else if (event.lNetworkEvents & FD_WRITE)
        {
            if (event.iErrorCode[FD_WRITE_BIT] == 0)
            {
                std::string str = "send data from service";
                int sz = send(sockArray[nIndex], str.c_str(), str.length(), 0);
                if (sz == SOCKET_ERROR)
                {
                    if (WSAGetLastError() == WSAEWOULDBLOCK)
                    {
                        continue;
                    }
                }
            }
        }*/
} 
    ::closesocket(client->m_socket);
}

void CServiceSocket::OnAccept()
{

}

