//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ ���ɵİ����ļ���
// �� hookUI.rc ʹ��
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_HOOKUI_DIALOG               102
#define IDD_MYTESTDIALOG                103
#define IDR_MAINFRAME                   128
#define IDB_PNG1                        129
#define IDB_BITMAP1                     131
#define IDR_MENU1                       132
#define IDC_BUTTON_HOOK_ALL             1000
#define IDC_BUTTON_INJECT               1000
#define IDC_BUTTON_HOOK_SINGLE          1001
#define IDC_BUTTON_INIT                 1001
#define IDC_BUTTON_HOOK_OFF             1002
#define IDC_BUTTON_TEST                 1003
#define IDC_EDIT_NAME                   1004
#define IDC_EDIT_TEXT                   1005
#define IDC_BUTTON_T_B                  1006
#define IDC_IMAGE                       1007
#define IDC_STARTCLIENT                 1008
#define IDC_CLIENTSEND                  1009
#define IDC_STARTSERVER                 1010
#define IDC_SERVERSEND                  1013
#define IDC_DIALOG_SHOW                 1090
#define ID_11_22                        32771
#define ID_11_33                        32772
#define ID_11_44                        32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
