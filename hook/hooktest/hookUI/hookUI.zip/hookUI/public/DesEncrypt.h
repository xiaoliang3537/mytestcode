#pragma once
#include <openssl/des.h>
#include "../MD5Checksum.h"
#include "../MngServices/Service.h"
#pragma comment (lib ,"./openssl/libs/libeay32.lib")

void  encryptDes3(char * pKey /* must >= 24 */, char * pData /*�ռ���Ҫ��ʵ�����ݴ�8�ֽ�*/  , int &ilength)
{
	unsigned char intext[8], outtext[8];

	DES_key_schedule keyschedc1;
	DES_key_schedule keyschedc2;
	DES_key_schedule keyschedc3;
	DES_cblock keyc1;
	DES_cblock keyc2;
	DES_cblock keyc3;

	unsigned char block_key[9] = {0};
	memcpy(block_key,pKey,8);
	DES_set_key((DES_cblock *)block_key, &keyschedc1);
	memcpy(block_key,pKey + 8,8);
	DES_set_key((DES_cblock *)block_key, &keyschedc2);
	memcpy(block_key,pKey + 16,8);
	DES_set_key((DES_cblock *)block_key, &keyschedc3); 

	int iCount = 0 , iRest = 0 ;
	unsigned char ch; 
	iRest = ilength %8;
	/*
	** ��������8λ���룬���뷽ʽΪ����1λ��һ��0x01,��2λ������0x02,... 
	��Ӧjava�����  ECB ����ģʽ�� PKCS#5 ��䷽ʽ begin
	*/
	ch = 8 - iRest;
	memset(pData + ilength, ch, 8 - iRest);
	ilength += 8 - iRest;
	/**********************end************************************/

	iCount = ilength /8;
	
	for (int i=0; i < iCount; i ++)
	{
		memcpy(intext,pData + i*8,8);
		DES_ecb3_encrypt((DES_cblock *)intext,
			(DES_cblock *)outtext, 
			&keyschedc1, &keyschedc2, 
			&keyschedc3,DES_ENCRYPT);
		memcpy(pData + i*8 , outtext , 8);
	}
}

void  dencryptDes3(char * pKey /* must >= 24 */, char * pData, int &ilength)
{
	unsigned char intext[8], outtext[8];

	DES_key_schedule keyschedc1;
	DES_key_schedule keyschedc2;
	DES_key_schedule keyschedc3;
	DES_cblock keyc1;
	DES_cblock keyc2;
	DES_cblock keyc3;

	unsigned char block_key[9] = {0};
	memcpy(block_key,pKey,8);
	DES_set_key((DES_cblock *)block_key, &keyschedc1);
	memcpy(block_key,pKey + 8,8);
	DES_set_key((DES_cblock *)block_key, &keyschedc2);
	memcpy(block_key,pKey + 16,8);
	DES_set_key((DES_cblock *)block_key, &keyschedc3); 

	int iCount = 0 , iRest = 0 ;
	

	iCount = ilength /8;
	
	for (int i=0; i < iCount; i ++)
	{
		memcpy(intext,pData + i*8,8);
		DES_ecb3_encrypt((DES_cblock *)intext,
			(DES_cblock *)outtext, 
			&keyschedc1, &keyschedc2, 
			&keyschedc3,DES_DECRYPT);
		memcpy(pData + i*8 , outtext , 8);
	}

	/************************************************************************/
	/* ȥ������ʱ�������ӵ����� 
	/************************************************************************/
	iRest = *(pData+ilength-1);
	ilength -= iRest;
	pData[ilength] = 0;

}

void getKey(char * szBuf)
{
	int ilen = strlen(szBuf);
	for (int i = 0; i< ilen; i++)
	{
		szBuf[i] ^= szBuf[ilen - 1 - i];
	}
}
void encMapInDes(char *str/*�ռ���Ҫ��ʵ�����ݴ�8�ֽ�*/, int &length/*��ʵ���ݳ���*/)
{
	char szBuf[200] = {0};
	char * pszAnsi = NULL;
	CService::UnicodeToAnsi(g_sUserName.GetBuffer(),pszAnsi);
	if(!pszAnsi)
	{
		return ;
	}
	string sMD5 = CMD5Checksum::GetMD5OfString(pszAnsi,strlen(pszAnsi));
	delete [] pszAnsi;
	pszAnsi = NULL;

	memset(szBuf,0,200);
	strcpy(szBuf,sMD5.c_str()); 
	getKey(szBuf);
	char * pszKey = szBuf;
	pszKey += 3; //�ӵ���λ��ʼȡkeyֵ
	encryptDes3(pszKey,str,length);
}

void dencMapInDes(char * str,int &ilength)
{
	char szBuf[200] = {0};
	char * pszAnsi = NULL;
	CService::UnicodeToAnsi(g_sUserName.GetBuffer(),pszAnsi);
	if(!pszAnsi)
	{
		return ;
	}
	string sMD5 = CMD5Checksum::GetMD5OfString(pszAnsi,strlen(pszAnsi));
	delete [] pszAnsi;
	pszAnsi = NULL;

	memset(szBuf,0,200);
	strcpy(szBuf,sMD5.c_str()); 
	getKey(szBuf);
	char * pszKey = szBuf;
	pszKey += 3; //�ӵ���λ��ʼȡkeyֵ
	dencryptDes3(pszKey,str,ilength);

}