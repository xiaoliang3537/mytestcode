#pragma once

#include <stdio.h>
#include <string>
#include <Gdiplus.h>
#include <atlimage.h>
#include <GdiPlusGpStubs.h>
#include <GdiPlusGraphics.h>
#include <cstring>

using namespace std;

// ������������ݹ���
struct _ST_AccessInfo
{
    CString strName;
    CString strValue;
    CPoint point;
    VARIANT variant;
};

// ftp ������Ϣ�ṹ
typedef struct ST_FTP_INFO
{
    ST_FTP_INFO()
    {
        memset(szUserName, 0x0, MAX_PATH);
        memset(szUserName, 0x0, MAX_PATH);
        memset(szUserName, 0x0, MAX_PATH);
    }
    char szUserName[MAX_PATH];
    char szPassword[MAX_PATH];
    char szPath[MAX_PATH];
};

class CPublic
{
public:
    CPublic(void);
    ~CPublic(void);

public:
    // ���ع���·��
    static std::string getWorkPath();
    
    static std::string TCharToString(CString &strInfo);
    static CString stringToTChar(string &strInfo);
    static CString stringToTChar(char* szInfo);
    // �� image ת����������
    static int fillBuff(CImage &image, BYTE* pByte);
    //static int fillBuff(GpImage &img, BYTE* pByte);

    static int hostToIp(char* szHost, char* szIp);

    // ��ȡ��ǰʱ��
    static std::string getCurrTime()
    {
        SYSTEMTIME sy;
        memset(&sy,0,sizeof(sy));
        GetLocalTime(&sy);
        char szData[64] = {0};
        sprintf(szData, "%04d-%02d-%02d %02d:%02d:%02d",
            sy.wYear,sy.wMonth,sy.wDay,sy.wHour,sy.wMinute,sy.wSecond);
        return szData;
    }
};


