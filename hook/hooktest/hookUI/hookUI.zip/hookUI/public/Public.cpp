#include "StdAfx.h"
#include "Public.h"

CPublic::CPublic(void)
{
}

CPublic::~CPublic(void)
{
}


std::string CPublic::getWorkPath()
{
    char szTemp[256];
    TCHAR szFilePath[MAX_PATH] = {0};
    GetModuleFileName(NULL,szFilePath,MAX_PATH);
    TCHAR * pszFind = _tcsrchr(szFilePath,_T('\\'));
    *pszFind = 0;
    CString strPath = szFilePath;
    memset(szTemp, 0x0, sizeof(szTemp));
    int iLen = WideCharToMultiByte(CP_ACP, 0,strPath, -1, NULL, 0, NULL, NULL);
    WideCharToMultiByte(CP_ACP, 0, strPath, -1, szTemp, iLen, NULL, NULL);
    return szTemp;
}

CString CPublic::stringToTChar(string &strInfo)
{
    int charLen = strlen(strInfo.c_str());
    int len = MultiByteToWideChar(CP_ACP, 0, strInfo.c_str(), charLen, NULL, 0);
    wchar_t* pWChar = new wchar_t[len + 1];   
    MultiByteToWideChar(CP_ACP, 0, strInfo.c_str(), charLen, pWChar, len); 
    pWChar[len] = '\0';

    CString strPath;
    strPath.Empty();
    //strPath.Append(pWChar);
    strPath.Format(_T("%s"), pWChar);

    if(pWChar)
    { 
        delete[] pWChar;
        pWChar = NULL;
    }

    return strPath;
}

static CString stringToTChar(char* szInfo)
{
    int charLen = strlen(szInfo);
    int len = MultiByteToWideChar(CP_ACP, 0, szInfo, charLen, NULL, 0);
    wchar_t* pWChar = new wchar_t[len + 1];
    MultiByteToWideChar(CP_ACP, 0, szInfo, charLen, pWChar, len);
    pWChar[len] = '\0';

    CString strPath;
    strPath.Empty();
    //strPath.Append(pWChar);
    strPath.Format(_T("%s"), pWChar);

    if (pWChar)
    {
        delete[] pWChar;
        pWChar = NULL;
    }

    return strPath;
}

std::string CPublic::TCharToString(CString &strInfo)
{
    char szTemp[4096];
    memset(szTemp, 0x0, sizeof(szTemp));
    int iLen = WideCharToMultiByte(CP_ACP, 0,strInfo, -1, NULL, 0, NULL, NULL);
    WideCharToMultiByte(CP_ACP, 0, strInfo, -1, szTemp, iLen, NULL, NULL);
    string info(szTemp);
    return info;
}



// ����host
int CPublic::hostToIp(char* szHost, char* szIp)
{
    int iRet = 0;
    if( 0 == strlen(szHost) )
    {
        iRet = 1;
    }
    else
    {
        hostent * pHost = gethostbyname(szHost);
        if(!pHost)
        {
            int iError = GetLastError();
            return -1;
        }
        in_addr addr;   
        CopyMemory(&addr.S_un.S_addr, pHost->h_addr_list[0], pHost->h_length);
        strcpy(szIp,inet_ntoa(addr));
    }
    return iRet;
}



int CPublic::fillBuff(CImage &image, BYTE* pByte)
{
    int stride = 4 * ((image.GetWidth() + 3) / 4);
    size_t safeSize = stride * image.GetHeight() * 4 + sizeof(BITMAPINFOHEADER) + sizeof(BITMAPFILEHEADER) + 256 * sizeof(RGBQUAD);
    size_t mux = stride * image.GetHeight() * 4;
    HGLOBAL mem = GlobalAlloc(GHND, safeSize);
    if (NULL == mem)
    {
        return 0;
    }

    HRESULT hr;
    IStream* stream = 0;
    hr = CreateStreamOnHGlobal(mem, TRUE, &stream);
    hr = image.Save(stream, Gdiplus::ImageFormatPNG);

    LARGE_INTEGER seekPos = {0};
    ULARGE_INTEGER imageSize;
    hr = stream->Seek(seekPos, STREAM_SEEK_CUR, &imageSize);

    //BYTE* buffer = new BYTE[imageSize.LowPart];

    hr = stream->Seek(seekPos, STREAM_SEEK_SET, 0);
    hr = stream->Read(pByte, imageSize.LowPart, 0);

    // Fill buffer from stream
    hr = stream->Seek(seekPos, STREAM_SEEK_SET, 0);
    hr = stream->Read(pByte, imageSize.LowPart, 0);

    if (NULL != mem)
    {
        GlobalFree(mem);
        mem = NULL;
    }
    return imageSize.LowPart;
}

//
//int fillBuff(GpImage &img, BYTE* pByte)
//{
//    UINT  width = 0;
//    UINT  height = 0;
//
//    DllExports::GdipGetImageWidth(&img, &width);
//    DllExports::GdipGetImageHeight(&img, &height);
//
//    int stride = 4 * ((width + 3) / 4);
//    size_t safeSize = stride * height * 4 + sizeof(BITMAPINFOHEADER) + sizeof(BITMAPFILEHEADER) + 256 * sizeof(RGBQUAD);
//    HGLOBAL mem = GlobalAlloc(GHND, safeSize);
//    HRESULT hr;
//    IStream* stream = 0;
//    hr = CreateStreamOnHGlobal(mem, TRUE, &stream);
//
//    CLSID sid;
//    GetEncoderClsid(_T("image/png"), &sid);
//
//    CLSID clsid = Gdiplus::ImageFormatPNG;
//    GpStatus status = DllExports::GdipSaveImageToStream(&img,stream, &sid, NULL);
//
//
//    LARGE_INTEGER seekPos = {0};
//    ULARGE_INTEGER imageSize;
//    hr = stream->Seek(seekPos, STREAM_SEEK_CUR, &imageSize);
//    BYTE* buffer = new BYTE[imageSize.LowPart];
//
//    hr = stream->Seek(seekPos, STREAM_SEEK_SET, 0);
//    hr = stream->Read(pByte, imageSize.LowPart, 0);
//
//    return safeSize;
//}


