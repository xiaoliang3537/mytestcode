#include "stdafx.h"
#include "function.h"
#include "public/Public.h"
#include <Windows.h>
#include <Winsvc.h>
#include <wtsapi32.h>
#include <userenv.h>

using namespace Gdiplus;

BOOL is_main_window(HWND handle)
{
    return GetWindow(handle, GW_OWNER) == (HWND)0 && IsWindowVisible(handle);
}
BOOL CALLBACK enum_windows_callback(HWND handle, LPARAM lParam)
{
    handle_data& data = *(handle_data*)lParam;
    unsigned long process_id = 0;
    GetWindowThreadProcessId(handle, &process_id);
    if (data.process_id != process_id || !is_main_window(handle))
        return TRUE;
    data.window_handle = handle;
    return FALSE;
}
HWND find_main_window(unsigned long process_id)
{
    handle_data data;
    data.process_id = process_id;
    data.window_handle = 0;
    EnumWindows(enum_windows_callback, (LPARAM)&data);
    return data.window_handle;
}


BOOL CALLBACK EnumWindowsProc(HWND hWnd, LPARAM lParam)
{
    DWORD dwProcessId;
    GetWindowThreadProcessId(hWnd, &dwProcessId);
    LPWNDINFO pInfo = (LPWNDINFO)lParam;

    if (dwProcessId == pInfo->dwProcessId)
    {
        HWND hParent = NULL;
        HWND hSelf = hWnd;
        do
        {
            hParent = GetParent(hSelf);
            if (!hParent)
            {
                return TRUE;
            }
            else
            {
                char Text[MAX_PATH] = { 0 };
                //int nLen = ::GetWindowText(hParent, Text, MAX_PATH);
                hSelf = hParent;
                pInfo->hWnd = hParent;
            }
        } while (hParent != hSelf);
    }
    return !(BOOL)pInfo->hWnd;

        return FALSE;
}

HWND GetHwndByProcessId(DWORD dwProcessId)
{
    WNDINFO info = { 0 };
    info.hWnd = NULL;
    info.dwProcessId = dwProcessId;
    EnumWindows(EnumWindowsProc, (LPARAM)&info);
    return info.hWnd;
}

HWND GetXHandle(LPCWSTR procName)
{
    DWORD iProcID = 0;
    PROCESSENTRY32 pEntry = { sizeof(PROCESSENTRY32) };
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPALL, 0);
    if (hSnapshot != INVALID_HANDLE_VALUE)
    {
        if (Process32First(hSnapshot, &pEntry))
        {
            while (Process32Next(hSnapshot, &pEntry))
            {
                //CString str = pEntry.szExeFile;
                //LOG(INFO) << str << endl;
                if (lstrcmpi(procName, pEntry.szExeFile) == 0)
                {
                    iProcID = pEntry.th32ProcessID;
                    CloseHandle(hSnapshot);
                    break;
                }
            }
        }
    }
    HWND hwnd = ::GetTopWindow(NULL);
    while (hwnd)
    {
        DWORD pid = 0;
        DWORD dwProcessId = GetWindowThreadProcessId(hwnd, &pid);
        if (dwProcessId != 0)
        {
            if (pid == iProcID)
            {
                LOG(INFO) << "return hwnd " << endl;
                return hwnd;
            }
        }
        CWnd* wnd = CWnd::FromHandle(hwnd);
        CString str;
        wnd->GetWindowTextW(str);
        hwnd = ::GetNextWindow(hwnd, GW_HWNDNEXT);
        //LOG(INFO) << "GetTopWindow  " << str  << "  " << pid << "  " << dwProcessId << "  " << iProcID << endl;
    }
    LOG(INFO) << "return NULL " << endl;
    return NULL;
}


// ͨ������������߳�ID 
UINT32 GetTargetThreadIdFromProcessName(WCHAR *ProcessName)
{
    PROCESSENTRY32 pe;
    HANDLE SnapshotHandle = NULL;
    HANDLE ProcessHandle = NULL;
    BOOL Return, ProcessFound = FALSE;
    UINT32 pTID, ThreadID;

    SnapshotHandle = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);

    if (SnapshotHandle == INVALID_HANDLE_VALUE)
    {
        MessageBox(NULL, L"Error: unable to create toolhelp snapshot", L"Loader", NULL);
        return FALSE;
    }

    pe.dwSize = sizeof(PROCESSENTRY32);

    Return = Process32First(SnapshotHandle, &pe);

    while (Return)
    {
        if (_wcsicmp(pe.szExeFile, ProcessName) == 0)
        {
            ProcessFound = TRUE;
            break;
        }

        Return = Process32Next(SnapshotHandle, &pe);
        pe.dwSize = sizeof(PROCESSENTRY32);

    }

    CloseHandle(SnapshotHandle);
    //ͨ��fs�Ĵ�����ȡTID  
    _asm
    {
        mov eax, fs:[0x18]
        add eax, 36
        mov[pTID], eax
    }

    ProcessHandle = OpenProcess(PROCESS_VM_READ, FALSE, pe.th32ProcessID);
    bool b = ReadProcessMemory(ProcessHandle, (LPCVOID)pTID, &ThreadID, 4, NULL);
    DWORD d = GetLastError();
    CloseHandle(ProcessHandle);

    return ThreadID;
}

UINT32 GetTargetThreadIdFromProcessNameEx(WCHAR *ProcessName)
{
    HWND h = GetXHandle(ProcessName);
    DWORD ProcessID;
    DWORD ThreadID;
    ThreadID = GetWindowThreadProcessId(h, &ProcessID);

    return ThreadID;
}

DWORD GetWndProcessIDByName(WCHAR *ProcessName)
{
    DWORD iProcID = 0;
    PROCESSENTRY32 pEntry = { sizeof(PROCESSENTRY32) };
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPALL, 0);
    if (hSnapshot != INVALID_HANDLE_VALUE)
    {
        if (Process32First(hSnapshot, &pEntry))
        {
            while (Process32Next(hSnapshot, &pEntry))
            {
                //CString str = pEntry.szExeFile;
                //LOG(INFO) << str << endl;
                if (lstrcmpi(ProcessName, pEntry.szExeFile) == 0)
                {
                    iProcID = pEntry.th32ProcessID;
                    CloseHandle(hSnapshot);
                    break;
                }
            }
        }
    }
    return iProcID;
}

//���̿��գ�ö�ٸ����̣�
BOOL GetPidByProcessName(LPCTSTR lpszProcessName, DWORD &dwPid)
{
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (INVALID_HANDLE_VALUE == hSnapshot)
    {
        return FALSE;
    }

    PROCESSENTRY32 pe;
    pe.dwSize = sizeof(PROCESSENTRY32);
    if (!Process32First(hSnapshot, &pe))
    {
        ::CloseHandle(hSnapshot);
        return FALSE;
    }

    while (Process32Next(hSnapshot, &pe))
    {
        if (!lstrcmp(lpszProcessName, pe.szExeFile))
        {
            ::CloseHandle(hSnapshot);
            dwPid = pe.th32ProcessID;
            return TRUE;
        }
    }

    ::CloseHandle(hSnapshot);
    return FALSE;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//BOOL IsMainWindow(HWND handle)
//{
//    return GetWindow(handle, GW_OWNER) == (HWND)0 && IsWindowVisible(handle);
//}
//
//BOOL CALLBACK EnumWindowsCallback(HWND handle, LPARAM lParam)
//{
//    handle_data& data = *(handle_data*)lParam;
//    unsigned long process_id = 0;
//    GetWindowThreadProcessId(handle, &process_id);
//    if (data.process_id != process_id || !IsMainWindow(handle)) {
//        return TRUE;
//    }
//    data.best_handle = handle;
//    return FALSE;
//}
//
//HWND FindMainWindow(unsigned long process_id)
//{
//    handle_data data;
//    data.process_id = process_id;
//    data.best_handle = 0;
//    EnumWindows(EnumWindowsCallback, (LPARAM)&data);
//    return data.best_handle;
//}

//void OnOK()
//{
//    //��ȡIE������
//    HWND ExplorerWnd = ::FindWindow(_T("IEFrame"), NULL);
//    if (!ExplorerWnd)
//        ::MessageBox(m_hWnd, TEXT("û���Ҵ�IE����"), NULL, MB_OK);
//    ::SetForegroundWindow(ExplorerWnd);
//    //����IE�����ڻ�ȡ���������
//    HWND BrowserWnd = FindWithClassName(ExplorerWnd, _T("Internet Explorer_Server"));
//    if (BrowserWnd)
//    {
//        GetIHTMLDocument2Interface(BrowserWnd);
//    }
//}

/****************************************************************************
Ѱ��ָ���������Ӵ��ھ��
****************************************************************************/
HWND FindWithClassName(HWND ParentWnd, TCHAR* FindClassName)
{
    HWND hChild = ::GetWindow(ParentWnd, GW_CHILD);
    for (; hChild != NULL; hChild = ::GetWindow(hChild, GW_HWNDNEXT))
    {
        TCHAR ClassName[100] = { 0 };
        ::GetClassName(hChild, ClassName, sizeof(ClassName) / sizeof(TCHAR));
        if (_tcscmp(ClassName, FindClassName) == 0)
        {
            CWnd* wnd = CWnd::FromHandle(hChild);
            CString str;
            LPTSTR pszName = NULL;

            while (true)
            {
                CWnd *p = wnd->GetParent();
                if (NULL == p)
                {
                    break;
                }
                wnd = p;

                VARIANT varChild;
                VariantInit(&varChild);

                varChild.vt = VT_I4;
                varChild.lVal = CHILDID_SELF;

                CComPtr<IDispatch> spDisp;
                wnd->GetAccessibleName(varChild, &pszName);
                if (NULL == pszName)
                {
                    continue;
                }
                str.Format(_T("%s"), pszName);
                if (str.GetLength() != 0 && (str.Compare(_T("NULL")) != 0) && (0 != str.Compare(_T("none"))))
                {
                    break;
                }
            }
            OutputDebugString(str);
            OutputDebugString(FindClassName);
            OutputDebugString(_T("\r\n"));
        }

        HWND FindWnd = FindWithClassName(hChild, FindClassName);
        if (FindWnd)
            return FindWnd;
    }
    return NULL;
}

void GetIHTMLDocument2Interface(HWND BrowserWnd)
{
    CoInitialize(NULL);

    HRESULT hr;
    // Explicitly load MSAA so we know if it's installed
    HINSTANCE hInst = ::LoadLibrary(_T("OLEACC.DLL"));
    if (hInst)
    {
        LRESULT lRes; //SendMessageTimeout��ķ���ֵ�����ں���pfObjectFromLresult�ĵ�1������
        UINT nMsg = ::RegisterWindowMessage(_T("WM_HTML_GETOBJECT"));
        ::SendMessageTimeout(BrowserWnd, nMsg, 0L, 0L, SMTO_ABORTIFHUNG, 1000, (DWORD*)&lRes);

        //��ȡ����pfObjectFromLresult
        LPFNOBJECTFROMLRESULT pfObjectFromLresult = (LPFNOBJECTFROMLRESULT)::GetProcAddress(hInst, ("ObjectFromLresult"));
        if (pfObjectFromLresult)
        {
            CComPtr<IHTMLDocument2> spDoc;
            hr = (*pfObjectFromLresult)(lRes, IID_IHTMLDocument, 0, (void**)&spDoc);
            if (SUCCEEDED(hr))
            {
                //��ȡ�ĵ��ӿ�
                CComPtr<IDispatch> spDisp;
                spDoc->get_Script(&spDisp);
                CComQIPtr<IHTMLWindow2> spWin = spDisp;
                spWin->get_document(&spDoc.p);
                //  Change background color to red
                spDoc->put_bgColor(CComVariant("red"));
                CComPtr<IHTMLElement> item;
                spDoc->get_body(&item);
                BSTR pbClass;
                item->get_innerHTML(&pbClass);

            } // else document not ready
        } // else Internet Explorer is not running
        ::FreeLibrary(hInst);
    } // else Active Accessibility is not installed

    CoUninitialize();
}

IWebBrowser2* GetIWebBrowserInterface(HWND BrowserWnd)
{
    //CoInitialize(NULL);  //��仰Ҫ������Ĺ��캯����

    IWebBrowser2* pWebBrowser2 = NULL;
    HRESULT hr;
    // Explicitly load MSAA so we know if it's installed
    HINSTANCE hInst = ::LoadLibrary(_T("OLEACC.DLL"));
    if (hInst)
    {
        LRESULT lRes;
        UINT nMsg = ::RegisterWindowMessage(_T("WM_HTML_GETOBJECT"));
        ::SendMessageTimeout(BrowserWnd, nMsg, 0L, 0L, SMTO_ABORTIFHUNG, 1000, (DWORD*)&lRes);

        LPFNOBJECTFROMLRESULT pfObjectFromLresult = (LPFNOBJECTFROMLRESULT)::GetProcAddress(hInst, ("ObjectFromLresult"));
        if (pfObjectFromLresult)
        {
            CComPtr<IServiceProvider> spServiceProv;
            hr = (*pfObjectFromLresult)(lRes, IID_IServiceProvider, 0, (void**)&spServiceProv);
            if (SUCCEEDED(hr))
            {
                hr = spServiceProv->QueryService(SID_SWebBrowserApp,
                    IID_IWebBrowser2, (void**)&pWebBrowser2);
            } // else document not ready
        } // else Internet Explorer is not running
        ::FreeLibrary(hInst);
    } // else Active Accessibility is not installed

      //CoUninitialize(); //��仰Ҫ����������������У����򷵻�ֵ��ʹ���ǿ�ָ��Ҳ��Ч

    return SUCCEEDED(hr) ? pWebBrowser2 : NULL;
}

char* TCHAR2char(TCHAR* tchStr)
{
    int iLen = 2 * wcslen(tchStr);
    char* chRtn = new char[iLen + 1];
    int len = wcstombs(chRtn, tchStr, iLen + 1);
    return chRtn;
}

void GetObjectName(IAccessible* child, VARIANT* varChild, char* objName, int len)
{
    BSTR strTmp;
    HRESULT hr = child->get_accName(*varChild, &strTmp);
    if (S_OK != hr || NULL == strTmp)
    {
        return;
    }
    _bstr_t str = strTmp;
    char* tmp = str;
    //strcpy_s(objName, 128, tmp);
    memccpy(objName, tmp, 1, 128);

}

char* WCharToChar(WCHAR *s) {
    int w_nlen = WideCharToMultiByte(CP_ACP, 0, s, -1, NULL, 0, NULL, false);
    char *ret = new char[w_nlen];
    memset(ret, 0, w_nlen);
    WideCharToMultiByte(CP_ACP, 0, s, -1, ret, w_nlen, NULL, false);
    return ret;
}

void GetObjectRole(IAccessible* child, VARIANT* varChild, DWORD &id, char* objRole, int len)
{
    VARIANT pvarRole;
    DWORD roleId;
    child->get_accRole(*varChild, &pvarRole);

    if (varChild->vt != VT_I4)
    {
        pvarRole.vt = VT_EMPTY;
        return /*E_INVALIDARG*/;
    }
    roleId = pvarRole.lVal;
    UINT   roleLength;
    LPWSTR lpszRoleString;

    // Get the length of the string.
    roleLength = GetRoleTextW(roleId, NULL, 0);

    // Allocate memory for the string. Add one character to
    // the length you got in the previous call to make room
    // for the null character.
    lpszRoleString = (LPWSTR)malloc((roleLength + 1) * sizeof(TCHAR));
    if (lpszRoleString != NULL)
    {
        // Get the string.
        GetRoleTextW(roleId, lpszRoleString, roleLength + 1);
        id = roleId;
    }

    //char* tmp = TCHAR2char(lpszRoleString);
    //free(lpszRoleString);
    char* tmp = WCharToChar(lpszRoleString);
    free(lpszRoleString);
    strcpy_s(objRole, MAX_PATH - 1, tmp);
    sprintf(objRole + strlen(objRole), "%06x", roleId);
    delete[] tmp;
    return /*S_OK*/;

}

void GetObjectClass(IAccessible* child, char* objClass, int len)
{
    HWND htmp;
    LPTSTR strClass;
    strClass = (LPTSTR)malloc(MAX_PATH);
    ::WindowFromAccessibleObject(child, &htmp);
    if (0 == ::GetClassName(htmp, strClass, MAX_PATH))
    {
        free(strClass);
        return;
    }
    if (NULL == htmp)
    {
        return;
    }
    char* tmp = TCHAR2char(strClass);

    strcpy_s(objClass, MAX_PATH - 1, tmp);
    free(strClass);
    delete[] tmp;
}
BOOL FindChild(IAccessible* paccParent, LPSTR szName, LPSTR szRole, LPSTR szClass, IAccessible** paccChild, VARIANT* pvarChild, int depth)
{
    HRESULT hr;
    long numChildren;
    unsigned long numFetched;
    VARIANT varChild;
    int index;
    IAccessible* pCAcc = NULL;
    IEnumVARIANT* pEnum = NULL;
    IDispatch* pDisp = NULL;
    BOOL found = false;
    char szObjName[1024] = { 0 }, szObjRole[1024] = { 0 }, szObjClass[1024] = { 0 }, szObjState[1024] = { 0 };
    DWORD id = 0;
    //�õ�����֧�ֵ�IEnumVARIANT�ӿ�
    hr = paccParent->QueryInterface(IID_IEnumVARIANT, (PVOID*)& pEnum);

    if (pEnum)
        pEnum->Reset();

    //ȡ�ø���ӵ�еĿɷ��ʵ��ӵ���Ŀ
    paccParent->get_accChildCount(&numChildren);
    //�������Ƚ�ÿһ����ID���ҵ����֡���ɫ������������һ�µġ�
    for (index = 1; index <= numChildren && !found; index++)
    {
        pCAcc = NULL;
        // ���֧��IEnumVARIANT�ӿڣ��õ���һ����ID
        //�Լ����Ӧ�� IDispatch �ӿ�
        if (pEnum)
            hr = pEnum->Next(1, &varChild, &numFetched);
        else
        {
            //���һ�����ײ�֧��IEnumVARIANT�ӿڣ���ID�����������
            varChild.vt = VT_I4;
            varChild.lVal = index;
        }

        // �ҵ�����ID��Ӧ�� IDispatch �ӿ�
        if (varChild.vt == VT_I4)
        {
            //ͨ����ID��ŵõ���Ӧ�� IDispatch �ӿ�
            pDisp = NULL;
            hr = paccParent->get_accChild(varChild, &pDisp);
        }
        else
            //�����֧��IEnumVARIANT�ӿڿ���ֱ�ӵõ���IDispatch �ӿ�
            pDisp = varChild.pdispVal;

        // ͨ�� IDispatch �ӿڵõ��ӵ� IAccessible �ӿ� pCAcc
        if (pDisp)
        {
            hr = pDisp->QueryInterface(IID_IAccessible, (void**)&pCAcc);
            hr = pDisp->Release();
        }

        // Get information about the child
        if (pCAcc)
        {
            //�����֧��IAccessible �ӿڣ���ô��ID����CHILDID_SELF
            VariantInit(&varChild);
            varChild.vt = VT_I4;
            varChild.lVal = CHILDID_SELF;

            *paccChild = pCAcc;
        }
        else
            //����Ӳ�֧��IAccessible �ӿ�
            *paccChild = paccParent;

        //�������в��ɷ���״̬��Ԫ��
        //GetObjectState(*paccChild, &varChild, szObjState, sizeof(szObjState));
        //if (NULL != strstr(szObjState, "unavailable"))
        //{
        //    if (pCAcc)
        //        pCAcc->Release();
        //    continue;
        //}
        ////ͨ��get_accName�õ�Name
        GetObjectName(*paccChild, &varChild, szObjName, sizeof(szObjName));
        //ͨ��get_accRole�õ�Role
        GetObjectRole(*paccChild, &varChild, id, szObjRole, sizeof(szObjRole));
        //ͨ��WindowFromAccessibleObject��GetClassName�õ�Class
        GetObjectClass(*paccChild, szObjClass, sizeof(szObjClass));

        //����ʵ�ִ���Ƚϼ򵥣�����Լ�������ɡ�

        ////�����Щ�������������������ΪNULL
        //if ((!szName || !strcmp(szName, szObjName)) && (!szRole || !strcmp(szRole, szObjRole)) && (!szClass || !strcmp(szClass, szObjClass)))
        //{
        //    found = true;
        //    *pvarChild = varChild;
        //    break;
        //}

        std::fstream file("E:\\code\\vs_test\\testhook\\Debug\\DetoursTest.txt", std::ios::out | std::ios::app);
        if (file.is_open())
        {
            bool b = false;
            if (id == 0x0 || id == 0x1 || id == 0x2 || id == 0x3 || id == 0x4 || id == 0x0C || id == 0x15 || id == 0x16 || id == 0x19 ||
                id == 0x23 || id == 0x27 || id == 0x28 || id == 0x2B || id == 0x29)
            {
                b = true;
            }
            if ((id == 0x0A && strcmp(szObjName, "Ӧ�ó���") == 0) || strlen(szObjName) == 0)
            {
                b = true;
            }
            //if (NULL != strstr(szObjClass, "WindowsForms10.Window.8.app"))
            //{
            //    if ( strlen(szObjName) == 0 || NULL != strstr(szObjName, "<null>") )
            //    {
            //        b= true;
            //    }
            //}
            if (!b)
            {
                for (int y = 0; y < depth; y++)
                {
                    file << "  ";
                }
                //if (strlen(szObjName) == MAX_PATH -1 )
                //{
                //    HWND hChild;
                //    hr = WindowFromAccessibleObject(pChild, &hChild);
                //    if (hr== S_OK)
                //    {
                //        CWnd *wnd = CWnd::FromHandle(hChild);
                //        CString str;
                //        wnd->GetWindowTextW(str);
                //        OutputDebugString(str);
                //        OutputDebugString(_T("\r\n"));
                //    }
                //}
                file << szObjName << "|" << szObjClass << "|" << szObjRole << std::endl;
            }
        }
        file.close();


        if (!found && pCAcc)
        {
            // ����εõ����ӽӿ�Ϊ���ݹ����
            found = FindChild(pCAcc,
                szName,
                szRole,
                szClass,
                paccChild,
                pvarChild, depth + 1);
            if (*paccChild != pCAcc)
                pCAcc->Release();
        }
    }//End for

     // Clean up
    if (pEnum)
        pEnum->Release();

    return found;
}

// UIԪ�ص�״̬Ҳ��ʾ��������ʽ����Ϊһ��״̬�����ж��ֵ��
//�����ѡ�ġ���������ģ��������Ƿ�ӳ��Щֵ��λ�Ļ���������
//����Щ����ת������Ӧ���ö��ŷָ��״̬�ַ�����
//UINT GetObjectState(IAccessible* pacc, VARIANT* pvarChild, LPTSTR lpszState, UINT cchState)
//{
//    HRESULT hr;
//    VARIANT varRetVal;
//
//    *lpszState = 0;
//
//    VariantInit(&varRetVal);
//
//    hr = pacc->get_accState(*pvarChild, &varRetVal);
//
//    if (!SUCCEEDED(hr))
//        return(0);
//
//    DWORD dwStateBit;
//    int cChars = 0;
//    if (varRetVal.vt == VT_I4)
//    {
//        // ���ݷ��ص�״ֵ̬�����Զ������ӵ��ַ�����
//        for (dwStateBit = STATE_SYSTEM_UNAVAILABLE;
//            dwStateBit < STATE_SYSTEM_ALERT_HIGH;
//            dwStateBit <<= 1)
//        {
//            if (varRetVal.lVal & dwStateBit)
//            {
//                cChars += GetStateText(dwStateBit,
//                    lpszState + cChars,
//                    cchState - cChars);
//                *(lpszState + cChars++) = '', '';
//            }
//        }
//        if (cChars > 1)
//            *(lpszState + cChars - 1) = ''\0'';
//    }
//    else if (varRetVal.vt == VT_BSTR)
//    {
//        WideCharToMultiByte(CP_ACP,
//            0,
//            varRetVal.bstrVal,
//            -1,
//            lpszState,
//            cchState,
//            NULL,
//            NULL);
//    }
//
//    VariantClear(&varRetVal);
//
//    return(lstrlen(lpszState));
//}

vector<int> split(const string &str, const string &pattern)
{
    //const char* convert to char*
    char * strc = new char[strlen(str.c_str()) + 1];
    strcpy(strc, str.c_str());
    vector<int> resultVec;
    char* tmpStr = strtok(strc, pattern.c_str());
    while (tmpStr != NULL)
    {
        resultVec.push_back(atoi(tmpStr));
        tmpStr = strtok(NULL, pattern.c_str());
    }

    delete[] strc;

    return resultVec;
}

int splitString(const CString str, char split, CStringArray &strArray)
{
    strArray.RemoveAll();
    CString strTemp = str;
    int iIndex = 0;
    while (1)
    {
        iIndex = strTemp.Find(split);
        if (iIndex >= 0)
        {
            strArray.Add(strTemp.Left(iIndex));
            strTemp = strTemp.Right(strTemp.GetLength() - iIndex - 1);
        }
        else
        {
            break;
        }
    }
    strArray.Add(strTemp);

    return strArray.GetSize();
}


int saveBitmapToFile(CString strFileName, CImage& img, RectF &srcRect, RectF &tagRect)
{
    CImage imgage;
    imgage.Create(tagRect.Width, tagRect.Height, 32, 0);


    bool b = BitBlt(imgage.GetDC(), 0, 0, srcRect.Width, srcRect.Height,
        img.GetDC(), tagRect.X, tagRect.Y, SRCCOPY);
    imgage.Save(strFileName);

    img.ReleaseDC();
    imgage.ReleaseDC();
    return b ? 0 : 1;
}


int showSpecifiedWnd(HWND hwd, bool show)
{
    if (NULL == hwd)
    {
        return 0;
    }
    CWnd *wnd = CWnd::FromHandle(hwd);
    if (NULL != wnd)
    {
        if (IsIconic(hwd))
        {
            wnd->ShowWindow(SW_SHOWMAXIMIZED);
        }
        if (!wnd->IsWindowVisible())
        {
            wnd->ShowWindow(SW_SHOW);
        }
        //else
        //{
        //    wnd->ShowWindow(SW_HIDE);
        //}
    }
    return 0;
}


int topSpecifiedWnd(HWND hwd)
{
    if (NULL == hwd)
    {
        return 0;
    }
    ::SetWindowPos(hwd, 0, 0, 0, 0,0, SWP_NOMOVE | SWP_NOSIZE);
    return 0;
}


DWORD GetActiveSessionID()
{

    DWORD dwSessionId = 0;
    PWTS_SESSION_INFO pSessionInfo = NULL;
    DWORD dwCount = 0;

    WTSEnumerateSessions(WTS_CURRENT_SERVER_HANDLE, 0, 1, &pSessionInfo, &dwCount);

    for (DWORD i = 0; i < dwCount; i++)
    {
        WTS_SESSION_INFO si = pSessionInfo[i];
        if (WTSActive == si.State)
        {
            dwSessionId = si.SessionId;
            break;
        }
    }

    WTSFreeMemory(pSessionInfo);
    return dwSessionId;

}
BOOL TriggerAppExecute(std::wstring wstrCmdLine/*, INT32& n32ExitResult*/)
{
    DWORD dwProcesses = 0;
    BOOL bResult = FALSE;

    //DWORD dwSid = GetActiveSessionID();
    DWORD dwSid = WTSGetActiveConsoleSessionId();
    DWORD dwRet = 0;
    PROCESS_INFORMATION pi;
    STARTUPINFO si;
    HANDLE hProcess = NULL, hPToken = NULL, hUserTokenDup = NULL;
    if (!WTSQueryUserToken(dwSid, &hPToken))
    {
        PROCESSENTRY32 procEntry;
        DWORD dwPid = 0;
        HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (hSnap == INVALID_HANDLE_VALUE)
        {
            return FALSE;
        }

        procEntry.dwSize = sizeof(PROCESSENTRY32);
        if (Process32First(hSnap, &procEntry))
        {
            do
            {
                if (_tcsicmp(procEntry.szExeFile, _T("explorer.exe")) == 0)
                {
                    DWORD exeSessionId = 0;
                    if (ProcessIdToSessionId(procEntry.th32ProcessID, &exeSessionId) && exeSessionId == dwSid)
                    {
                        dwPid = procEntry.th32ProcessID;
                        break;
                    }
                }

            } while (Process32Next(hSnap, &procEntry));
        }
        CloseHandle(hSnap);

        // explorer���̲�����
        if (dwPid == 0)
        {
            return FALSE;
        }

        hProcess = ::OpenProcess(PROCESS_QUERY_INFORMATION, FALSE, dwPid);
        if (hProcess == NULL)
        {
            return FALSE;
        }

        if (!::OpenProcessToken(hProcess, TOKEN_ALL_ACCESS_P, &hPToken))
        {
            CloseHandle(hProcess);
            return FALSE;
        }
    }

    if (hPToken == NULL)
        return FALSE;

    TOKEN_LINKED_TOKEN admin;
    bResult = GetTokenInformation(hPToken, (TOKEN_INFORMATION_CLASS)TokenLinkedToken, &admin, sizeof(TOKEN_LINKED_TOKEN), &dwRet);

    if (!bResult) // vista ��ǰ�汾��֧��TokenLinkedToken
    {
        TOKEN_PRIVILEGES tp;
        LUID luid;
        if (LookupPrivilegeValue(NULL, SE_DEBUG_NAME, &luid))
        {
            tp.PrivilegeCount = 1;
            tp.Privileges[0].Luid = luid;
            tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
        }
        //����token
        DuplicateTokenEx(hPToken, MAXIMUM_ALLOWED, NULL, SecurityIdentification, TokenPrimary, &hUserTokenDup);
    }
    else
    {
        hUserTokenDup = admin.LinkedToken;
    }

    LPVOID pEnv = NULL;
    DWORD dwCreationFlags = CREATE_PRESERVE_CODE_AUTHZ_LEVEL;

    // hUserTokenDup Ϊ��ǰ��½�û�������
    if (CreateEnvironmentBlock(&pEnv, hUserTokenDup, TRUE))
    {
        //��������˻�������������CreateProcessAsUser��
        //dwCreationFlags������Ҫ����CREATE_UNICODE_ENVIRONMENT��
        //����MSDN��ȷ˵����
        dwCreationFlags |= CREATE_UNICODE_ENVIRONMENT;
    }
    else
    {
        //������������ʧ����Ȼ���Դ������̣�
        //����Ӱ�쵽����Ľ��̻�ȡ������������
        pEnv = NULL;
    }

    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;
    ZeroMemory(&pi, sizeof(pi));

    //si.cb = sizeof(STARTUPINFO);
    //si.lpDesktop = _T("WinSta0//Default");

    bResult = CreateProcessAsUser(
        hUserTokenDup,                      // client's access token
        //NULL,                               // file to execute
        _T("E:\\code\\vs_test\\testhook\\Debug\\hookUI.exe"),
        (LPTSTR)wstrCmdLine.c_str(),                 // command line
        NULL,            // pointer to process SECURITY_ATTRIBUTES
        NULL,               // pointer to thread SECURITY_ATTRIBUTES
        FALSE,              // handles are not inheritable
        dwCreationFlags,     // creation flags
        pEnv,               // pointer to new environment block
        NULL,               // name of current directory
        &si,               // pointer to STARTUPINFO structure
        &pi                // receives information about new process
    );


    if (pi.hProcess)
    {
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
    }

    if (hUserTokenDup != NULL)
        CloseHandle(hUserTokenDup);
    if (hProcess != NULL)
        CloseHandle(hProcess);
    if (hPToken != NULL)
        CloseHandle(hPToken);
    if (pEnv != NULL)
        DestroyEnvironmentBlock(pEnv);

    return TRUE;
}