#pragma once

#include <stdio.h>
#include <string>
#include <Gdiplus.h>
#include <atlimage.h>
#include <GdiPlusGpStubs.h>
#include <GdiPlusGraphics.h>
#include <cstring>

using namespace std;

// ȥ����β�ո�
void Trim(string &s)
{
    if( !s.empty() )
    {
        s.erase(0,s.find_first_not_of(" "));
        s.erase(s.find_last_not_of(" ") + 1);
    }
}
// ȥ�����пո�
void TrimAll(string &s)
{
    int index = 0;
    if( !s.empty())
    {
        while( (index = s.find(' ',index)) != string::npos)
        {
            s.erase(index,1);
        }
    }
}
// ȥ��β���ո�
void TrimRight(char *pStr)
{
    char *pTmp = pStr+strlen(pStr)-1; 
    while (*pTmp == ' ') 
    { 
        *pTmp = '/0'; 
        pTmp--; 
    } 
}
void TrimAll(char *pStr)
{
    char *pTmp = pStr; 
    while (*pStr != '/0') 
    { 
        if (*pStr != ' ') 
        { 
            *pTmp++ = *pStr; 
        } 
        ++pStr; 
    } 
    *pTmp = '/0'; 
}

/*ȥ���ַ�����߿ո�*/
void TrimLeft(char *pStr) 
{ 
    char *pTmp = pStr; 
    while (*pTmp == ' ') 
    { 
        pTmp++; 
    } 
    while(*pTmp != '/0') 
    { 
        *pStr = *pTmp; 
        pStr++; 
        pTmp++; 
    } 
    *pStr = '/0'; 
}

