#pragma once

#include <afxinet.h>
#include <afxhtml.h>
#include <OleAcc.h>
#include <comdef.h>
#include <iostream>
#include <fstream>
#include <vector>
#include "service.h"
#include "thread.h"
#include "data/MyAppScanCof.h"
#include "loger.h"

class CMonitorServer;
class CServiceSocket;
// ϵͳ����
class server : public Thread
{
public:
    HANDLE m_hEventExit;
public:
    server();
    ~server();
    int initServer();
public:
    virtual void execute() ;
    virtual void stop();
    virtual void start();
protected:
    loger* m_loger;
private:

};

// FTP server
class FTPServer : public Thread
{
public:
    FTPServer();
    ~FTPServer();
    int initServer();
    void setStartEvent(HANDLE startEvent) { m_hEventServerStart = startEvent;  };
public:
    virtual void execute();
    virtual void stop();
    virtual void start();
protected:
    loger* m_loger;
private:
    HANDLE m_hEventExit;
    HANDLE m_hEventServerStart;
    HINSTANCE m_hInst;
};
