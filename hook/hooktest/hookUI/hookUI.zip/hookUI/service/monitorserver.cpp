#include "stdafx.h"
#include "monitorserver.h"
#include "MyHookCof.h"

CMonitorServer::CMonitorServer()
{
    m_hEventExit = CreateEvent(0, FALSE, FALSE, _T("") );
    m_myAppScan = new CMyAppScanCof();
    m_bInit = false;
    
}

CMonitorServer::~CMonitorServer()
{

}


void CMonitorServer::execute()
{
    LOG(INFO) << "Monitor Server start:thead id =" << GetCurrentThreadId() << endl;
    while (1)
    {
        int iRet = WaitForSingleObject(m_hEventExit, 5000);
        if (iRet == WAIT_OBJECT_0)
        {
            break;
        }
        else if(iRet == WAIT_TIMEOUT)
        {
            //if (m_bInit)
            //{
            //    LOG(INFO) << "clickMenuProblem" << endl;
            //    m_myAppScan->clickMenuProblem();
            //}
            //LOG(INFO) << "CMonitorServer time out" << endl;
            iRet = getProcessHandle();

            if ( 0 == iRet && !m_bInit )
            {
                //PostMessage(NULL, WM_USER_MONITORSERVER, 0, 0);
                std::wstring str;
                str = _T("-run");
                //TriggerAppExecute(str);

                //CString str = _T("AppScan.exe");
                //LOG(INFO) << "init AppScan" << endl;
                //// �ȴ�����������ɽ��г�ʼ��
                //Sleep(3 * 1000);
                //m_myAppScan->init(0);

                //LOG(INFO) << "mouse hook" << endl;
                //if (0 != m_hookCof->mouseHook(str))
                //{
                //    LOG(ERROR) << "��깳�Ӱ�װʧ��!" << endl;
                //    ::AfxMessageBox(_T("��깳�Ӱ�װʧ��!"));
                //    continue;
                //}

                m_bInit = true;
            }
            else if (2 == iRet)
            {
                // �������
            }
        }
        else
        {

        }
    }
    LOG(INFO) << "Monitor Server terminate:thead id =" << GetCurrentThreadId() << endl;
}

void CMonitorServer::stop()
{
    SetEvent(m_hEventExit);
}

void CMonitorServer::start()
{
    
}

int CMonitorServer::getProcessData(ST_ProcessData& stProcessData)
{
    int iRet = 0;
    stProcessData.hHwnd = m_stProcessData.hHwnd;
    stProcessData.iProcessID = m_stProcessData.iProcessID;
    stProcessData.strBinPath = m_stProcessData.strBinPath;
    stProcessData.strName = m_stProcessData.strName;
    return iRet;
}

int CMonitorServer::getProcessHandle()
{
    // �����ҵĽ���
    CString str = _T("AppScan.exe");
    HWND h;
    DWORD d = GetWndProcessIDByName(str.GetBuffer());
    
    if (0 == d  )
    {
        if (m_bInit)
        {
            //LOG(DEBUG) << "AppScan.exe has broke" << endl;
            return 2;
        }
        //LOG(DEBUG) << "cant find AppScan.exe " << endl;
        return 1;
    }
    //LOG(DEBUG) << "find AppScan.exe " << endl;
    return 0;
}

