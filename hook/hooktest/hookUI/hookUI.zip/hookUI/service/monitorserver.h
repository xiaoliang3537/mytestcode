#pragma once

#include <afxinet.h>
#include <afxhtml.h>
#include <OleAcc.h>
#include <comdef.h>
#include <iostream>
#include <fstream>
#include <vector>
#include "service.h"
#include "thread.h"
#include "data/MyAppScanCof.h"
#include "function.h"
#include "server.h"

class loger;
class CMyHookCof;

struct ST_ProcessData
{
    CString strName;
    CString strBinPath;
    DWORD iProcessID;
    HWND hHwnd;
};
// ϵͳ����
class CMonitorServer : public Thread
{
public:
    CMonitorServer();
    ~CMonitorServer();

public:
    virtual void execute() ;
    virtual void stop();
    virtual void start();

public:
    int getProcessData(ST_ProcessData& stProcessData);
protected:
    int getProcessHandle();
private:
    HANDLE m_hEventExit;
    CMyAppScanCof *m_myAppScan;
    CMyHookCof * m_hookCof;
    ST_ProcessData m_stProcessData;
    bool m_bInit;
};

