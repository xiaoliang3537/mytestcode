#include "stdafx.h"
#include "server.h"
#include "log/loger.h"
#include "monitorserver.h"
#include "ServiceSocket.h"
#include "Public.h"

HANDLE g_hStartEvent;
typedef BOOL (*pStartFTPServer)(DWORD type, UINT32 id);
typedef BOOL (*pStopFTPServer)(DWORD type, UINT32 id);

pStartFTPServer StartFTPServer = NULL;
pStopFTPServer StopFTPServer = NULL;

CMyAppScanCof *g_myAppScan = NULL;
CMonitorServer* g_monotorServer = NULL;
CServiceSocket* g_serviceSocket = NULL;


extern "C" __declspec(dllexport) BOOL StartFtpServer(DWORD type, UINT32 id);
extern "C" __declspec(dllexport) BOOL StopFtpServer(DWORD type, UINT32 id);
extern "C" __declspec(dllexport) BOOL AddFtpUser(void* info);

server::server()
{

}

server::~server()
{

}


int server::initServer()
{
    int iRet = 0;
    m_hEventExit = CreateEvent(0, FALSE, FALSE, _T(""));
    if (m_hEventExit == 0)
    {
        printf("create start event failed,errno:%d\n", ::GetLastError());
        return -1;
    }
    g_hStartEvent = ::CreateEvent(0, FALSE, FALSE, 0);
    if (g_hStartEvent == 0)
    {
        printf("create start event failed,errno:%d\n", ::GetLastError());
        return -1;
    }

    // ������ط���
    g_monotorServer = new CMonitorServer();

    // ����socket
    g_serviceSocket = new CServiceSocket();
    if (0 != g_serviceSocket->startListen() )
    {
        LOG(ERROR) << "start service socket failed" << endl;
        return -1;
    }
    
    // ����FTP����
    FTPServer* ftpServer = new FTPServer();
    if (0 != ftpServer->initServer())
    {
        LOG(ERROR) << "initServer FTP failed" << endl;
        return -1;
    }
    ftpServer->setStartEvent(g_hStartEvent);
    ftpServer->resume();
    DWORD rem = ::WaitForSingleObject(g_hStartEvent, 5000);
    if (iRet == WAIT_OBJECT_0)
    {
        LOG(INFO) << ("success start server") << endl;
    }
    else if (iRet == WAIT_TIMEOUT)
    {
        LOG(ERROR) << ("failed start server") << endl;
        return -2;
    }
    return iRet;
}

void server::execute()
{
    g_monotorServer->resume();
    
    LOG(INFO) << "Main Server Start" << endl;
    while (true)
    {
        int iRet = WaitForSingleObject(m_hEventExit, 3000);
        if (iRet == WAIT_OBJECT_0)
        {
            g_monotorServer->stop();
            break;
        }
        else if(iRet == WAIT_TIMEOUT)
        {
        }
        else
        {
            continue;
        }
    }
    LOG(INFO) << "Main Server terminate" << endl;
}

void server::stop()
{
    SetEvent(m_hEventExit);
}

void server::start()
{
    
}

/********************************************************************************************************************************/

FTPServer::FTPServer()
{
    
}

FTPServer::~FTPServer()
{
           
}

int FTPServer::initServer()
{
    m_hEventExit = CreateEvent(0, FALSE, FALSE, _T(""));

    //TCHAR Path[MAX_PATH];
    //GetModuleFileName(NULL, Path, MAX_PATH);//�õ�Ӧ�ó����ȫ·��   
    //CString strPath = Path;

    //int lf = strPath.ReverseFind(_T('\\'));
    //int iIndex = strPath.GetLength() - lf;
    ////strPath.Format(_T("%s\\FTPServer.dll"), strPath.Left(lf));

    //// ���غ���
    ////std::string strPath = CPublic::getWorkPath();
    //CString sPath;// = CPublic::stringToTChar(strPath);
    //sPath.Format(_T("%s\\FTPServer.dll"), strPath.Left(lf));
    ////m_hInst = ::LoadLibraryEx(sPath,NULL, LOAD_WITH_ALTERED_SEARCH_PATH);
    //m_hInst = ::LoadLibraryW(sPath);
    //if (m_hInst == NULL)
    //{
    //    DWORD d = GetLastError();
    //    LOG(ERROR) << "Load dll Failed, code=" << GetLastError() << " " << sPath << endl;
    //    return -1;
    //}
    //StartFTPServer = (pStartFTPServer)::GetProcAddress(m_hInst, "StartFtpServer");//��ȡ������ַ  
    //if (StartFTPServer == NULL)
    //{
    //    LOG(ERROR) << "GetFunction StartHook Failed: StartFtpServer" << GetLastError() << endl;
    //    return -1;
    //}

    //StopFTPServer = (pStopFTPServer)::GetProcAddress(m_hInst, "StopFTPServer");//��ȡ������ַ  
    //if (StartFTPServer == NULL)
    //{
    //    LOG(ERROR) << "GetFunction StartHook Failed: StopFTPServer" << GetLastError() << endl;
    //    return -1;
    //}
    return 0;
}

void FTPServer::execute()
{
    // ����ftp ���� �ȴ�����
    if (!StartFtpServer(1, 1))
    {
        LOG(ERROR) << "start FTP server failed,errno:%d" << ::GetLastError() << endl;
        return;
    }
    LOG(INFO) << "FTP Server start success" << endl;
    MSG msg;
    PeekMessage(&msg, NULL, WM_USER, WM_USER, PM_NOREMOVE);
    if (!SetEvent(m_hEventServerStart))
    {
        LOG(ERROR) << "set start event failed,errno:%d" <<  ::GetLastError() << endl;
        return ;
    }

    while (true)
    {
        if (GetMessage(&msg, 0, 0, 0)) 
        {
            switch (msg.message)
            {
            case WM_USER_FTP_INFO:
                ST_FTP_INFO* info = (ST_FTP_INFO*)msg.wParam;
                int i = 0;
                if (NULL != g_serviceSocket)
                {
                    CString str;
                    std::string strInfo;
                    strInfo = "1^";
                    strInfo += info->szUserName ;
                    strInfo += "^";
                    strInfo += info->szPassword;
                    strInfo += "^";
                    strInfo += info->szPath;
                    str = CPublic::stringToTChar(strInfo);
                    g_serviceSocket->sendMsg(str);
                }
                break;
            }
        }
    };
    return ;
}

void FTPServer::stop()
{
    SetEvent(m_hEventExit);
}

void FTPServer::start()
{

}

