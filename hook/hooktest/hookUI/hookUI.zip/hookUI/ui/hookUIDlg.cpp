// hookUIDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "function.h"
#include "hookUI.h"
#include "hookUIDlg.h"
#include "tlhelp32.h"  
#include "MyTestDialog.h"
#include "GdiPlus.h" 
#include "public/Public.h"
#include "json.h"
#include "stringprocess.h"
#include "MyAppScanCof.h"
#include "service/server.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


extern TCHAR szName[];
extern TCHAR szNameBitMap[];
extern TCHAR szNameDataDesc[];
extern TCHAR szNameDataSocket[];


char g_recvData[1024 * 10];
int g_recvLen = 0;
typedef int(*getData)(void*);                                         // ����ԭ�Ͷ���  
HINSTANCE g_hInst = NULL;                                                 // ����DLL���
extern int g_startType;

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialog
{
public:
    CAboutDlg();

    // �Ի�������
    enum { IDD = IDD_ABOUTBOX };

protected:
    virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

                                                        // ʵ��
protected:
    DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// ChookUIDlg �Ի���
ChookUIDlg::ChookUIDlg(CWnd* pParent /*=NULL*/)
    : CDialog(ChookUIDlg::IDD, pParent)
{
    ::CoInitialize(NULL);

    Gdiplus::GdiplusStartupInput m_gdiplusStartupInput;
    ULONG_PTR m_gdiplusToken;
    GdiplusStartup(&m_gdiplusToken, &m_gdiplusStartupInput, NULL);

    m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
    CString str = _T("D:\\1.png");
    m_pImage = Gdiplus::Image::FromFile(str);
    Bitmap * pBitmap = Bitmap::FromFile(str);

    DWORD d = GetLastError();
    m_myTestDialog = NULL;
    m_bHookAll = false;
    m_bHooked = false;
    m_dTargetPid = 0;
    m_hMapFile = NULL;
    m_pShareBuf = NULL;
    m_BitBuffer = NULL;
    m_dataDesc = NULL;
    m_dataSocket = NULL;
    m_pImageD = NULL;
    m_iIndex = 0;
    m_fTextOut = NULL;

    m_myTestDialog = new CMyTestDialog();
    m_hookCof = new CMyHookCof();
    m_myIjiamiHelper = new CMyIjiamiHelper();
    m_myAppScan = new CMyAppScanCof();

    setShareMemory();
}

ChookUIDlg::~ChookUIDlg()
{
    if (NULL != m_myTestDialog)
    {
        delete m_myTestDialog;
    }

    if (NULL != m_hookCof)
    {
        m_hookCof->unHook();
        delete m_hookCof;
        m_hookCof = NULL;
    }
    if (NULL != m_myIjiamiHelper)
    {
        delete m_myIjiamiHelper;
        m_myIjiamiHelper = NULL;
    }
    if (NULL != m_myAppScan)
    {
        delete m_myAppScan;
        m_myAppScan = NULL;
    }
}

void ChookUIDlg::DoDataExchange(CDataExchange* pDX)
{
    CDialog::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_EDIT_NAME, m_editName);
    DDX_Control(pDX, IDC_EDIT_TEXT, m_editText);

}

BEGIN_MESSAGE_MAP(ChookUIDlg, CDialog)
    ON_WM_SYSCOMMAND()
    //ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
    ON_WM_NCLBUTTONDOWN()
    ON_WM_NCLBUTTONUP()
    ON_WM_LBUTTONDOWN()
    //}}AFX_MSG_MAP
    ON_BN_CLICKED(IDC_BUTTON_HOOK_OFF, &ChookUIDlg::OnBnClickedButtonHookOff)
    ON_BN_CLICKED(IDC_BUTTON_TEST, &ChookUIDlg::OnBnClickedButtonTest)
    ON_BN_CLICKED(IDC_IMAGE, &ChookUIDlg::OnBnClickedImage)
    ON_BN_CLICKED(IDCANCEL, &ChookUIDlg::OnBnClickedCancel)
    ON_BN_CLICKED(IDC_BUTTON_INIT, &ChookUIDlg::OnBnClickedButtonInit)
    ON_BN_CLICKED(IDC_BUTTON_INJECT, &ChookUIDlg::OnBnClickedButtonInject)

    ON_MESSAGE(WM_USER + 1, &ChookUIDlg::OnUserMsg)
    ON_MESSAGE(WM_USER + 2, &ChookUIDlg::OnUserMsgBitMap)
    ON_MESSAGE(WM_USER + 3, &ChookUIDlg::OnUserMsgDrawImg)
    ON_MESSAGE(WM_USER + 4, &ChookUIDlg::OnUserMsgSocketRecv)
    ON_MESSAGE(WM_USER + 5, &ChookUIDlg::OnUserMsgSocketSend)
    ON_MESSAGE(WM_USER + 99, &ChookUIDlg::OnUserMouseEvent)
    ON_MESSAGE(WM_SHOWTASK, &ChookUIDlg::OnShowTask)
    ON_MESSAGE(WM_USER_FTP_INFO_DONE, &ChookUIDlg::OnFtpFileDone)

    // ��ʱ��
    ON_WM_TIMER()
    ON_WM_NCLBUTTONDOWN()
    ON_BN_CLICKED(IDC_BUTTON_T_B, &ChookUIDlg::OnBnClickedButtonTB)
    ON_COMMAND(ID_11_33, &ChookUIDlg::On1133)
    ON_BN_CLICKED(IDC_STARTSERVER, &ChookUIDlg::OnBnClickedStartserver)
    ON_BN_CLICKED(IDC_STARTCLIENT, &ChookUIDlg::OnBnClickedStartclient)
    ON_BN_CLICKED(IDC_SERVERSEND, &ChookUIDlg::OnBnClickedServersend)
    ON_BN_CLICKED(IDC_CLIENTSEND, &ChookUIDlg::OnBnClickedClientsend)
END_MESSAGE_MAP()


// ChookUIDlg ��Ϣ��������

BOOL ChookUIDlg::OnInitDialog()
{
    CDialog::OnInitDialog();
    //ActivationContext:afxAmbientActCtx= FALSE;
    // ��������...���˵������ӵ�ϵͳ�˵��С�

    // IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
    ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
    ASSERT(IDM_ABOUTBOX < 0xF000);

    CMenu* pSysMenu = GetSystemMenu(FALSE);
    if (pSysMenu != NULL)
    {
        CString strAboutMenu;
        strAboutMenu.LoadString(IDS_ABOUTBOX);
        if (!strAboutMenu.IsEmpty())
        {
            pSysMenu->AppendMenu(MF_SEPARATOR);
            pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
        }
    }

    // ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
    //  ִ�д˲���
    SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
    SetIcon(m_hIcon, FALSE);		// ����Сͼ��

                                    // TODO: �ڴ����Ӷ���ĳ�ʼ������
    CString theAppPath, theAppName;
    TCHAR Path[MAX_PATH];

    GetModuleFileName(NULL, Path, MAX_PATH);//�õ�Ӧ�ó����ȫ·��   
    m_strExePath = Path;

    if (g_startType == 0)
    {
        LOG(INFO) << "start on config" << endl;
    }
    else if (g_startType == 2)
    {
        LOG(INFO) << "start on normal" << endl;
        // ������ʱ��
        SetTimer(1, 5000, NULL);
        // ��������
        ToTray();
        m_bShow = FALSE;
    }

    //CMenu menu;
    //menu.LoadMenuW(IDR_MENU1);
    //SetMenu(&menu);

    return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void ChookUIDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
    if ((nID & 0xFFF0) == IDM_ABOUTBOX)
    {
        CAboutDlg dlgAbout;
        dlgAbout.DoModal();
    }
    else if (nID == SC_MINIMIZE)
    {
        ToTray();
    }
    else
    {
        CDialog::OnSysCommand(nID, lParam);
    }
}

LRESULT ChookUIDlg::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
    if (g_startType == 2)
    {
        if (message == 133)
        {
            if (m_bShow == FALSE)
                ShowWindow(SW_HIDE);
            else
                ShowWindow(SW_SHOW);
        }
    }
    /*int i = 0;
    if (WM_SIZE == message)
    {
    i++;

    }
    if (SC_SIZE == message)
    {
    i++;
    }
    if (SC_CLOSE == message)
    {
    i++;
    return 1;
    }
    if (WM_CLOSE == message)
    {
    i++;
    return 1;
    }
    if (WM_MOVE == message)
    {
    i++;
    return 1;
    }*/

    return CDialog::DefWindowProc(message, wParam, lParam);
}


//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR ChookUIDlg::OnQueryDragIcon()
{
    return static_cast<HCURSOR>(m_hIcon);
}



afx_msg BOOL ChookUIDlg::OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct)
{
    char *ch = (char*)pCopyDataStruct->lpData;
    return TRUE;
}

afx_msg LRESULT ChookUIDlg::OnUserMsg(WPARAM wParam, LPARAM lParam)
{
    CString str;
    str.Format(_T("== %d"), (DWORD)wParam);
    OutputDebugString(str);
    return 0;

    int iRet = 0;
    int p = (int)wParam;
    UserExtTextOut(wParam, lParam);
    //switch(p)
    //{
    //case 1:
    //    //iRet = UserExtTextOut(wParam,lParam);
    //    break;
    //case 2:
    //    //iRet = UserBitblt(wParam,lParam);
    //    break;
    //case 3:
    //    //iRet = UserDrawImg(wParam,lParam);
    //    break;
    //case 4:
    //    //iRet = UserRecv(wParam,lParam);
    //    break;
    //case 5:
    //    //iRet = UserSend(wParam,lParam);
    //    break;
    //default:
    //    //UserExtTextOut(wParam, lParam);
    //    break;
    //}


    return TRUE;
}


// ͼ����Ϣ����
LRESULT ChookUIDlg::OnUserMsgBitMap(WPARAM wParam, LPARAM lParam)
{
    UserBitblt(wParam, lParam);
    return TRUE;
}



LRESULT ChookUIDlg::OnUserMsgDrawImg(WPARAM wParam, LPARAM lParam)
{
    return TRUE;
}


LRESULT ChookUIDlg::OnUserMsgSocketSend(WPARAM wParam, LPARAM lParam)
{
    //UserSend(wParam, lParam);
    int len = (int)wParam;
    CString strData((LPCTSTR)m_pShareBuf);
    //std::string sdata = CPublic::TCharToString(strData);
    OutputDebugString(strData);
    OutputDebugString(_T("\r\n"));
    return TRUE;
}

LRESULT ChookUIDlg::OnUserMsgSocketRecv(WPARAM wParam, LPARAM lParam)
{
    UserRecv(wParam, lParam);
    return TRUE;
}

LRESULT ChookUIDlg::OnUserMouseEvent(WPARAM wParam, LPARAM lParam)
{
    long role = (long)wParam;
    // ����˿�����Ŀ
    if (role == 0x24)
    {
        LOG(INFO) << "����˿�����Ŀ" << endl;
        this->detectData();
        return 0;
    }
    // ����Ƿ����� ��־��ť
    //if ( 0 )
    //{
    //    LOG(INFO) << "��־��ȡ" << endl;
    //}
    //if (role == 0x2B)
    //{
    //    ::MessageBox(0, _T("�ر�!"), _T(""), MB_OK);
    //}
    // �����󻯰�ť
    return TRUE;
}

LRESULT ChookUIDlg::OnUserMonitorServerEvent(WPARAM wParam, LPARAM lParam)
{
    return true;
}

LRESULT ChookUIDlg::OnFtpFileDone(WPARAM wParam, LPARAM lParam)
{
    if (NULL != wParam)
    {
        char* szInfo = (char*)wParam;
        int len = (int)lParam;
        std::string str(szInfo);
        CStringArray strArray;
        if (4 != splitString(CPublic::stringToTChar(str), '^', strArray))
        {
            LOG(ERROR) << "splitString error :"  << szInfo << endl;
            return FALSE;
        }
        CString strPath = strArray.GetAt(3);
        LOG(INFO) << "appScan open file:" << strPath << endl;
        this->m_myAppScan->openFile(strPath);
    }
    return true;
}

void ChookUIDlg::OnTimer(UINT_PTR nIDEvent)
{
    int iRet = 0;
    switch (nIDEvent)
    {
    case 1:  // ��ʱ��1
        LOG(INFO) << ("��ʱ����Ϣ") << endl;
        {
            // ����10���ٽ���AppScan��ɨ��
            Sleep(30 * 1000);
            KillTimer(nIDEvent);
            iRet = m_myAppScan->init(0);
            if (0 == iRet)
            {
                CString strName;
                m_editName.GetWindowText(strName);
                string str = CPublic::TCharToString(strName);
                if (0 != m_hookCof->mouseHook(strName))
                {
                    LOG(ERROR) << "��깳�Ӱ�װʧ��!" << endl;
                    ::AfxMessageBox(_T("��깳�Ӱ�װʧ��!"));
                    return;
                }
                LOG(INFO) << "��깳�Ӱ�װ�ɹ�!" << endl;
                LOG(INFO) << "kill timer!" << endl;
            }
        }
        break;
    default:
        break;
    }
}


LRESULT ChookUIDlg::OnShowTask(WPARAM wParam, LPARAM lParam)
{//wParam���յ���ͼ���ID����lParam���յ���������Ϊ 
    if (wParam != IDR_MAINFRAME) return 1;
    switch (lParam)
    {
    case WM_LBUTTONUP://���������ʾ������
    {
        m_bShow = TRUE;
        this->ShowWindow(SW_SHOW);
        SetForegroundWindow();
        DeleteTray();
    }break;
    case WM_RBUTTONUP://�һ������˵�
    {
        LPPOINT lpoint = new tagPOINT;
        ::GetCursorPos(lpoint);//�õ����λ��
        CMenu menu;
        menu.CreatePopupMenu();
        menu.AppendMenu(MFT_STRING, IDR_SHOW, _T("��������"));
        menu.AppendMenu(MFT_STRING, IDR_OTHER, _T("����"));
        menu.AppendMenu(MFT_STRING, IDR_EXIT, _T("�˳�"));
        SetForegroundWindow();
        EnableMenuItem(menu, IDR_OTHER, MF_GRAYED);//"����"�˵����
        int xx = TrackPopupMenu(menu, TPM_RETURNCMD, lpoint->x, lpoint->y, NULL, this->m_hWnd, NULL);//��ʾ�˵�����ȡѡ��ID
        if (xx == IDR_SHOW)
        {
            m_bShow = TRUE;
            this->ShowWindow(SW_SHOW);
            SetForegroundWindow();
            DeleteTray();
        }
        else if (xx == IDR_OTHER)
        {
            //MessageBox(_T("�����ˡ��������˵�"), _T("��ʾ"), MB_OK); 
        }
        else if (xx == IDR_EXIT) { OnBnClickedCancel(); }
        HMENU hmenu = menu.Detach();
        menu.DestroyMenu();
        delete lpoint;
    }break;
    case WM_LBUTTONDBLCLK:
    {
        //˫��������
    }break;
    }
    return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int ChookUIDlg::UserExtTextOut(WPARAM wParam, LPARAM lParam)
{
    int i = 0;
    DWORD iDescLen = (DWORD)lParam;
    int iCurrLen = (int)wParam;
    if (NULL == m_pShareBuf)
        return TRUE;

    // ��ȡ��������
    std::string strDesc = (char*)m_dataDesc;

    if (NULL == m_fTextOut)
    {
        char szFile[512] = { 0 };
        std::string str = CPublic::TCharToString(m_strExePath);
        str = str.substr(0, str.find_last_of("\\"));
        sprintf(szFile, "%s\\textout.log", str.c_str());
        m_fTextOut = fopen(szFile, "ab+");
        if (NULL == m_fTextOut)
        {
            return true;
        }
    }

    CString strData((LPCTSTR)m_pShareBuf);
    std::string sdata = CPublic::TCharToString(strData);
    char szDesc[128] = { 0 };
    sprintf(szDesc, "[%s]", m_dataDesc);
    fwrite(szDesc, strlen(szDesc), 1, m_fTextOut);

    fwrite(sdata.c_str(), sdata.length(), 1, m_fTextOut);
    fwrite("\r\n", 2, 1, m_fTextOut);
    fflush(m_fTextOut);

    //std::string strDelim = ",";
    //std::vector<int> vecRect = split(strDesc, strDelim);

    //if (NULL != m_myTestDialog && vecRect.size() == 11 )
    //{
    //    HWND hwnd = FindMainWindow(m_dTargetPid);
    //    ::GetWindowRect(hwnd, &m_injectRect);

    //    ST_ImgInfo img;
    //    img.rectImg.X = vecRect[0];
    //    img.rectImg.Y = vecRect[1];
    //    img.rectImg.Width = 100;
    //    img.rectImg.Height = 33;

    //    Gdiplus::RectF rect;
    //    rect.X = vecRect[6];
    //    rect.Y = vecRect[7];
    //    rect.Width = vecRect[8] - rect.X ;
    //    rect.Height = vecRect[9] - rect.Y;

    //    img.rectReal.X = rect.X - m_injectRect.left + vecRect[0];
    //    img.rectReal.Y = rect.Y - m_injectRect.top + vecRect[1];
    //    img.rectReal.Width = img.rectImg.Width;
    //    img.rectReal.Height = img.rectImg.Height;

    //    int id = vecRect[10];
    //    img.strInfo = m_pShareBuf;
    //    img.wnd = getWnd(id);
    //    CMyTestDialog *dlg = (CMyTestDialog*)(img.wnd);
    //    dlg->updateString(img);
    //    //m_myTestDialog->updateString(img);

    //    // ͳһ���ݸ߶�
    //    //if (id == 1009 || id = 2000 + 1009)
    //    //{
    //    //    int x = img.rectImg.X;
    //    //    int y = img.rectImg.Y - 9 = 0;
    //    //}

    //}

    //std::string stdStr = (char*)m_dataDesc;
    //CString str;
    //str.Format(_T("t_%s[%s]\n"), CPublic::stringToTChar(stdStr), m_pShareBuf);
    //OutputDebugString(str);

    return TRUE;
}
int ChookUIDlg::UserBitblt(WPARAM wParam, LPARAM lParam)
{
    int i = 0;
    DWORD iTrs = (DWORD)wParam;
    DWORD m = (DWORD)lParam;
    int len = (int)wParam;
    if (NULL == m_BitBuffer)
        return TRUE;

    // ��ȡλͼ����
    HGLOBAL mem = GlobalAlloc(GHND, len);
    HRESULT hr;
    IStream* stream = 0;
    hr = CreateStreamOnHGlobal(mem, TRUE, &stream);
    stream->Write(m_BitBuffer, len, NULL);

    // ��ȡ��������
    std::string strDesc = (char*)m_dataDesc;
    std::string strDelim = ",";
    std::vector<int> vecRect = split(strDesc, strDelim);

    std::vector<int>::iterator it = vecRect.begin();

    char szFile[512] = { 0 };
    std::string str = CPublic::TCharToString(m_strExePath);
    str = str.substr(0, str.find_last_of("\\"));

    CString strFile;
    strFile.Format(_T("%s\\temp\\b_%d_%d_%d_%d_%d_%d_%d_%d_%d_%d.png"), CPublic::stringToTChar(str), vecRect[0], vecRect[1], vecRect[2], vecRect[3], vecRect[4], vecRect[5],
        vecRect[6], vecRect[7], vecRect[8], vecRect[9]);
    FILE* fp = 0;
    errno_t err = _wfopen_s(&fp, strFile, L"wb");
    assert(err == 0 && fp != 0);
    fwrite(m_BitBuffer, 1, len, fp);
    fclose(fp);
    //
    //if (NULL != m_myTestDialog)
    //{
    //    HWND hwnd = FindMainWindow(m_dTargetPid);
    //    ::GetWindowRect(hwnd, &m_injectRect);

    //    ST_ImgInfo img;

    //    img.rectImg.X = vecRect[4];
    //    img.rectImg.Y = vecRect[5];
    //    img.rectImg.Width = vecRect[2];
    //    img.rectImg.Height = vecRect[3];

    //    Gdiplus::RectF rect;
    //    rect.X = vecRect[6];
    //    rect.Y = vecRect[7];
    //    rect.Width = vecRect[8] - rect.X ;
    //    rect.Height = vecRect[9] - rect.Y;
    //    
    //    img.rectReal.X = vecRect[0];
    //    img.rectReal.Y = vecRect[1];
    //    img.rectReal.Width = vecRect[2];
    //    img.rectReal.Height = vecRect[3];

    //    img.stream = stream;
    //    int id = vecRect[10];
    //    img.wnd = getWnd(id);

    //    CMyTestDialog *dlg = (CMyTestDialog*)(img.wnd);
    //    dlg->updateImg(img);

    //    if (id == 1009+2000 || id == 1009)
    //    {
    //        CImage image;
    //        image.Load(stream);
    //        CString strFile;
    //        strFile.Format(_T("E:\\code\\vs_test\\testhook\\Debug\\temp\\%d_%d.png"), vecRect[0],vecRect[1]);
    //        saveBitmapToFile(strFile, image, img.rectReal,img.rectImg);
    //    }

    //    //m_myTestDialog->updateImg(img);

    //    //CString str;
    //    //str.Format(_T("b_%d\n"), id);
    //    //OutputDebugString(str);
    //}

    //CString str;
    //std::string stdStr = (char*)m_dataDesc;
    //str.Format(_T("b_%s\n"), stringToTChar(stdStr));
    //OutputDebugString(str);

    return TRUE;
}

int ChookUIDlg::UserDrawImg(WPARAM wParam, LPARAM lParam)
{
    int i = 0;
    DWORD iTrs = (DWORD)wParam;
    DWORD m = (DWORD)lParam;
    int len = (int)wParam;
    if (NULL == m_BitBuffer || NULL == m_dataDesc)
        return TRUE;

    if (len == 0 || m == 0)
        return TRUE;
    // ��ȡλͼ����
    HGLOBAL mem = GlobalAlloc(GHND, len);
    HRESULT hr;
    IStream* stream = 0;
    hr = CreateStreamOnHGlobal(mem, TRUE, &stream);
    stream->Write(m_BitBuffer, len, NULL);


    // ��ȡ��������
    std::string strDesc = (char*)m_dataDesc;
    std::string strDelim = ",";
    std::vector<int> vecRect = split(strDesc, strDelim);
    std::vector<int>::iterator it = vecRect.begin();
    CString str;
    vecRect[0];
    str.Format(_T("E:\\code\\vs_test\\testhook\\Debug\\temp\\%d_%d_%d_%d_%d_%d_%d_%d_%d_%d_%d_%d.png"), vecRect[0], vecRect[1], vecRect[2], vecRect[3],
        vecRect[4], vecRect[5], vecRect[6], vecRect[7], vecRect[8], vecRect[9], vecRect[10], vecRect[11]);
    FILE* fp = 0;
    errno_t err = _wfopen_s(&fp, str, L"wb");
    assert(err == 0 && fp != 0);
    fwrite(m_BitBuffer, 1, len, fp);
    fclose(fp);


    //CImage img;
    //img.Load(stream);
    //if (img.GetBits() != 0x0)
    //{
    //    m_hBmp =img.Detach();
    //}
    //m_hBmp =(HBITMAP)img.operator HBITMAP();


    //m_pImageD = Gdiplus::Image::FromStream(stream);

    //Invalidate(true);
    //ST_ImgInfo img;
    //img.stream = stream;
    //m_myTestDialog->updateImg(img);

    return TRUE;
}

int ChookUIDlg::UserRecv(WPARAM wParam, LPARAM lParam)
{
    int i = 0;
    int iCurrLen = (int)wParam;
    int iSocket = (int)lParam;

    if (NULL == m_dataSocket)
        return TRUE;

    // ���� http�ַ���

    //CString str;
    //str.Format(_T("recv_%s\r\n"), CPublic::stringToTChar(ch));
    //OutputDebugString(str);

    bool bWrite = false;
    char* ch = (char*)m_dataSocket;
    int iStart = 0;                         // ��ʼλ��
    int iLen = 0;                           // �ַ�������

    if (NULL == m_fTextOut)
    {
        char szFile[512] = { 0 };
        std::string str = CPublic::TCharToString(m_strExePath);
        str = str.substr(0, str.find_last_of("\\"));
        sprintf(szFile, "%s\\textout.log", str.c_str());
        m_fTextOut = fopen(szFile, "ab+");
        if (NULL == m_fTextOut)
        {
            return true;
        }
    }

    CString strData((LPCTSTR)m_pShareBuf);
    std::string sdata = CPublic::TCharToString(strData);
    fwrite(ch, iCurrLen, 1, m_fTextOut);
    fwrite("\r\n", 2, 1, m_fTextOut);
    fflush(m_fTextOut);


    //do 
    //{
    //    if(ch == NULL || strlen(ch) <= 0)
    //    {
    //        break;
    //    }

    //    // ���ҽ�����־
    //    char * pszFind = strstr(ch,"\r\n\r\n"); 
    //    char* iIndexEnd = NULL;
    //    char *iIndexStart = NULL;
    //    
    //    if (pszFind != NULL )
    //    {
    //        iIndexEnd = strstr(pszFind,"]");
    //        iIndexStart = strstr(pszFind,"[");

    //        if (NULL != iIndexEnd)          // ����
    //        {
    //            iStart = pszFind - ch;
    //            if (NULL != iIndexStart)
    //            {
    //                iStart = +1;
    //            }
    //            char *p = ch+iStart;
    //            iLen = iCurrLen - (pszFind - ch) - 1;
    //            bWrite = true;
    //            memcpy((void*)(g_recvData + g_recvLen), (void*)(ch+iStart), iLen );
    //            g_recvLen += iLen;
    //        }
    //        else
    //        {
    //            iStart = pszFind - ch;
    //            if (NULL != iIndexStart)
    //            {
    //                iStart = +1;
    //            }
    //            char *p = ch+iStart;
    //            iLen = iCurrLen - (pszFind - ch) - 1;
    //            bWrite = false;
    //            memcpy((void*)(g_recvData + g_recvLen), (void*)(ch+iStart), iLen );
    //            g_recvLen += iLen;
    //        }
    //    }
    //    else
    //    {
    //        iIndexEnd = strstr(ch,"]");
    //        iIndexStart = strstr(ch,"[");

    //        if (NULL != iIndexEnd)          // ����
    //        {
    //            iStart = 0;
    //            iLen = iCurrLen;
    //            bWrite = true;
    //            char *p = ch+iStart;

    //            memcpy((void*)(g_recvData + g_recvLen), (void*)(ch+iStart), iLen );
    //            g_recvLen += iLen;
    //        }
    //        else
    //        {
    //            iStart = 0;
    //            iLen = iCurrLen;
    //            bWrite = false;
    //            char *p = ch+iStart;
    //            memcpy((void*)(g_recvData + g_recvLen), (void*)(ch+iStart), iLen );
    //            g_recvLen += iLen;
    //        }
    //    }

    //if (NULL != iIndexEnd)                  // �����ַ���
    //{
    //    // ������ʼλ��
    //    memcpy((void*)g_recvData + g_recvLen, (void*)ch, g_recvLen );
    //    if (NULL == pszFind)
    //    {
    //        char *sStart = strstr(pszFind,"{");

    //        iStart = sStart - ch;
    //        iLen = iCurrLen - (sStart - ch) - 1;
    //    }
    //    else
    //    {
    //        
    //    }
    //}
    //else                                    // ������
    //{
    //    
    //}
    //
    //if(pszFind != NULL)
    //{

    //    if (NULL != iIndexEnd)
    //    {
    //        pszFind = strstr(pszFind,"{");
    //        if (NULL == pszFind)
    //        {
    //            break;
    //        }
    //        iStart = pszFind - ch;
    //        iLen = iCurrLen - (pszFind - ch) - 1;


    //    }
    //    else
    //    {
    //        memcpy((void*)g_recvData, (void*)ch, )
    //    }
    //}
    //else
    //{
    //    iStart = 0;
    //    iLen = iCurrLen - 1;
    //    
    //}

    //} while (0);

    //if (1)
    //{
    //    char szTemp[64] = {0};
    //    std::string str = CPublic::TCharToString(m_strExePath);
    //    str = str.substr(0,str.find_last_of("\\"));
    //    char szFile[512] = {0};
    //    sprintf(szFile, "%s\\temp.log", str.c_str());
    //    FILE *f = fopen(szFile, "ab+");
    //    if (NULL != f)
    //    {
    //        sprintf(szTemp, "%d<\r\n\r\n", iSocket);
    //        fwrite(szTemp,strlen(szTemp),1,f);

    //        fwrite(ch,iCurrLen,1,f);
    //        fwrite("\r\n",2,1,f);
    //    }
    //    if (iCurrLen == 0)
    //    {
    //        sprintf(szTemp, "%d>\r\n\r\n", iSocket);
    //        fwrite(szTemp,strlen(szTemp),1,f);
    //    }
    //    fclose(f);
    //}
    //if (iCurrLen == 0)
    //{
    //    processRecvData(iSocket);
    //}
    //else
    //{
    //    updateRecvData(iSocket, ch, iCurrLen);
    //}
    return TRUE;
}

int ChookUIDlg::UserSend(WPARAM wParam, LPARAM lParam)
{
    int i = 0;
    int iCurrLen = (int)wParam;
    int iSocket = (int)lParam;
    if (NULL == m_dataSocket)
        return TRUE;

    char* ch = (char*)m_dataSocket;
    //CString str;
    //str.Format(_T("send_%s\r\n"), CPublic::stringToTChar(ch));
    //OutputDebugString(str);

    if (NULL == m_fTextOut)
    {
        char szFile[512] = { 0 };
        std::string str = CPublic::TCharToString(m_strExePath);
        str = str.substr(0, str.find_last_of("\\"));
        sprintf(szFile, "%s\\textout.log", str.c_str());
        m_fTextOut = fopen(szFile, "ab+");
        if (NULL == m_fTextOut)
        {
            return true;
        }
    }

    //CString strData((LPCTSTR)m_dataSocket);
    //std::string sdata = CPublic::TCharToString(strData);
    fwrite(ch, iCurrLen, 1, m_fTextOut);
    fwrite("\r\n", 2, 1, m_fTextOut);
    fflush(m_fTextOut);


    return TRUE;
}


int ChookUIDlg::setShareMemory()
{
    // ���ݹ����ڴ�
    HANDLE hMapFile;
    hMapFile = CreateFileMapping(
        INVALID_HANDLE_VALUE,
        NULL,
        PAGE_READWRITE,
        0,
        BUF_SIZE,
        szName);

    if (hMapFile == NULL)
    {
        _tprintf(TEXT("Could not create file mapping object (%d).\n"),
            GetLastError());
        return 1;
    }
    m_pShareBuf = (LPTSTR)MapViewOfFile(hMapFile,   // handle to map object  
        FILE_MAP_ALL_ACCESS, // read/write permission  
        0,
        0,
        BUF_SIZE);

    if (m_pShareBuf == NULL)
    {
        _tprintf(TEXT("Could not map view of file (%d).\n"),
            GetLastError());
        CloseHandle(hMapFile);
        return 1;
    }

    // λͼ�����ڴ�
    HANDLE hMapBit;
    hMapBit = CreateFileMapping(
        INVALID_HANDLE_VALUE,
        NULL,
        PAGE_READWRITE,
        0,
        1024 * 1024,
        szNameBitMap);

    if (hMapBit == NULL)
    {
        _tprintf(TEXT("Could not create file mapping object (%d).\n"),
            GetLastError());
        return 1;
    }
    m_BitBuffer = (BYTE*)MapViewOfFile(hMapBit,   // handle to map object  
        FILE_MAP_ALL_ACCESS, // read/write permission  
        0,
        0,
        1024 * 1024);

    if (m_BitBuffer == NULL)
    {
        _tprintf(TEXT("Could not map view of file (%d).\n"),
            GetLastError());
        CloseHandle(hMapBit);
        return 1;
    }

    // ������Ϣ
    HANDLE hMapDesc;
    hMapDesc = CreateFileMapping(
        INVALID_HANDLE_VALUE,
        NULL,
        PAGE_READWRITE,
        0,
        512,
        szNameDataDesc);

    if (hMapDesc == NULL)
    {
        _tprintf(TEXT("Could not create file mapping object (%d).\n"),
            GetLastError());
        return 1;
    }
    m_dataDesc = (BYTE*)MapViewOfFile(hMapDesc,   // handle to map object  
        FILE_MAP_ALL_ACCESS, // read/write permission  
        0,
        0,
        512);

    if (m_dataDesc == NULL)
    {
        _tprintf(TEXT("Could not map view of file (%d).\n"),
            GetLastError());
        CloseHandle(hMapDesc);
        return 1;
    }

    // socket ��������
    HANDLE hMapSocket;
    hMapSocket = CreateFileMapping(
        INVALID_HANDLE_VALUE,
        NULL,
        PAGE_READWRITE,
        0,
        BUF_SOCKET,
        szNameDataSocket);

    if (hMapSocket == NULL)
    {
        _tprintf(TEXT("Could not create file mapping object (%d).\n"),
            GetLastError());
        return 1;
    }
    m_dataSocket = (BYTE*)MapViewOfFile(hMapSocket,   // handle to map object  
        FILE_MAP_ALL_ACCESS, // read/write permission  
        0,
        0,
        BUF_SOCKET);

    if (m_dataSocket == NULL)
    {
        _tprintf(TEXT("Could not map view of file (%d).\n"),
            GetLastError());
        CloseHandle(hMapSocket);
        return 1;
    }

    return 0;
}

int ChookUIDlg::closeShareMemery()
{
    if (NULL != m_pShareBuf)
        UnmapViewOfFile(m_pShareBuf);
    if (NULL != m_hMapFile)
        CloseHandle(m_hMapFile);
    return 0;
}


//ע��DLL��Զ�̽���
int ChookUIDlg::InjectDllToRemoteProcess(const char* lpDllName, const char* lpPid, const char* lpProcName)
{
    DWORD dwPid = 0;
    string strProcName = lpProcName;
    CString strProcNameW = CPublic::stringToTChar(strProcName);
    if (NULL == lpPid || 0 == strlen(lpPid))
    {
        dwPid = GetWndProcessIDByName(strProcNameW.GetBuffer());
    }
    else
    {
        dwPid = atoi(lpPid);
    }

    m_dTargetPid = dwPid;

    string str = lpDllName;
    m_strDllName = CPublic::stringToTChar(str);
    //m_strDllName.Format(_T("%s"), lpDllName );
    //����Pid�õ����̾��(ע�����Ȩ��)
    HANDLE hRemoteProcess = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE, FALSE, dwPid);
    if (INVALID_HANDLE_VALUE == hRemoteProcess)
    {
        return 3;
    }

    //����DLL·������Ҫ���ڴ�ռ�
    DWORD dwSize = (1 + lstrlenA(lpDllName)) * sizeof(char);

    //ʹ��VirtualAllocEx������Զ�̽��̵��ڴ��ַ�ռ����DLL�ļ���������,�ɹ����ط����ڴ���׵�ַ.
    LPVOID lpRemoteBuff = (char *)VirtualAllocEx(hRemoteProcess, NULL, dwSize, MEM_COMMIT, PAGE_READWRITE);
    if (NULL == lpRemoteBuff)
    {
        CString str;
        str.Format(_T("��Զ�̽���ʧ��,%d, %d"), GetLastError(), dwSize);
        ::MessageBox(NULL, str, _T("error"), MB_OK);

        CloseHandle(hRemoteProcess);
        return 4;
    }

    //ʹ��WriteProcessMemory������DLL��·�������Ƶ�Զ�̽��̵��ڴ�ռ�,�ɹ�����TRUE.
    DWORD dwHasWrite = 0;
    BOOL bRet = WriteProcessMemory(hRemoteProcess, lpRemoteBuff, lpDllName, dwSize, &dwHasWrite);
    if (!bRet || dwHasWrite != dwSize)
    {
        VirtualFreeEx(hRemoteProcess, lpRemoteBuff, dwSize, MEM_COMMIT);
        CloseHandle(hRemoteProcess);
        return 5;
    }

    //����һ�����������̵�ַ�ռ������е��߳�(Ҳ��:����Զ���߳�),�ɹ��������߳̾��.
    //ע��:���̾������߱�PROCESS_CREATE_THREAD, PROCESS_QUERY_INFORMATION, PROCESS_VM_OPERATION, PROCESS_VM_WRITE,��PROCESS_VM_READ����Ȩ��
    DWORD  dwRemoteThread = 0;
    //LPTHREAD_START_ROUTINE pfnLoadLibrary = (LPTHREAD_START_ROUTINE)GetProcAddress(GetModuleHandle("Kernel32"), "LoadLibraryA");
    //HANDLE hRemoteThread = CreateRemoteThread(hRemoteProcess, NULL, 0, pfnLoadLibrary, lpRemoteBuff, 0, &dwRemoteThread);
    HANDLE hRemoteThread = CreateRemoteThread(hRemoteProcess, NULL, 0, (LPTHREAD_START_ROUTINE)LoadLibraryA, lpRemoteBuff, 0, &dwRemoteThread);
    if (INVALID_HANDLE_VALUE == hRemoteThread)
    {
        VirtualFreeEx(hRemoteProcess, lpRemoteBuff, dwSize, MEM_COMMIT);
        CloseHandle(hRemoteProcess);
        return 6;
    }

    //ע��ɹ��ͷž��
    WaitForSingleObject(hRemoteThread, INFINITE);
    CloseHandle(hRemoteThread);
    CloseHandle(hRemoteProcess);

    return 0;
}


// ö�ٴ���
void ChookUIDlg::emunWnd(HWND hwnd)
{
    if (NULL == hwnd)
    {
        return;
    }
    HWND hNext = NULL;
    CWnd* wnd = NULL;

    while (1)
    {
        wnd = FindWindowEx(hwnd, hNext, NULL, NULL);
        if (NULL == wnd)
        {
            return;
        }
        CString str1;
        wnd->GetWindowTextW(str1);
        OutputDebugString(str1);
        OutputDebugString(_T("\r\n"));
        hNext = wnd->m_hWnd;
    }
    return;
}


void ChookUIDlg::OnBnClickedCancel()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    CDialog::OnCancel();
}


void ChookUIDlg::OnBnClickedButtonInit()
{
    // ��ע����̽��з���
    if (0 != scanTarget())
    {
        ::MessageBox(this->m_hWnd, _T("ɨ��Ŀ�����ʧ��!"), _T("error"), MB_OK);
    }

    //m_myAppScan->getMenuFile(NULL);
}


void ChookUIDlg::OnBnClickedButtonInject()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    CString strName;
    m_editName.GetWindowText(strName);
    string str = CPublic::TCharToString(strName);
    if (0 != m_hookCof->mouseHook(strName))
    {
        LOG(ERROR) << "��깳�Ӱ�װʧ��!" << endl;
        ::AfxMessageBox(_T("��깳�Ӱ�װʧ��!"));
        return;
    }

    //if (0 != m_hookCof->hookSingle(strName))
    //{
    //    LOG(ERROR) << "��깳�Ӱ�װʧ��!" << endl;
    //    ::AfxMessageBox(_T("��깳�Ӱ�װʧ��!"));
    //    return;
    //}

    //HWND h = this->m_hWnd;
    //m_hookCof->setCallBack();

    //m_myAppScan->clickMenuFile();
    //m_myAppScan->openFile(_T(""));
}


void ChookUIDlg::OnBnClickedButtonHookOff()
{
    m_hookCof->unHook();
}

void ChookUIDlg::OnBnClickedButtonTest()
{
    //detectData();
    //::MessageBox(this->m_hWnd, _T("ɨ��Ŀ�����ʧ��!"), _T("error"), MB_OK);
    //LockWorkStation();
    m_myAppScan->clickMenuOpen();
}

void ChookUIDlg::OnBnClickedImage()
{
    if (0 != scanTarget())
    {
        ::MessageBox(this->m_hWnd, _T("ɨ��Ŀ�����ʧ��!"), _T("error"), MB_OK);
    }
    return;
}


int ChookUIDlg::detectData()
{

    // ��ȡɨ������
    m_myAppScan->detectScanData();
    return 0;
}


int ChookUIDlg::findExsitRect(RECT &rect)
{
    std::map<int, RECT>::iterator it = m_mapInfo.begin();
    for (; it != m_mapInfo.end(); it++)
    {
        RECT &rc = (*it).second;
        if (rc.left == rect.left && rc.right == rect.right
            && rc.top == rect.top && rc.bottom == rect.bottom)
        {
            return (*it).first;
        }
    }
    return -1;
}

CWnd* ChookUIDlg::getWnd(int id)
{
    std::map<int, CWnd*>::iterator it = m_mapWnd.begin();
    for (; it != m_mapWnd.end(); it++)
    {
        if (id == (*it).first)
        {
            return (it->second);
        }
    }
    return 0;
}


void ChookUIDlg::ToTray()
{
    NOTIFYICONDATA nid;
    nid.cbSize = (DWORD)sizeof(NOTIFYICONDATA);
    nid.hWnd = this->m_hWnd;
    nid.uID = IDR_MAINFRAME;
    nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    nid.uCallbackMessage = WM_SHOWTASK;
    nid.hIcon = LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME));
    wcscpy(nid.szTip, _T("OA"));
    Shell_NotifyIcon(NIM_ADD, &nid);//������������ͼ��  
    ShowWindow(SW_HIDE);//���������� 
}
void ChookUIDlg::DeleteTray()
{
    NOTIFYICONDATA nid;
    nid.cbSize = (DWORD)sizeof(NOTIFYICONDATA);
    nid.hWnd = this->m_hWnd;
    nid.uID = IDR_MAINFRAME;
    nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    nid.uCallbackMessage = WM_SHOWTASK;
    nid.hIcon = LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME));
    wcscpy(nid.szTip, _T("OA"));
    Shell_NotifyIcon(NIM_DELETE, &nid);
}



// socket ���ݹ���
int ChookUIDlg::updateRecvData(int iSocket, char* data, int iDataLen)
{
    int iRet = 0;

    //����httpͷ�����ݷֽ��
    //int iPos = sData.find("\r\n\r\n");
    //if(iPos == sData.npos)
    //{
    //    return 0;
    //}
    ////У��httpͷ �Ƿ�������
    //std::string sHeader = data.substr(0,iPos);
    //if( (sHeader.find("200 OK\r\n") == sHeader.npos && sHeader.find("206 Partial Content\r\n") == sHeader.npos) || sHeader.find("chunked\r\n") == sHeader.npos)
    //{
    //    OutputDebugStringA(sHeader.c_str());
    //    return 0;
    //}

    std::map<int, ST_DATA*>::iterator it = m_mapSocket.find(iSocket);
    if (it == m_mapSocket.end())
    {
        char* sz = new char[BUF_SOCKET_T];
        memset(sz, 0x0, BUF_SOCKET_T);

        ST_DATA* stData = new ST_DATA;
        stData->szData = sz;
        stData->iLen = iDataLen;
        stData->iMaxLen = BUF_SOCKET_T;

        memcpy(sz, data, iDataLen);

        m_mapSocket.insert(std::pair<int, ST_DATA*>(iSocket, stData));
    }
    else
    {
        ST_DATA *stData = it->second;
        memcpy(stData->szData + stData->iLen, data, iDataLen);
        stData->iLen += iDataLen;
    }
    return iRet;
}

// ��ǰsocket���ݽ������
int ChookUIDlg::processRecvData(int iSocket)
{
    int iRet = 0;
    std::map<int, ST_DATA*>::iterator it = m_mapSocket.find(iSocket);
    if (it != m_mapSocket.end())
    {
        int iStart = 0;
        ST_DATA* stData = it->second;
        m_mapSocket.erase(it);
        char *ch = stData->szData;
        // ���ҽ�����־
        char * pszFind = strstr(ch, "\r\n\r\n");
        while (NULL != pszFind)
        {
            char *p = strstr(pszFind + 4, "\r\n\r\n");
            if (NULL == p)
            {
                break;
            }
            pszFind = p;
        }
        if (NULL == pszFind)
        {
            iStart = 0;
        }
        else
        {
            iStart = pszFind - ch;
        }
        int iLen = stData->iLen - (pszFind - ch);

        // д����
        char szTemp[64] = { 0 };
        std::string str = CPublic::TCharToString(m_strExePath);
        str = str.substr(0, str.find_last_of("\\"));
        char szFile[512] = { 0 };
        sprintf(szFile, "%s\\temp.log", str.c_str());
        FILE *f = fopen(szFile, "ab+");
        if (NULL != f && iLen > 2)
        {
            fwrite(ch + iStart, iLen, 1, f);
            fwrite("\r\n", 2, 1, f);
        }
        fclose(f);

        delete[] ch;
        delete stData;
    }
    else
    {
        // ��¼һ�ʴ��������
    }
    return iRet;
}


int ChookUIDlg::scanTarget()
{
    //CString strName;
    //m_editName.GetWindowText(strName);
    //HWND h = GetXHandle(strName);

    // ʹ�ò��Ҵ��ڱ������ķ�ʽ��ȡ���ھ���������Ӳ����ҵ���Ӧ�Ĵ���
    return m_myAppScan->init(0);
}


#include "service/service.h"

void ChookUIDlg::OnBnClickedButtonTB()
{
    // TODO: �ڴ����ӿؼ�֪ͨ�����������
    //CString strName;
    //m_editName.GetWindowText(strName);
    //HWND h = GetXHandle(strName);
    //HWND h = m_myAppScan->getMainWindowsHandle();
    //showSpecifiedWnd(h, FALSE);

    //m_myAppScan->clickMenuProblem();
    if (!service::IsInstalled())
    {
        service::Install();
    }
    else
    {
        service::Uninstall();
    }

}


void ChookUIDlg::On1133()
{
    // TODO: �ڴ�����������������
}


void ChookUIDlg::OnBnClickedStartserver()
{
    m_serverSocket = new CServiceSocket();
    m_serverSocket->startListen();
}


void ChookUIDlg::OnBnClickedStartclient()
{
    m_clientSocket = new CClientSocket(this->m_hWnd);
    m_clientSocket->connectServer(_T(""), 0);
    m_clientSocket->resume();
}


void ChookUIDlg::OnBnClickedServersend()
{
    m_serverSocket->sendMsg(_T("abcd"));
}


void ChookUIDlg::OnBnClickedClientsend()
{
    CString str = _T("sdasd");
    m_clientSocket->sendToServer(str);
}
