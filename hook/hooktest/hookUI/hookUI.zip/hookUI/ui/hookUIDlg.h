// hookUIDlg.h : ͷ�ļ�
//

#pragma once

#define  UM_WNDTITLE WM_USER+100        //�Զ�����Ϣ

#include "dataprocess.h"
#include <GdiPlusEnums.h>
#include "GdiPlus.h" 
#include "MyTestDialog.h"
#include <map>
#include "MyHookCof.h"
#include "MyIjiamiHelper.h"
#include "MyAppScanCof.h"
#include "socket/ClientSocket.h"
#include "socket/ServiceSocket.h"
#include "socket/DataSocket.h"


using namespace std;  
using namespace Gdiplus;  
#pragma comment(lib, "GdiPlus.lib")


// ChookUIDlg �Ի���
class ChookUIDlg : public CDialog
{
    // ����
public:
    ChookUIDlg(CWnd* pParent = NULL);	// ��׼���캯��
    ~ChookUIDlg();
    // �Ի�������
    enum { IDD = IDD_HOOKUI_DIALOG };

protected:
    virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��
    // ʵ��
protected:
    HICON m_hIcon;

    // ���ɵ���Ϣӳ�亯��
    virtual BOOL OnInitDialog();
    afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
    afx_msg LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
    //afx_msg void OnPaint();
    afx_msg HCURSOR OnQueryDragIcon();
    DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnBnClickedCancel();
    afx_msg void OnBnClickedButtonInit();
    afx_msg void OnBnClickedButtonInject();
    afx_msg void OnBnClickedButtonHookOff();
    afx_msg void OnBnClickedButtonTest();
    afx_msg void OnBnClickedImage();
    afx_msg void OnBnClickedButtonTB();
    afx_msg void On1133();
    afx_msg void OnBnClickedStartserver();
    afx_msg void OnBnClickedStartclient();
    afx_msg void OnBnClickedServersend();
    afx_msg void OnBnClickedClientsend();

    afx_msg LRESULT OnUserMsg(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnUserMsgBitMap(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnUserMsgDrawImg(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnUserMsgSocketSend(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnUserMsgSocketRecv(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnUserMouseEvent(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnUserMonitorServerEvent(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnFtpFileDone(WPARAM wParam, LPARAM lParam);
    afx_msg LRESULT OnShowTask(WPARAM wParam, LPARAM lParam);
    afx_msg BOOL OnCopyData(CWnd* pWnd, COPYDATASTRUCT* pCopyDataStruct);
    

    void OnTimer(UINT_PTR nIDEvent);
private:
    int UserExtTextOut(WPARAM wParam, LPARAM lParam);
    int UserBitblt(WPARAM wParam, LPARAM lParam);
    int UserDrawImg(WPARAM wParam, LPARAM lParam);
    int UserRecv(WPARAM wParam, LPARAM lParam);
    int UserSend(WPARAM wParam, LPARAM lParam);

private:
    // ��ȡ����
    int detectData();
    // socket ���ݹ���
    int updateRecvData(int iSocket, char* data, int iDataLen);
    // ��ǰsocket���ݽ������
    int processRecvData(int iSocket);
    // ɨ��Ŀ�����
    int scanTarget();
private:
    // dllע��
    int InjectDllToRemoteProcess(const char* lpDllName, const char* lpPid, const char* lpProcName);
    // �����ڴ����
    int setShareMemory();
    int closeShareMemery();

    // ��ѯ�Ѿ����ڵ� rect
    int findExsitRect(RECT &rect);
    CWnd* getWnd(int id);

    void ToTray();//��С��������
    void DeleteTray();//ɾ������ͼ��

private:
    CString m_strExePath;
    bool m_bHookAll;
    bool m_bHooked;
    CEdit m_editName;
    CEdit m_editText;
    CString m_strDllName;
    DWORD m_dTargetPid;
    LPCTSTR m_pShareBuf;
    BYTE* m_BitBuffer ;
    unsigned char * m_dataDesc;
    unsigned char * m_dataSocket;
    HANDLE m_hMapFile;
    dataprocess m_cDataPrpcess;

    RECT m_injectRect;

    CBitmap m_cBitMap;
    HBITMAP m_hBmp;
    Gdiplus::Image *m_pImage;
    Gdiplus::Image *m_pImageD;
    CMyTestDialog *m_myTestDialog;
    CMyHookCof * m_hookCof;
    CMyIjiamiHelper* m_myIjiamiHelper;
    CMyAppScanCof* m_myAppScan;
    FILE *m_fTextOut;
    BOOL m_bShow;
public:
    void emunWnd(HWND hwnd);
    int m_iIndex;

    std::map<int, RECT> m_mapInfo;
    std::map<int, CWnd*> m_mapWnd;
    typedef struct ST_DATA
    {
        ST_DATA()
        {
            szData = NULL;
            iLen = 0;
            iMaxLen = 0;
            iTime = 0;
        }
        char* szData;
        int iLen;
        int iMaxLen;
        int iTime;
    };
    // socket ����
    std::map<int, ST_DATA*> m_mapSocket;

protected:
    CDataScoket* m_DataSocketE;
    CServiceSocket* m_serverSocket;
    CClientSocket * m_clientSocket;
};
