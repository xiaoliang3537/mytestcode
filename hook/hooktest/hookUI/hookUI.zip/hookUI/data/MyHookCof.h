#pragma once

#include <afxinet.h>
#include <afxhtml.h>
#include <OleAcc.h>
#include <comdef.h>
#include <iostream>
#include <fstream>
#include <vector>
#include "json.h"

using namespace std;

// hook ����
class CMyHookCof
{
public:
    CMyHookCof();
    ~CMyHookCof();
public:
    int init();
    // ����ϵͳapi hook
    int hookAll();
    int hookSingle(CString &strProcessName);
    int unHook();
    int unHookSigle();
    int unHookAll();

    // ϵͳ��Ϣhook
    int mouseHook(CString &strProcessName);
    int mouseUnHook();
    // ���ô�������
    int setProcess(HWND hwnd);

    BOOL setCallBack();
public:
    // dllע��
    int InjectDllToRemoteProcess(const char* lpDllName, const char* lpPid, const char* lpProcName);
private:
    BOOL GetPidByProcessName(LPCTSTR lpszProcessName, DWORD &dwPid);
protected:
    HWND m_hwndProcess;
    int m_iHookType;                        // 0 δhook 1 single 2 all
    bool m_bIsHook;
    DWORD m_dTargetPid;
    CString m_strDllName;
    CString m_strDllPath;
    CString m_strDllMsgPath;
    HINSTANCE m_hInst;
    CString m_strExePath;                   // Ӧ��ִ��·��
};

