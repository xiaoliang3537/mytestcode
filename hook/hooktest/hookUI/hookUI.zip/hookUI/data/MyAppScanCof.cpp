#include "stdafx.h"
#include "MyAppScanCof.h"
#include "public/Public.h"
#include "public/function.h"
#include "loger.h"


CMyAppScanCof::CMyAppScanCof()
{
    CoInitialize(NULL);
    m_stRootNode = NULL;
    m_bInit = false;
    m_hwnd = NULL;
    m_hWndTab = NULL;
    m_hWndScanLog = NULL;
    m_bInitTabCtrl = false;
    m_bInitTableCtrl = false;
    m_iMenuReport = NULL;
    m_iMenuData = NULL;
    m_iMenuProblem = NULL;
    m_iMenuTask = NULL;
    m_iTabIssueInfo = NULL;
    m_iTabfixRecommendation = NULL;
    m_iTabAdvisory = NULL;
    m_iTabRQ = NULL;
    m_iMenuFile = NULL;
    m_iMenuOpen = NULL;
    m_iDlgFileEdit = NULL;
    m_iDlgFileOpen = NULL;

    CFile file;
    CString strFileName;
    char szFile[515] = { 0 };
    std::string strPath = CPublic::getWorkPath();
    m_strWorkPath = CPublic::stringToTChar( strPath );
}


CMyAppScanCof::~CMyAppScanCof()
{
    this->clearUp();
    CoUninitialize();
}

void ResetVarStart(VARIANT& var)
{
    var.vt = VT_I4;
    var.lVal = CHILDID_SELF;
}

HWND CMyAppScanCof::getMainWindowsHandle()
{
    return m_hwnd;
}

int CMyAppScanCof::clickMenuTask()
{
    return clickMenu(m_iMenuTask);
}
int CMyAppScanCof::clickMenuProblem()
{
    return clickMenu(m_iMenuProblem);
}
int CMyAppScanCof::clickMenuData()
{
    return clickMenu(m_iMenuData);
}
int CMyAppScanCof::clickMenuReport()
{
    return clickMenu(m_iMenuReport);
}

int CMyAppScanCof::clickMenuFile()
{
    STARTUPINFO si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));

    si.dwFlags = STARTF_USESHOWWINDOW;  // ָ��wShowWindow��Ա��Ч
    si.wShowWindow = TRUE;          // �˳�Ա��ΪTRUE�Ļ�����ʾ�½����̵������ڣ�

                                    // Get the executable file path
    TCHAR szFilePath[MAX_PATH];
    ::GetModuleFileName(NULL, szFilePath, MAX_PATH);
    //_T("E:\\code\\vs_test\\testhook\\Debug\\hookUI.exe")
    bool b = CreateProcess(szFilePath, _T("-trp"),
        NULL, NULL, FALSE, NULL, NULL,NULL, &si, &pi);

    
    while (1)
    {
        if (0 == getMenuOpenItem())
        {
            break;
        }
        Sleep(1000);
    }
    
    if (NULL != m_iDlgFileEdit)
    {
        VARIANT varId;
        varId.vt = VT_I4;
        varId.lVal = CHILDID_SELF;

        m_iDlgFileEdit->put_accValue(varId, CComBSTR("C:\\Users\\Administrator\\Documents\\AppScan\\3.scan"));
    }
    if (NULL != m_iDlgFileOpen)
    {
        clickMenu(m_iDlgFileOpen);
    }

    return 0;
}

int CMyAppScanCof::clickMenuOpen()
{
    return clickMenu(m_iMenuOpen);
}

int CMyAppScanCof::clickMenu(IAccessible* acc)
{
    // ģ�������ݲ˵�
    HRESULT hr;
    if (NULL != acc)
    {
        VARIANT varId;
        varId.vt = VT_I4;
        varId.lVal = CHILDID_SELF;

        BSTR bstr;
        hr = acc->get_accDefaultAction(varId, &bstr);
        hr = acc->accDoDefaultAction(varId);

        pause();
    }
    return 0;
}

int CMyAppScanCof::getMenuFile(HWND hwd)
{
    int iRet = 0;
    if (NULL == hwd)
    {
        DWORD processID = GetWndProcessIDByName(_T("AppScan.exe"));
        m_hwnd = find_main_window(processID);
    }
    else
        m_hwnd = hwd;

    getMenuItem();
    
    return 0;
}

int CMyAppScanCof::openFile(CString strFile)
{
    STARTUPINFO si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));

    si.dwFlags = STARTF_USESHOWWINDOW;  // ָ��wShowWindow��Ա��Ч
    si.wShowWindow = TRUE;          // �˳�Ա��ΪTRUE�Ļ�����ʾ�½����̵������ڣ�

    TCHAR szFilePath[MAX_PATH];
    ::GetModuleFileName(NULL, szFilePath, MAX_PATH);
    // 0x000B0722 
    DWORD dMain = (DWORD)m_hwnd;
    CString strCmd;
    strCmd.Format(_T("-trp %ld"), dMain);
    //_T("E:\\code\\vs_test\\testhook\\Debug\\hookUI.exe")
    bool b = CreateProcess(szFilePath, strCmd.GetBuffer(),
        NULL, NULL, FALSE, NULL, NULL, NULL, &si, &pi);

    strCmd.ReleaseBuffer();
    bool bOk = false;
    int iCount = 0;
    while (1)
    {
        if (0 == getMenuOpenItem())
        {
            bOk = TRUE;
            break;
        }
        Sleep(1000);
        iCount++;
        if (iCount > 15)
        {
            break;
        }
    }

    if (NULL != m_iDlgFileEdit)
    {
        VARIANT varId;
        varId.vt = VT_I4;
        varId.lVal = CHILDID_SELF;

        //m_iDlgFileEdit->put_accValue(varId, CComBSTR("C:\\Users\\Administrator\\Documents\\AppScan\\3.scan"));
        m_iDlgFileEdit->put_accValue(varId, CComBSTR(strFile));
    }
    if (NULL != m_iDlgFileOpen)
    {
        clickMenu(m_iDlgFileOpen);
    }
    return 0;
}

int CMyAppScanCof::init(HWND hwnd)
{
    int iRet = 0;
    // ����ɨ����־����
    HWND h = GetDesktopWindow();
    if (NULL == m_hwnd)
    {
        DWORD processID = GetWndProcessIDByName(_T("AppScan.exe"));
        m_hwnd = find_main_window(processID);
    }
    // ��һ��ɨ�� ��ȡ��Ҫ�����ֶ��������Ϣ
    getMenuItem();

    // ���˵��Ƿ�����
    if (m_iMenuReport == NULL || m_iMenuProblem == NULL || m_iMenuTask == NULL ||
        m_iMenuData == NULL)
    {
        LOG(ERROR) << ("error get menu") << endl;
        return -2;
    }
    LOG(INFO) << "first scan" << endl;
    // �ڶ���ɨ�� �������˵���ť ����tabѡ�߿�
    clickMenu(m_iMenuProblem);
    getTabItem();
    clickMenu(m_iMenuData);
    clickMenu(m_iMenuTask);

    LOG(INFO) << "second scan" << endl;
    // ������ɨ��
    if (!m_bInitTabCtrl)
    {
        if (0 != findTabControl(m_hWndTab) )
        {
            LOG(INFO) << "findTabControl error" << endl;
            return -2;
        }
        m_bInitTabCtrl = TRUE;
        LOG(INFO) << "��ʼ�� tab �ؼ����ݳɹ�" << endl;
    }
    LOG(INFO) << "third scan" << endl;
    //if (!m_bInitTableCtrl)
    {
        // �������� ��Ҫÿ�ζ�ȥ��ȡ������
        iRet = findScanLogWnd();
        if (0 == iRet)
        {
            LOG(INFO) << "��ʼ�� table �ؼ����ݳɹ�" << endl;
            m_bInitTableCtrl = TRUE;
        }
    }

    return 0;
}

int CMyAppScanCof::clearUp()
{
    std::vector<ST_WndDef*>::iterator it = m_vecWndData.begin();
    for (; it != m_vecWndData.end(); it++)
    {
        ST_WndDef *st = *it;
        delete st;
        st = NULL;
    }
    m_vecWndData.clear();
    m_vecTabChild.clear();
    return 0;
}


int CMyAppScanCof::detectScanData()
{
    this->detectTabCache();
    this->detectTableCache();
    return 0;
}

int CMyAppScanCof::getData()
{
    std::vector<ST_WndDef>::iterator it = m_vecWnd.begin();
    int i = 0;
    for (; it != m_vecWnd.end(); it++)
    {
        ST_WndDef &stWndDef = *it;
        CString str;
        this->GetIHTMLDocument2InterfaceDoc(stWndDef.hwnd, str);
        
        CFile file;
        CString strFileName;
        strFileName.Format(_T("E:\\code\\vs_test\\testhook\\Debug\\%d.txt"), i++);
        
        if (!file.Open(strFileName, CFile::modeCreate | CFile::modeWrite | CFile::typeBinary ))
        {
            DWORD d = GetLastError();
            LOG(ERROR) << "���ļ�ʧ��" << endl;
            continue;
        }

        file.Write(str.GetBuffer(), str.GetLength() * sizeof(TCHAR));

        file.Close();
    }
    return 0;
}

int CMyAppScanCof::getDataRichEdit()
{
    std::vector<ST_WndDef>::iterator it = m_vecWnd.begin();
    int i = 0;
    for (; it != m_vecWnd.end(); it++)
    {
        ST_WndDef &stWndDef = *it;
        CString str;

        CComQIPtr<IAccessible, &IID_IAccessible> m_pAcc;
        IAccessible* pCAcc = NULL;
        HRESULT hr = AccessibleObjectFromWindow(stWndDef.hwnd, OBJID_WINDOW, IID_IAccessible, (void**)&m_pAcc);

        VARIANT varChild;
        VariantInit(&varChild);
        varChild.vt = VT_I4;
        varChild.lVal = CHILDID_SELF;

        m_pAcc->QueryInterface(IID_IAccessible, (void**)&pCAcc);

        BSTR bstr;
        pCAcc->get_accName(varChild, &bstr);
        if (NULL != bstr)
        {
            int i = 0;
        }
        pCAcc->Release();
    }
    return 0;
}

/****************************************************************************
Ѱ��ָ���������Ӵ��ھ��
****************************************************************************/
HWND CMyAppScanCof::FindWithClassName(HWND ParentWnd, TCHAR* FindClassName, bool bAll, int depth )
{
    HWND hChild = ::GetWindow(ParentWnd, GW_CHILD);
    if (NULL == hChild)
    {
        //LOG(ERROR) << "�����Ӷ���ʧ��!" << GetLastError() << endl;
        int i = 0;
    }
    for (; hChild != NULL; hChild = ::GetWindow(hChild, GW_HWNDNEXT))
    {
        TCHAR ClassName[100] = { 0 };
        ::GetClassName(hChild, ClassName, sizeof(ClassName) / sizeof(TCHAR));
        CString str;
        for (int i = 0; i < depth; i++)
            str.Append(L"  ");
        LOG(INFO) << str << CString(ClassName) << endl;
        if (_tcscmp(ClassName, FindClassName) == 0 || _tcsstr(ClassName, FindClassName) != NULL )
        {
            if (!bAll)
            {
                return hChild;
            }
            OutputDebugString(FindClassName); 
        }
        HWND FindWnd = FindWithClassName(hChild, FindClassName, bAll, depth+1);
        if (FindWnd)
        {
            return FindWnd;
        }
    }
    return NULL;
}

HWND CMyAppScanCof::FindWithObjectName(HWND ParentWnd, TCHAR* FindObjectName, int role, bool bAll, int depth )
{
    HWND hChild = ::GetWindow(ParentWnd, GW_CHILD);
    if (NULL == hChild)
    {
        DWORD d = GetLastError();
        int i = 0;
    }
    for (; hChild != NULL; hChild = ::GetWindow(hChild, GW_HWNDNEXT))
    {
        VARIANT varChild;
        varChild.vt = VT_I4;
        varChild.lVal = CHILDID_SELF;
        BSTR bstr;
        CWnd *wnd = CWnd::FromHandle(hChild);
        HRESULT hr = wnd->GetAccessibleName(varChild, &bstr);

        if (hr == S_OK && bstr != NULL)
        {
            if (_tcscmp(bstr, FindObjectName) == 0 || _tcsstr(bstr, FindObjectName) != NULL)
            {
                if ( 0 == role )
                {
                    return hChild;
                }
            }
        }
        HWND FindWnd = FindWithObjectName(hChild, FindObjectName, bAll, depth+1);
        if (FindWnd)
        {
            return FindWnd;
        }
    }
    return NULL;
}

void CMyAppScanCof::GetIHTMLDocument2InterfaceDoc(HWND BrowserWnd, CString &str)
{
    HRESULT hr;
    // Explicitly load MSAA so we know if it's installed
    HINSTANCE hInst = ::LoadLibrary(_T("OLEACC.DLL"));
    if (hInst)
    {
        LRESULT lRes; //SendMessageTimeout��ķ���ֵ�����ں���pfObjectFromLresult�ĵ�1������
        UINT nMsg = ::RegisterWindowMessage(_T("WM_HTML_GETOBJECT"));
        ::SendMessageTimeout(BrowserWnd, nMsg, 0L, 0L, SMTO_ABORTIFHUNG, 1000, (DWORD*)&lRes);
        //��ȡ����pfObjectFromLresult
        LPFNOBJECTFROMLRESULT pfObjectFromLresult = (LPFNOBJECTFROMLRESULT)::GetProcAddress(hInst, ("ObjectFromLresult"));
        if (pfObjectFromLresult)
        {
            CComPtr<IHTMLDocument2> spDoc;
            hr = (*pfObjectFromLresult)(lRes, IID_IHTMLDocument, 0, (void**)&spDoc);
            if (SUCCEEDED(hr))
            {
                //��ȡ�ĵ��ӿ�
                CComPtr<IDispatch> spDisp;
                spDoc->get_Script(&spDisp);
                CComQIPtr<IHTMLWindow2> spWin = spDisp;
                spWin->get_document(&spDoc.p);
                this->detectAppCache(spDoc, str);
            } // else document not ready
        } // else Internet Explorer is not running
        ::FreeLibrary(hInst);
    } // else Active Accessibility is not installed
}

IWebBrowser2* CMyAppScanCof::GetIWebBrowserInterface(HWND BrowserWnd)
{
    IWebBrowser2* pWebBrowser2 = NULL;
    HRESULT hr;
    // Explicitly load MSAA so we know if it's installed
    HINSTANCE hInst = ::LoadLibrary(_T("OLEACC.DLL"));
    if (hInst)
    {
        LRESULT lRes;
        UINT nMsg = ::RegisterWindowMessage(_T("WM_HTML_GETOBJECT"));
        ::SendMessageTimeout(BrowserWnd, nMsg, 0L, 0L, SMTO_ABORTIFHUNG, 1000, (DWORD*)&lRes);

        LPFNOBJECTFROMLRESULT pfObjectFromLresult = (LPFNOBJECTFROMLRESULT)::GetProcAddress(hInst, ("ObjectFromLresult"));
        if (pfObjectFromLresult)
        {
            CComPtr<IServiceProvider> spServiceProv;
            hr = (*pfObjectFromLresult)(lRes, IID_IServiceProvider, 0, (void**)&spServiceProv);
            if (SUCCEEDED(hr))
            {
                hr = spServiceProv->QueryService(SID_SWebBrowserApp,
                    IID_IWebBrowser2, (void**)&pWebBrowser2);
            } // else document not ready
        } // else Internet Explorer is not running
        ::FreeLibrary(hInst);
    } // else Active Accessibility is not installed

      //CoUninitialize(); //��仰Ҫ����������������У����򷵻�ֵ��ʹ���ǿ�ָ��Ҳ��Ч

    return SUCCEEDED(hr) ? pWebBrowser2 : NULL;
}

void CMyAppScanCof::GetObjectName(IAccessible* child, VARIANT* varChild, WCHAR* objName, int len)
{
    BSTR strTmp;
    HRESULT hr = child->get_accName(*varChild, &strTmp);
    if (S_OK != hr || NULL == strTmp)
    {
        return;
    }
    _bstr_t str = strTmp;
    char* tmp = str;
    int lenW = wcslen(strTmp);
    wmemcpy(objName, strTmp, lenW > MAX_PATH? MAX_PATH-1 : lenW);
    SysFreeString(strTmp);
}

void CMyAppScanCof::GetObjectRole(IAccessible* child, VARIANT* varChild, DWORD &id, WCHAR* objRole, int len)
{
    VARIANT pvarRole;
    DWORD roleId;
    child->get_accRole(*varChild, &pvarRole);

    if (varChild->vt != VT_I4)
    {
        pvarRole.vt = VT_EMPTY;
        return /*E_INVALIDARG*/;
    }
    roleId = pvarRole.lVal;
    UINT   roleLength;
    LPWSTR lpszRoleString;

    // Get the length of the string.
    roleLength = GetRoleTextW(roleId, NULL, 0);

    lpszRoleString = (LPWSTR)malloc((roleLength + 1) * sizeof(WCHAR));
    if (lpszRoleString != NULL)
    {
        // Get the string.
        GetRoleTextW(roleId, lpszRoleString, roleLength + 1);
        id = roleId;
    }
    //strcpy_s(objRole, MAX_PATH - 1, tmp);
    wmemcpy(objRole, lpszRoleString, wcslen(lpszRoleString) * sizeof(WCHAR) );
    wsprintf(objRole + wcslen(lpszRoleString+1) * sizeof(WCHAR) , _T("%06x"), roleId);
    free(lpszRoleString);
    return /*S_OK*/;

}

void CMyAppScanCof::GetObjectValue(IAccessible* child, VARIANT* varChild, WCHAR* objValue, int len)
{
    BSTR strTmp;
    HRESULT hr = child->get_accValue(*varChild, &strTmp);
    if (S_OK != hr || NULL == strTmp)
    {
        return;
    }
    _bstr_t str = strTmp;
    char* tmp = str;
    wmemcpy(objValue, strTmp, wcslen(strTmp));
    SysFreeString(strTmp);
}

void CMyAppScanCof::GetObjectClass(IAccessible* child, WCHAR* objClass, int len)
{
    HWND htmp;
    LPWSTR strClass;
    strClass = (LPWSTR)malloc(MAX_PATH);
    ::WindowFromAccessibleObject(child, &htmp);
    if (0 == ::GetClassNameW(htmp, strClass, MAX_PATH))
    {
        free(strClass);
        return;
    }
    if (NULL == htmp)
    {
        return;
    }
    wmemcpy(objClass, strClass, wcslen(strClass));
    free(strClass);
}

UINT CMyAppScanCof::GetObjectState(IAccessible* pacc, VARIANT* pvarChild, LPTSTR lpszState, UINT cchState)
{
    HRESULT hr;
    VARIANT varRetVal;

    *lpszState = 0;

    VariantInit(&varRetVal);

    hr = pacc->get_accState(*pvarChild, &varRetVal);

    if (!SUCCEEDED(hr))
        return(0);

    DWORD dwStateBit;
    int cChars = 0;
    if (varRetVal.vt == VT_I4)
    {
        // ���ݷ��ص�״ֵ̬�����Զ������ӵ��ַ�����
        for (dwStateBit = STATE_SYSTEM_UNAVAILABLE;
            dwStateBit < STATE_SYSTEM_ALERT_HIGH;
            dwStateBit <<= 1)
        {
            if (varRetVal.lVal & dwStateBit)
            {
                cChars += GetStateText(dwStateBit,
                    lpszState + cChars,
                    cchState - cChars);
                *(lpszState + cChars++) = ',';
            }
        }
        if (cChars > 1)
            *(lpszState + cChars - 1) = '"\0"';
    }
    else if (varRetVal.vt == VT_BSTR)
    {
        //WideCharToMultiByte(CP_ACP,
        //    0,
        //    varRetVal.bstrVal,
        //    -1,
        //    lpszState,
        //    cchState,
        //    NULL,
        //    NULL);
    }

    VariantClear(&varRetVal);
    return(lstrlen(lpszState));
}

BOOL CMyAppScanCof::FindChild(IAccessible* paccParent, LPSTR szName, LPSTR szRole, LPSTR szClass,
    IAccessible** paccChild, VARIANT* pvarChild, std::vector<ST_WndDef*> &vecWndData, int depth)
{
    HRESULT hr;
    long numChildren;
    unsigned long numFetched;
    VARIANT varChild;
    int index;
    IAccessible* pCAcc = NULL;
    IEnumVARIANT* pEnum = NULL;
    IDispatch* pDisp = NULL;
    BOOL found = false;
    WCHAR szObjName[1024] = { 0 }, szObjRole[1024] = { 0 }, szObjClass[1024] = { 0 }, szObjState[1024] = { 0 }, szObjValue[1024] = {0};
    DWORD id = 0;
    //�õ�����֧�ֵ�IEnumVARIANT�ӿ�
    hr = paccParent->QueryInterface(IID_IEnumVARIANT, (PVOID*)& pEnum);

    if (pEnum)
        pEnum->Reset();

    //ȡ�ø���ӵ�еĿɷ��ʵ��ӵ���Ŀ
    paccParent->get_accChildCount(&numChildren);
    //�������Ƚ�ÿһ����ID���ҵ����֡���ɫ������������һ�µġ�
    for (index = 1; index <= numChildren && !found; index++)
    {
        pCAcc = NULL;
        // ���֧��IEnumVARIANT�ӿڣ��õ���һ����ID
        //�Լ����Ӧ�� IDispatch �ӿ�
        if (pEnum)
            hr = pEnum->Next(1, &varChild, &numFetched);
        else
        {
            //���һ�����ײ�֧��IEnumVARIANT�ӿڣ���ID�����������
            varChild.vt = VT_I4;
            varChild.lVal = index;
        }

        // �ҵ�����ID��Ӧ�� IDispatch �ӿ�
        if (varChild.vt == VT_I4)
        {
            //ͨ����ID��ŵõ���Ӧ�� IDispatch �ӿ�
            pDisp = NULL;
            hr = paccParent->get_accChild(varChild, &pDisp);
        }
        else
            //�����֧��IEnumVARIANT�ӿڿ���ֱ�ӵõ���IDispatch �ӿ�
            pDisp = varChild.pdispVal;

        // ͨ�� IDispatch �ӿڵõ��ӵ� IAccessible �ӿ� pCAcc
        if (pDisp)
        {
            hr = pDisp->QueryInterface(IID_IAccessible, (void**)&pCAcc);
            hr = pDisp->Release();
        }

        // Get information about the child
        if (pCAcc)
        {
            //�����֧��IAccessible �ӿڣ���ô��ID����CHILDID_SELF
            VariantInit(&varChild);
            varChild.vt = VT_I4;
            varChild.lVal = CHILDID_SELF;

            *paccChild = pCAcc;
        }
        else
        {
            //����Ӳ�֧��IAccessible �ӿ�
            *paccChild = paccParent;
        }
        
        //ͨ��get_accRole�õ�Role
        GetObjectRole(*paccChild, &varChild, id, szObjRole, sizeof(szObjRole));
        //ͨ��WindowFromAccessibleObject��GetClassName�õ�Class
        GetObjectClass(*paccChild, szObjClass, sizeof(szObjClass));
        CFile file;
        CString strFileName;
        strFileName = m_strWorkPath + _T("\\DetoursTest.txt");
        if (file.Open(strFileName, CFile::modeWrite | CFile::modeCreate | CFile::modeNoTruncate ) )
        {
            bool b = false;
            //if (!b)
            {
                if (id == 0x1 || id == 0x2 || id == 0x3 || id == 0x4 || id == 0x0C || id == 0x16 || id == 0x2B
                    || id == 0x27 || id == 0x0C || id == 0x2B)
                {
                    b = true;
                }
            }
            //if (!b)
            {
                //if (id == 0x0a || id == 0x09 || id == 0x24 || id == 0x25 || id == 0x0a || id == 0x0a || id == 0x0a || NULL != wcsstr(szObjClass, _T("WindowsForms10.RichEdit20W.app")) )
                {
                    GetObjectName(*paccChild, &varChild, szObjName, sizeof(szObjName));
                    GetObjectValue(*paccChild, &varChild, szObjValue, sizeof(szObjValue));

                    if (NULL != wcsstr(szObjClass, _T("WindowsForms10.RichEdit20W.app")) )
                    {
                        int i = 0;
                    }
                    file.SeekToEnd();
                    for (int y = 0; y < depth; y++)
                    {
                        file.Write(_T("  "), 2);
                    }
                    file.Write(szObjName, wcslen(szObjName) * sizeof(WCHAR) );
                    file.Write(_T(" | "), 3 * sizeof(WCHAR) );
                    file.Write(szObjClass, wcslen(szObjClass) * sizeof(WCHAR));
                    file.Write(_T(" | "), 3 * sizeof(WCHAR) );
                    file.Write(szObjRole, wcslen(szObjRole) * sizeof(WCHAR));
                    file.Write(_T(" | "), 3 * sizeof(WCHAR) );
                    file.Write(szObjValue, wcslen(szObjValue) * sizeof(WCHAR));
                    file.Write(_T(" | "), 3 * sizeof(WCHAR));
                    CString strDep;
                    strDep.Format(_T("%d"), depth);
                    file.Write(strDep, strDep.GetLength() * sizeof(WCHAR));
                    file.Write(_T("\r\n"), 2);

                    ST_WndDef *def = new ST_WndDef();
                    def->dRole = id;
                    def->pIAcc = *paccChild;
                    def->iDepth = depth;
                    int len = wcslen(szObjClass) * sizeof(WCHAR);
                    wmemcpy(def->szClassName, szObjClass, len );
                    len = wcslen(szObjName) * sizeof(WCHAR);
                    wmemcpy(def->szObjName, szObjName, len > 512 ? 511 : len );
                    hr = WindowFromAccessibleObject(*paccChild, &(def->hwnd));

                    if (S_OK == hr)
                    {
                        // ��ʼ������
                        def->iState = 0;
                    }
                    vecWndData.push_back(def);
                    int iCount = m_vecWndData.size();
                    int t = 0;
                }
            }
            file.Close();
        }
        // �������
        
        if (!found && pCAcc)
        {
            // ����εõ����ӽӿ�Ϊ���ݹ����
            found = FindChild(pCAcc,
                szName,
                szRole,
                szClass,
                paccChild,
                pvarChild, vecWndData, depth + 1);
            if (*paccChild != pCAcc)
                pCAcc->Release();
        }
    }
    if (pEnum)
        pEnum->Release();

    return found;
}

int CMyAppScanCof::FirstScanApp()
{
    int iRet = 0;

    return iRet;
}

int CMyAppScanCof::getMenuItem()
{
    int iRet = 0;

    CComQIPtr<IAccessible, &IID_IAccessible> m_pAcc;
    HRESULT hr = AccessibleObjectFromWindow(m_hwnd, OBJID_WINDOW, IID_IAccessible, (void**)&m_pAcc);
    if (S_OK != hr)
    {
        LOG(ERROR) << "��ȡm_hwnd ʧ��[" << GetLastError() << "]" << endl;
        return -2;
    }

    CComQIPtr<IAccessible> pChild;
    VARIANT variant;
    VariantInit(&variant);
    variant.vt = VT_I4;
    variant.lVal = CHILDID_SELF;
    IDispatch* pDisp = NULL;

    getMenuObject(m_pAcc, "", "", "", &pChild, &variant, 0);
    return iRet;
}

int CMyAppScanCof::getTabItem()
{
    int iRet = 0;
    HRESULT hr;
    // �����ݵ�tab����
    m_hWndTab = FindWithClassName(m_hwnd, _T("WindowsForms10.SysTabControl32.app"), false);
    if (NULL == m_hWndTab)
    {
        ::MessageBox(NULL, _T("��ȡSysTabControl32ʧ��"), _T("error"), MB_OK);
        return -1;
    }

    CComQIPtr<IAccessible, &IID_IAccessible> m_pAcc;
    hr = AccessibleObjectFromWindow(m_hWndTab, OBJID_WINDOW, IID_IAccessible, (void**)&m_pAcc);
    if (S_OK != hr)
    {
        LOG(ERROR) << "��ȡSysTabControl32 ʧ��[" << GetLastError() << "]" << endl;
        return -2;
    }

    CComQIPtr<IAccessible> pChild;
    VARIANT variant;
    VariantInit(&variant);
    variant.vt = VT_I4;
    variant.lVal = CHILDID_SELF;
    IDispatch* pDisp = NULL;

    getTabObject(m_pAcc, "", "", "", &pChild, &variant, 0);
    return iRet;
}

int CMyAppScanCof::getTabObject(IAccessible* paccParent, LPSTR szName, LPSTR szRole, LPSTR szClass,
    IAccessible** paccChild, VARIANT* pvarChild, int depth)
{
    HRESULT hr;
    long numChildren;
    unsigned long numFetched;
    VARIANT varChild;
    int index;
    IAccessible* pCAcc = NULL;
    IEnumVARIANT* pEnum = NULL;
    IDispatch* pDisp = NULL;
    BOOL found = false;
    WCHAR szObjName[1024] = { 0 }, szObjRole[1024] = { 0 };
    DWORD id = 0;
    hr = paccParent->QueryInterface(IID_IEnumVARIANT, (PVOID*)& pEnum);

    if (pEnum)
        pEnum->Reset();
    paccParent->get_accChildCount(&numChildren);
    for (index = 1; index <= numChildren && !found; index++)
    {
        pCAcc = NULL;
        if (pEnum)
            hr = pEnum->Next(1, &varChild, &numFetched);
        else
        {
            varChild.vt = VT_I4;
            varChild.lVal = index;
        }

        if (varChild.vt == VT_I4)
        {
            pDisp = NULL;
            hr = paccParent->get_accChild(varChild, &pDisp);
        }
        else
            pDisp = varChild.pdispVal;

        if (pDisp)
        {
            hr = pDisp->QueryInterface(IID_IAccessible, (void**)&pCAcc);
            hr = pDisp->Release();
        }

        if (pCAcc)
        {
            VariantInit(&varChild);
            varChild.vt = VT_I4;
            varChild.lVal = CHILDID_SELF;
            *paccChild = pCAcc;
        }
        else
        {
            *paccChild = paccParent;
        }
        memset(szObjRole, 0x0, 1024);
        memset(szObjName, 0x0, 1024);
        GetObjectRole(*paccChild, &varChild, id, szObjRole, sizeof(szObjRole));
        GetObjectName(*paccChild, &varChild, szObjName, sizeof(szObjName));

        if (id == 0x25)         // ��ť
        {
            if (0 == wcscmp(szObjName, _T("������Ϣ")))
            {
                (*paccChild)->accDoDefaultAction(varChild);
                pause();
            }
            else if (0 == wcscmp(szObjName, _T("��ѯ")))
            {
                (*paccChild)->accDoDefaultAction(varChild);
                pause();
            }
            else if (0 == wcscmp(szObjName, _T("�޶�����")))
            {
                (*paccChild)->accDoDefaultAction(varChild);
                pause();
            }
            else if (0 == wcscmp(szObjName, _T("����/��Ӧ")))
            {
                hr = (*paccChild)->accDoDefaultAction(varChild);
                pause();
            }
        }
        if (!found && pCAcc)
        {
            // ����εõ����ӽӿ�Ϊ���ݹ����
            found = getTabObject(pCAcc,
                szName,
                szRole,
                szClass,
                paccChild,
                pvarChild, depth + 1);
            if (*paccChild != pCAcc)
                pCAcc->Release();
        }
    }
    if (pEnum)
        pEnum->Release();

    return found;
}

BOOL CMyAppScanCof::getMenuObject(IAccessible* paccParent, LPSTR szName, LPSTR szRole, LPSTR szClass,
    IAccessible** paccChild, VARIANT* pvarChild, int depth )
{
    HRESULT hr;
    long numChildren;
    unsigned long numFetched;
    VARIANT varChild;
    int index;
    IAccessible* pCAcc = NULL;
    IEnumVARIANT* pEnum = NULL;
    IDispatch* pDisp = NULL;
    BOOL found = false;
    WCHAR szObjName[1024] = { 0 }, szObjRole[1024] = { 0 };
    DWORD id = 0;
    hr = paccParent->QueryInterface(IID_IEnumVARIANT, (PVOID*)& pEnum);

    if (pEnum)
        pEnum->Reset();
    paccParent->get_accChildCount(&numChildren);
    for (index = 1; index <= numChildren && !found; index++)
    {
        pCAcc = NULL;
        if (pEnum)
            hr = pEnum->Next(1, &varChild, &numFetched);
        else
        {
            varChild.vt = VT_I4;
            varChild.lVal = index;
        }

        if (varChild.vt == VT_I4)
        {
            pDisp = NULL;
            hr = paccParent->get_accChild(varChild, &pDisp);
        }
        else
            pDisp = varChild.pdispVal;

        if (pDisp)
        {
            hr = pDisp->QueryInterface(IID_IAccessible, (void**)&pCAcc);
            hr = pDisp->Release();
        }

        if (pCAcc)
        {
            VariantInit(&varChild);
            varChild.vt = VT_I4;
            varChild.lVal = CHILDID_SELF;
            *paccChild = pCAcc;
        }
        else
        {
            *paccChild = paccParent;
        }
        memset(szObjRole, 0x0, 1024);
        memset(szObjName, 0x0, 1024);
        GetObjectRole(*paccChild, &varChild, id, szObjRole, sizeof(szObjRole));
        GetObjectName(*paccChild, &varChild, szObjName, sizeof(szObjName));
        if (id == 0x2B)         // ��ť
        {
            if (0 == wcscmp(szObjName, _T("����")))
            {
                m_iMenuReport = *paccChild;
            }
            if (0 == wcscmp(szObjName, _T("����")))
            {
                m_iMenuData = *paccChild;
            }
            if (0 == wcscmp(szObjName, _T("����")))
            {
                m_iMenuTask = *paccChild;
            }
            if (0 == wcscmp(szObjName, _T("����")))
            {
                m_iMenuProblem = *paccChild;
            }
        }
        if (id == 0x0C )
        {
            if (0 == wcscmp(szObjName, _T("�ļ�(F)")))
            {
                m_iMenuFile = *paccChild;
                HWND hwd;
                HRESULT hr = WindowFromAccessibleObject(m_iMenuFile, &hwd);
            }
            if (0 == wcscmp(szObjName, _T("��(O)...")))
            {
                m_iMenuOpen = *paccChild;
                HWND hwd;
                HRESULT hr = WindowFromAccessibleObject(m_iMenuFile, &hwd);
            }
            
        }
        if (!found && pCAcc)
        {
            // ����εõ����ӽӿ�Ϊ���ݹ����
            found = getMenuObject(pCAcc,
                szName,
                szRole,
                szClass,
                paccChild,
                pvarChild, depth + 1);
            if (*paccChild != pCAcc)
                pCAcc->Release();
        }
    }
    if (pEnum)
        pEnum->Release();

    return found;
}

HRESULT CMyAppScanCof::WalkTreeWithAccessibleChildren(IAccessible* pAcc, int depth)
{
    HRESULT hr;
    long childCount;
    long returnCount;
    WCHAR szObjName[1024] = { 0 }, szObjRole[1024] = { 0 }, szObjClass[1024] = { 0 }, szObjState[1024] = { 0 }, szObjValue[1024] = {0};
    DWORD id = 0;
    if (!pAcc)
    {
        return E_INVALIDARG;
    }
    hr = pAcc->get_accChildCount(&childCount);
    if (FAILED(hr))
    {
        return hr;
    };
    if (childCount == 0)
    {
        return S_FALSE;
    }
    VARIANT* pArray = new VARIANT[childCount];
    hr = AccessibleChildren(pAcc, 0L, childCount, pArray, &returnCount);
    if (FAILED(hr))
    {
        delete[] pArray;
        return hr;
    };

    // Iterate through children.
    for (int x = 0; x < returnCount; x++)
    {
        VARIANT vtChild = pArray[x];
        WCHAR *ch = vtChild.bstrVal;
        // If it's an accessible object, get the IAccessible, and recurse.
        if (vtChild.vt == VT_DISPATCH)
        {
            IDispatch* pDisp = vtChild.pdispVal;
            IAccessible* pChild = NULL;
            hr = pDisp->QueryInterface(IID_IAccessible, (void**)&pChild);
            if (hr == S_OK)
            {
                GetObjectName(pChild, &vtChild, szObjName, sizeof(szObjName));
                GetObjectRole(pChild, &vtChild, id, szObjRole, sizeof(szObjRole));
                ////ͨ��WindowFromAccessibleObject��GetClassName�õ�Class
                GetObjectClass(pChild, szObjClass, sizeof(szObjClass));
                GetObjectValue(pChild, &vtChild, szObjValue, sizeof(szObjValue));

                CFile file;
                if (file.Open(_T("E:\\code\\vs_test\\testhook\\Debug\\DetoursTest.txt"), CFile::modeWrite | CFile::modeCreate | CFile::modeNoTruncate))
                {
                    file.SeekToEnd();
                    bool b = false;
                    {
                        for (int y = 0; y < depth; y++)
                        {
                            file.Write(_T( "  "), 2);
                        }

                        file.Write(szObjName, wcslen(szObjName) * sizeof(WCHAR));
                        file.Write(_T(" | "), 3 * sizeof(WCHAR));
                        file.Write(szObjClass, wcslen(szObjClass) * sizeof(WCHAR));
                        file.Write(_T(" | "), 3 * sizeof(WCHAR));
                        file.Write(szObjRole, wcslen(szObjRole) * sizeof(WCHAR));
                        file.Write(_T(" | "), 3 * sizeof(WCHAR));
                        file.Write(szObjValue, wcslen(szObjValue) * sizeof(WCHAR));
                        file.Write(_T(" | "), 3 * sizeof(WCHAR));
                        CString strDep;
                        strDep.Format(_T("%d"), depth);
                        file.Write(strDep, strDep.GetLength() * sizeof(WCHAR));
                        file.Write(_T("\r\n"), 2);
                    }
                }
                file.Close();

                WalkTreeWithAccessibleChildren(pChild, depth + 1);

                pChild->Release();
            }
            pDisp->Release();
        }
        // Else it's a child element so we have to call accNavigate on the parent,
        //   and we do not recurse because child elements can't have children.
        else
        {
            CFile file;
            if (file.Open(_T("E:\\code\\vs_test\\testhook\\Debug\\DetoursTest.txt"), CFile::modeWrite | CFile::modeCreate | CFile::modeNoTruncate))
            {

            }
            for (int y = 0; y < depth; y++)
            {
                file.Write(_T("  "), 2);
            }

            file.Write(szObjName, wcslen(szObjName) * sizeof(WCHAR));
            file.Write(_T(" | "), 3 * sizeof(WCHAR));
            file.Write(szObjClass, wcslen(szObjClass) * sizeof(WCHAR));
            file.Write(_T(" | "), 3 * sizeof(WCHAR));
            file.Write(szObjRole, wcslen(szObjRole) * sizeof(WCHAR));
            file.Write(_T(" | "), 3 * sizeof(WCHAR));
            file.Write(szObjValue, wcslen(szObjValue) * sizeof(WCHAR));
            file.Write(_T(" | "), 3 * sizeof(WCHAR));
            file.Close();
        }
    }
    delete[] pArray;
    return S_OK;
}



// �����������д���
BOOL CMyAppScanCof::TraverseWnd(IAccessible* paccParent, ST_Node* stNode, IAccessible** paccChild, VARIANT* pvarChild)
{
    HRESULT hr;
    long numChildren;
    unsigned long numFetched;
    VARIANT varChild;
    
    int index;
    IAccessible* pCAcc = NULL;
    IEnumVARIANT* pEnum = NULL;
    IDispatch* pDisp = NULL;
    BOOL found = false;
    WCHAR szObjName[1024] = { 0 }, szObjRole[1024] = { 0 }, szObjClass[1024] = { 0 }, szObjState[1024] = { 0 };
    DWORD id = 0;
    //�õ�����֧�ֵ�IEnumVARIANT�ӿ�
    hr = paccParent->QueryInterface(IID_IEnumVARIANT, (PVOID*)& pEnum);

    if (pEnum)
        pEnum->Reset();

    //ȡ�ø���ӵ�еĿɷ��ʵ��ӵ���Ŀ
    paccParent->get_accChildCount(&numChildren);

    //�������Ƚ�ÿһ����ID���ҵ����֡���ɫ������������һ�µġ�
    for (index = 1; index <= numChildren && !found; index++)
    {
        pCAcc = NULL;
        // ���֧��IEnumVARIANT�ӿڣ��õ���һ����ID
        //�Լ����Ӧ�� IDispatch �ӿ�
        if (pEnum)
            hr = pEnum->Next(1, &varChild, &numFetched);
        else
        {
            //���һ�����ײ�֧��IEnumVARIANT�ӿڣ���ID�����������
            varChild.vt = VT_I4;
            varChild.lVal = index;
        }

        // �ҵ�����ID��Ӧ�� IDispatch �ӿ�
        if (varChild.vt == VT_I4)
        {
            //ͨ����ID��ŵõ���Ӧ�� IDispatch �ӿ�
            pDisp = NULL;
            hr = paccParent->get_accChild(varChild, &pDisp);
        }
        else
            //�����֧��IEnumVARIANT�ӿڿ���ֱ�ӵõ���IDispatch �ӿ�
            pDisp = varChild.pdispVal;

        // ͨ�� IDispatch �ӿڵõ��ӵ� IAccessible �ӿ� pCAcc
        if (pDisp)
        {
            hr = pDisp->QueryInterface(IID_IAccessible, (void**)&pCAcc);
            hr = pDisp->Release();
        }

        // Get information about the child
        if (pCAcc)
        {
            //�����֧��IAccessible �ӿڣ���ô��ID����CHILDID_SELF
            VariantInit(&varChild);
            varChild.vt = VT_I4;
            varChild.lVal = CHILDID_SELF;

            *paccChild = pCAcc;
        }
        else
            //����Ӳ�֧��IAccessible �ӿ�
            *paccChild = paccParent;

        //ͨ��get_accName�õ�Name
        GetObjectName(*paccChild, &varChild, szObjName, sizeof(szObjName));
        //ͨ��get_accRole�õ�Role
        GetObjectRole(*paccChild, &varChild, id, szObjRole, sizeof(szObjRole));
        //ͨ��WindowFromAccessibleObject��GetClassName�õ�Class
        GetObjectClass(*paccChild, szObjClass, sizeof(szObjClass));

        ST_Node *stNodeChild = new ST_Node();
        _bstr_t bstr = szObjName;

        wmemcpy(stNodeChild->szCtrName, bstr, wcslen(bstr)<MAX_CTR_NAME_SIZE?wcslen(bstr):MAX_CTR_NAME_SIZE);
        bstr = szObjClass;
        wmemcpy(stNodeChild->szClassName, bstr, wcslen(bstr)<MAX_CLASS_NAME_SIZE ? wcslen(bstr) : MAX_CLASS_NAME_SIZE);
        stNodeChild->parent = stNode;

        WindowFromAccessibleObject(pCAcc, &stNodeChild->hwnd);
        stNode->child.push_back( stNodeChild );

        if (!found && pCAcc)
        {
            // ����εõ����ӽӿ�Ϊ���ݹ����
            found = TraverseWnd(pCAcc, stNodeChild, paccChild,pvarChild);
            if (*paccChild != pCAcc)
                pCAcc->Release();
        }
    }

    if (pEnum)
        pEnum->Release();

    return found;
}

int CMyAppScanCof::TraverseParent(HWND hwnd, CString &str)
{
    CWnd *wnd = CWnd::FromHandle(hwnd);
    LPTSTR pszName = NULL;
    DWORD id = 0;
    while (true)
    {
        CWnd *p = wnd->GetParent();
        if (NULL == p)
        {
            break;
        }
        wnd = p;

        VARIANT varChild;
        VARIANT varChild1;
        VariantInit(&varChild);
        VariantInit(&varChild1);

        varChild.vt = VT_I4;
        varChild.lVal = CHILDID_SELF;

        CComPtr<IDispatch> spDisp;
        wnd->GetAccessibleName(varChild, &pszName);

        CComQIPtr<IAccessible, &IID_IAccessible> m_pAcc;
        IAccessible* pCAcc = NULL;
        HRESULT hr = AccessibleObjectFromWindow(wnd->m_hWnd, OBJID_WINDOW, IID_IAccessible, (void**)&m_pAcc);
        if (S_OK == hr)
        {
            // ���ﲻ��ôʹ�� m_pAss���쳣����
            hr = m_pAcc->QueryInterface(IID_IAccessible, (void**)&pCAcc);
            WCHAR sz[1024] = { 0 };
            int len = 0;
            GetObjectRole(pCAcc, &varChild,id, sz, len);
            pCAcc->Release();
        }
        if (NULL == pszName)
        {
            continue;
        }
        str.Format(_T("%s"), pszName);
        if (str.GetLength() != 0 && (str.Compare(_T("NULL")) != 0) && (0 != str.Compare(_T("none"))))
        {
            break;
        }
    }
    return 0;
}


int CMyAppScanCof::detectAppCache(CComPtr<IHTMLDocument2> &pDocument, CString &str)
{
    CComPtr<IHTMLElementCollection> spHTML;
    HRESULT hr = pDocument->get_all(&spHTML);
    long length = 0;
    spHTML->get_length(&length);

    if (hr == S_OK && spHTML != NULL) {
        for (int i = 0; i < length; i++) {//ע��һ�£�����i=1�Ϳ��Ի���ձ����������Դ����
            CComVariant svarIndex = i;
            CComVariant svarEmpty;
            CComPtr<IDispatch> spDisp;

            hr = spHTML->item(svarIndex, svarEmpty, &spDisp);
            if (SUCCEEDED(hr)) {
                CComQIPtr<IHTMLElement> spElement = spDisp;
                if (spElement) {
                    CComBSTR bstrHTML;
                    spElement->get_outerHTML(&bstrHTML);
                    USES_CONVERSION;
                    CString ret = COLE2T(bstrHTML);
                    if (ret.Find(_T("appcache")) != -1) {
                    }
                    str += ret;
                    if (str.Find(_T("</html>")) >= 0 || str.Find(_T("</HTML>")) >= 0)
                    {
                        break;
                    }
                }
            }
            else {
                LOG(ERROR) << "��ȡIDispatchʧ��" << endl;;
            }
        }
    }
    return 0;
}

int CMyAppScanCof::getWebCache(ST_WndDef* st, std::string &str)
{
    if (NULL == st)
    {
        return 0;
    }
    std::string strTitle;
    CString strContent;
    CWnd *wnd = CWnd::FromHandle(st->hwnd);
    CComQIPtr<IAccessible, &IID_IAccessible> pAcc;
    IAccessible* pCAcc = NULL;
    HRESULT hr = AccessibleObjectFromWindow(st->hwnd, OBJID_WINDOW, IID_IAccessible, (void**)&pAcc);
    if (S_OK != hr)
    {
        LOG(ERROR) << "��ȡweb acc acc ʧ��[" << GetLastError() << "]" << endl;
        return -2;
    }

    VARIANT variant;
    variant.vt = VT_I4;
    variant.lVal = CHILDID_SELF;
    BSTR bstr;
    hr = pAcc->get_accName(variant, &bstr);
    if (S_OK != hr)
    {
        return 0;
    }
    // ������Ϣ
    CString csTitle = bstr;
    if (csTitle.Find(_T("issueInformation_0.html")) >= 0 || csTitle.Find(_T("issueInformation_1.html")) >= 0)
    {
        strTitle = ("issueInformation");
    }
    // �޶�����
    if (csTitle.Find(_T("fixRecommendation_0.html")) >= 0 | csTitle.Find(_T("fixRecommendation_1.html")) >= 0)
    {
        strTitle = ("fixRecommendation");
    }
    // ��ѯ
    if (csTitle.Find(_T("advisory_0.html")) >= 0 || csTitle.Find(_T("advisory_1.html")) >= 0 )
    {
        strTitle = ("advisory");
    }
    GetIHTMLDocument2InterfaceDoc(st->hwnd, strContent);
    
    st->jsonValue[strTitle] = Json::Value(strContent);

    return 0;
}

// ���Ҹ��ı���ؼ�
int CMyAppScanCof::findRichEditCtr(HWND ParentWnd)
{
    // WindowsForms10.RichEdit20W.app.0.3ce0bb8_r14_ad1  0x2A
    CComQIPtr<IAccessible, &IID_IAccessible> m_pAcc;
    HRESULT hr = AccessibleObjectFromWindow(ParentWnd, OBJID_WINDOW, IID_IAccessible, (void**)&m_pAcc);
    if (S_OK != hr)
    {
        LOG(ERROR) << "��ȡrich edit acc ʧ��[" << GetLastError() << "]" << endl;
        return -1;
    }
    // �ҵ� ������ѡ�  WindowsForms10.SysTabControl32.app.0.3ce0bb8_r14_ad1
    
    IAccessible* pcAcc = NULL;
    hr = m_pAcc->QueryInterface(IID_IAccessible, (void**)&pcAcc);
    if (S_OK != hr)
    {
        LOG(ERROR) << "��ȡrich edit acc ʧ��[" << GetLastError() << "]" << endl;
        return -1;
    }
    return 0;
}

// ��ȡ���ı�������
int CMyAppScanCof::getRichEditCache(ST_WndDef* st, std::string &str)
{
    if (NULL == st)
    {
        return 0;
    }
    CWnd *wnd = CWnd::FromHandle(st->hwnd);
    CComQIPtr<IAccessible, &IID_IAccessible> pAcc;
    IAccessible* pCAcc = NULL;
    IAccessible* pCAcc1 = NULL;
    HRESULT hr = AccessibleObjectFromWindow(st->hwnd, OBJID_CLIENT, IID_IAccessible, (void**)&pAcc);
    if (S_OK != hr)
    {
        LOG(ERROR) << "��ȡrich edit acc ʧ��[" << GetLastError() << "]" << endl;
        return -2;
    }

    VARIANT variant;
    variant.vt = VT_I4;
    variant.lVal = CHILDID_SELF;
    BSTR bstr;
    hr = pAcc->QueryInterface(IID_IAccessible, (void**)&pCAcc1);
    if (S_OK != hr)
    {
        LOG(ERROR) << "��ȡrich edit acc ʧ��[" << GetLastError() << "]" << endl;
        return 0;
    }

    hr = pCAcc1->get_accValue(variant, &bstr);
    if (S_OK != hr || bstr == NULL)
    {
        LOG(ERROR) << "��ȡrich edit get_accValue ʧ��[" << GetLastError() << "]" << endl;
        return 0;
    }

    st->jsonValue["rich"] = Json::Value(bstr);
    
    return 0;
}
// �����ı��༭��ؼ�
int CMyAppScanCof::findEditCtr(HWND ParentWnd)
{

    return 0;
}
// ��ȡ�ı�������  ������Ĭ�� ������Ӧ��
int CMyAppScanCof::getEditCache(ST_WndDef* st, std::string &str)
{
    if (NULL == st)
    {
        return 0;
    }
    CWnd *wnd = CWnd::FromHandle(st->hwnd);
    CComQIPtr<IAccessible, &IID_IAccessible> pAcc;
    IAccessible* pCAcc = NULL;
    HRESULT hr = AccessibleObjectFromWindow(st->hwnd, OBJID_WINDOW, IID_IAccessible, (void**)&pAcc);
    if (S_OK != hr)
    {
        LOG(ERROR) << "��ȡedit acc ʧ��[" << GetLastError() << "]" << endl;
        return -2;
    }

    VARIANT variant;
    variant.vt = VT_I4;
    variant.lVal = CHILDID_SELF;
    BSTR bstr;
    hr = pAcc->get_accName(variant, &bstr);
    if (S_OK != hr || bstr == NULL)
    {
        LOG(ERROR) << "��ȡedit get_accName ʧ��[" << GetLastError() << "]" << endl;
        return 0;
    }

    st->jsonValue["edit"] = Json::Value(bstr);

    return 0;
}

// ��ȡĿ��������
HWND CMyAppScanCof::GetMainWnd()
{
    return NULL;
}

// ����tab�ؼ�
HWND CMyAppScanCof::FinTabCtr(HWND hParent, TCHAR* FindClassName)
{
    HWND hChild = ::GetWindow(hParent, GW_CHILD);
    if (NULL == hChild)
    {
        DWORD d = GetLastError();
        int i = 0;
    }
    for (; hChild != NULL; hChild = ::GetWindow(hChild, GW_HWNDNEXT))
    {
        TCHAR ClassName[100] = { 0 };
        ::GetClassName(hChild, ClassName, sizeof(ClassName) / sizeof(TCHAR));
        if (_tcscmp(ClassName, FindClassName) == 0)
        {
            m_wndTabCtr = hChild;
            return hChild;
        }
        HWND FindWnd = FinTabCtr(hChild, FindClassName);
        if (FindWnd)
        {
            return FindWnd;
        }
    }
    return NULL;
}

int CMyAppScanCof::FindTabWebCtr(HWND hParent)
{
    if (NULL != m_wndTabCtr)
    {
        FindWithClassName(m_wndTabCtr, _T("Internet Explorer_Server"));
    }
    return 0;
}

// ����tab�����еı༭��  WindowsForms10.Window.8.app.0.3ce0bb8_r14_ad1 0X2A
int CMyAppScanCof::FindTabEditCtr(HWND hParent)
{
    if (NULL != m_wndTabCtr)
    {
        FindWithClassName(m_wndTabCtr, _T("Internet Explorer_Server"));
    }
    return 0;
}

// ����tab�����еĸ��ı���
int CMyAppScanCof::FindTabRichCtr(HWND hParent)
{
    if (NULL != m_wndTabCtr)
    {
        FindWithClassName(m_wndTabCtr, _T("WindowsForms10.RichEdit20W.app.0.3ce0bb8_r14_ad1"));
    }
    return 0;
}


int CMyAppScanCof::findScanLogWnd()
{
    int iRet = 0;
    // ����ɨ����־����
    HWND h = GetDesktopWindow();
    m_hWndScanLog = FindWithObjectName(h, _T("ɨ����־ �� IBM Security AppScan Standard"), 0, false);
    if (NULL == m_hWndScanLog)
    {
        LOG(ERROR) << "��ȡɨ����־ʧ��!�޷���ȡɨ����־����." << endl;
        return -1;
    }

    if (NULL == m_hWndScanLog)
    {
        return  -1;
    }

    CComQIPtr<IAccessible, &IID_IAccessible> m_pAcc;
    HRESULT hr = AccessibleObjectFromWindow(m_hWndScanLog, OBJID_WINDOW, IID_IAccessible, (void**)&m_pAcc);
    if (S_OK != hr)
    {
        LOG(ERROR) << "��ȡscanlog ʧ��[" << GetLastError() << "]" << endl;
        return -2;
    }

    CComQIPtr<IAccessible> pChild;
    VARIANT variant;
    VariantInit(&variant);
    variant.vt = VT_I4;
    variant.lVal = CHILDID_SELF;
    IDispatch* pDisp = NULL;

    m_vecWndScanLog.clear();

    findTableCache(m_pAcc, "", "", "", &pChild, &variant, m_vecWndScanLog, 0);
    VariantClear(&variant);

    return iRet;
}

int CMyAppScanCof::findTableCache(IAccessible* paccParent, LPSTR szName, LPSTR szRole, LPSTR szClass,
    IAccessible** paccChild, VARIANT* pvarChild, std::vector<ST_WndDef*> &vecWndData, int depth)
{
    HRESULT hr;
    long numChildren;
    unsigned long numFetched;
    VARIANT varChild;
    int index;
    IAccessible* pCAcc = NULL;
    IEnumVARIANT* pEnum = NULL;
    IDispatch* pDisp = NULL;
    BOOL found = false;
    WCHAR szObjName[1024] = { 0 }, szObjRole[1024] = { 0 }, szObjClass[1024] = { 0 }, szObjState[1024] = { 0 }, szObjValue[1024] = { 0 };
    DWORD id = 0;
    //�õ�����֧�ֵ�IEnumVARIANT�ӿ�
    hr = paccParent->QueryInterface(IID_IEnumVARIANT, (PVOID*)& pEnum);

    if (pEnum)
        pEnum->Reset();

    //ȡ�ø���ӵ�еĿɷ��ʵ��ӵ���Ŀ
    paccParent->get_accChildCount(&numChildren);
    //�������Ƚ�ÿһ����ID���ҵ����֡���ɫ������������һ�µġ�
    for (index = 1; index <= numChildren && !found; index++)
    {
        bool bT = false;
        pCAcc = NULL;
        // ���֧��IEnumVARIANT�ӿڣ��õ���һ����ID
        //�Լ����Ӧ�� IDispatch �ӿ�
        if (pEnum)
            hr = pEnum->Next(1, &varChild, &numFetched);
        else
        {
            //���һ�����ײ�֧��IEnumVARIANT�ӿڣ���ID�����������
            varChild.vt = VT_I4;
            varChild.lVal = index;
        }

        // �ҵ�����ID��Ӧ�� IDispatch �ӿ�
        if (varChild.vt == VT_I4)
        {
            //ͨ����ID��ŵõ���Ӧ�� IDispatch �ӿ�
            pDisp = NULL;
            hr = paccParent->get_accChild(varChild, &pDisp);
        }
        else
            //�����֧��IEnumVARIANT�ӿڿ���ֱ�ӵõ���IDispatch �ӿ�
            pDisp = varChild.pdispVal;

        // ͨ�� IDispatch �ӿڵõ��ӵ� IAccessible �ӿ� pCAcc
        if (pDisp)
        {
            hr = pDisp->QueryInterface(IID_IAccessible, (void**)&pCAcc);
            hr = pDisp->Release();
        }
        if (pCAcc)
        {
            VariantInit(&varChild);
            varChild.vt = VT_I4;
            varChild.lVal = CHILDID_SELF;
            *paccChild = pCAcc;
        }
        else
        {
            //����Ӳ�֧��IAccessible �ӿ�
            *paccChild = paccParent;
            bT = true;
        }
        GetObjectRole(*paccChild, &varChild, id, szObjRole, sizeof(szObjRole));
        GetObjectClass(*paccChild, szObjClass, sizeof(szObjClass));
        GetObjectName(*paccChild, &varChild, szObjName, sizeof(szObjName));
        GetObjectValue(*paccChild, &varChild, szObjValue, sizeof(szObjValue));

        // ���ұ���
        if (NULL != wcsstr(szObjName, _T("DataGridView")) && id == 0x18)
        {
            // �������� 
            paccChild;
            // �˳�
            found = true;
            detcetTableRowCache(*paccChild);
        }

        CFile file;
        CString strFileName;
        strFileName = m_strWorkPath + _T("\\DetoursTest.txt");
        if ( file.Open( strFileName.GetBuffer() , CFile::modeWrite | CFile::modeCreate | CFile::modeNoTruncate) )
        {
            bool b = false;
            if (!b)
            {
                if (id == 0x1 || id == 0x2 || id == 0x3 || id == 0x4 || id == 0x0C || id == 0x16 || id == 0x2B
                    || id == 0x27 || id == 0x0C || id == 0x2B)
                {
                    b = true;
                }
            }
            if (!b)
            {
                if (id == 0x0a || id == 0x09 || id == 0x24 || id == 0x25 || id == 0x0a || id == 0x0a || id == 0x0a 
                    || NULL != wcsstr(szObjClass, _T("WindowsForms10.RichEdit20W.app")) )
                {
                    if (NULL != wcsstr(szObjClass, _T("WindowsForms10.RichEdit20W.app")))
                    {
                        int i = 0;
                    }
                    file.SeekToEnd();
                    for (int y = 0; y < depth; y++)
                    {
                        file.Write(_T("  "), 2);
                    }
                    file.Write(szObjName, wcslen(szObjName) * sizeof(WCHAR));
                    file.Write(_T(" | "), 3 * sizeof(WCHAR));
                    file.Write(szObjClass, wcslen(szObjClass) * sizeof(WCHAR));
                    file.Write(_T(" | "), 3 * sizeof(WCHAR));
                    file.Write(szObjRole, wcslen(szObjRole) * sizeof(WCHAR));
                    file.Write(_T(" | "), 3 * sizeof(WCHAR));
                    file.Write(szObjValue, wcslen(szObjValue) * sizeof(WCHAR));
                    file.Write(_T(" | "), 3 * sizeof(WCHAR));
                    CString strDep;
                    strDep.Format(_T("%d"), depth);
                    file.Write(strDep, strDep.GetLength() * sizeof(WCHAR));
                    file.Write(_T("\r\n"), 2);

                    ST_WndDef *def = new ST_WndDef();
                    def->dRole = id;
                    def->pIAcc = *paccChild;
                    def->iDepth = depth;
                    int len = wcslen(szObjClass) * sizeof(WCHAR);
                    wmemcpy(def->szClassName, szObjClass, len);
                    len = wcslen(szObjName) * sizeof(WCHAR);
                    wmemcpy(def->szObjName, szObjName, len > 512 ? 511 : len);
                    hr = WindowFromAccessibleObject(*paccChild, &(def->hwnd));

                    if (S_OK == hr)
                    {
                        // ��ʼ������
                        def->iState = 0;
                    }
                    vecWndData.push_back(def);
                    int iCount = m_vecWndData.size();
                    int t = 0;
                }
            }
            file.Close();
        }

        if (!found && pCAcc)
        {
            // ����εõ����ӽӿ�Ϊ���ݹ����
            found = findTableCache(pCAcc,szName,szRole,szClass,paccChild,pvarChild, vecWndData, depth + 1);
            if (*paccChild != pCAcc)
                pCAcc->Release();
        }
    }
    if (pEnum)
        pEnum->Release();

    return found;
}

int CMyAppScanCof::FindFileMenu(IAccessible* paccParent, LPSTR szName, LPSTR szRole, LPSTR szClass,
    IAccessible** paccChild, VARIANT* pvarChild, int depth)
{
    HRESULT hr;
    long numChildren;
    unsigned long numFetched;
    VARIANT varChild;
    int index;
    IAccessible* pCAcc = NULL;
    IEnumVARIANT* pEnum = NULL;
    IDispatch* pDisp = NULL;
    BOOL found = false;
    WCHAR szObjName[1024] = { 0 }, szObjRole[1024] = { 0 };
    DWORD id = 0;
    hr = paccParent->QueryInterface(IID_IEnumVARIANT, (PVOID*)& pEnum);

    if (pEnum)
        pEnum->Reset();
    paccParent->get_accChildCount(&numChildren);
    for (index = 1; index <= numChildren && !found; index++)
    {
        pCAcc = NULL;
        if (pEnum)
            hr = pEnum->Next(1, &varChild, &numFetched);
        else
        {
            varChild.vt = VT_I4;
            varChild.lVal = index;
        }

        if (varChild.vt == VT_I4)
        {
            pDisp = NULL;
            hr = paccParent->get_accChild(varChild, &pDisp);
        }
        else
            pDisp = varChild.pdispVal;

        if (pDisp)
        {
            hr = pDisp->QueryInterface(IID_IAccessible, (void**)&pCAcc);
            hr = pDisp->Release();
        }

        if (pCAcc)
        {
            VariantInit(&varChild);
            varChild.vt = VT_I4;
            varChild.lVal = CHILDID_SELF;
            *paccChild = pCAcc;
        }
        else
        {
            *paccChild = paccParent;
        }
        memset(szObjRole, 0x0, 1024);
        memset(szObjName, 0x0, 1024);
        GetObjectRole(*paccChild, &varChild, id, szObjRole, sizeof(szObjRole));
        GetObjectName(*paccChild, &varChild, szObjName, sizeof(szObjName));
        if (id == 0x2A)
        {
            if (0 == wcscmp(szObjName, _T("�ļ���(N):")) )
            {
                m_iDlgFileEdit = *paccChild;
                break;
            }
        }
        if (id == 0x2B)
        {
            if (0 == wcscmp(szObjName, _T("��(O)")))
            {
                m_iDlgFileOpen = *paccChild;
                break;
            }
        }

        if (!found && pCAcc)
        {
            // ����εõ����ӽӿ�Ϊ���ݹ����
            found = FindFileMenu(pCAcc, szName, szRole, szClass, paccChild, pvarChild, depth + 1);
            if (*paccChild != pCAcc)
                pCAcc->Release();
        }
    }

    if (pEnum)
        pEnum->Release();

    return found;
}

int CMyAppScanCof::getMenuOpenItem()
{
    int iRet = 0;

    // ���ҵ�������
    HWND h = ::FindWindow(_T("#32770"), _T("��"));
    if (NULL == h)
    {
        return -1;
    }
    // ���Ҷ�Ӧ��

    CComQIPtr<IAccessible, &IID_IAccessible> m_pAcc;
    IAccessible* pCAcc = NULL;
    HRESULT hr = AccessibleObjectFromWindow(h, OBJID_WINDOW, IID_IAccessible, (void**)&m_pAcc);

    CComQIPtr<IAccessible> pChild;
    VARIANT variant;
    VariantInit(&variant);
    variant.vt = VT_I4;
    variant.lVal = CHILDID_SELF;
    IDispatch* pDisp = NULL;
    
    FindFileMenu(m_pAcc, "", "", "", &pChild, &variant,0);
    return iRet;
}

int CMyAppScanCof::detcetTableRowCache(IAccessible* paccParent)
{
    int iRet = 0;
    HRESULT hr;
    long numChildren;
    unsigned long numFetched;
    VARIANT varChild;
    int index;
    IAccessible* pCAcc = NULL;
    IEnumVARIANT* pEnum = NULL;
    IDispatch* pDisp = NULL;
    BOOL found = false;
    DWORD id = 0;
    CComQIPtr<IAccessible> paccChild;

    //�õ�����֧�ֵ�IEnumVARIANT�ӿ�
    hr = paccParent->QueryInterface(IID_IEnumVARIANT, (PVOID*)& pEnum);

    if (pEnum)
        pEnum->Reset();
    paccParent->get_accChildCount(&numChildren);

    for (index = 1; index <= numChildren && !found; index++)
    {
        bool bT = false;
        pCAcc = NULL;
        if (pEnum)
            hr = pEnum->Next(1, &varChild, &numFetched);
        else
        {
            //���һ�����ײ�֧��IEnumVARIANT�ӿڣ���ID�����������
            varChild.vt = VT_I4;
            varChild.lVal = index;
        }

        if (varChild.vt == VT_I4)
        {
            pDisp = NULL;
            hr = paccParent->get_accChild(varChild, &pDisp);
        }
        else
            pDisp = varChild.pdispVal;

        if (pDisp)
        {
            hr = pDisp->QueryInterface(IID_IAccessible, (void**)&pCAcc);
            hr = pDisp->Release();
        }
        if (pCAcc)
        {
            VariantInit(&varChild);
            varChild.vt = VT_I4;
            varChild.lVal = CHILDID_SELF;
            paccChild = pCAcc;
        }
        else
        {
            pCAcc = paccParent;
            bT = true;
        }

        BSTR bstr;
        pCAcc->get_accValue(varChild, &bstr);
        // ����
        if ( wcscmp(_T("����"), bstr) == 0 )
        {
            long iChildCount = 0;
            pCAcc->get_accChildCount(&iChildCount);

            for (int i = 1; i <= iChildCount; i++)
            {
                VARIANT colChild;
                IDispatch* pcolDisp = NULL;
                IAccessible* pColCAcc = NULL;
                colChild.vt = VT_I4;
                colChild.lVal = i;
                
                hr = pCAcc->get_accChild(colChild, &pcolDisp);
                if (S_OK != hr)
                {
                    continue;
                }
                if (pcolDisp)
                {
                    hr = pcolDisp->QueryInterface(IID_IAccessible, (void**)&pColCAcc);
                    if (S_OK != hr)
                        continue;
                    if (pColCAcc)
                    {
                        BSTR bstr;
                        colChild.lVal = CHILDID_SELF;
                        pColCAcc->get_accName(colChild, &bstr);
                        OutputDebugString(bstr);
                        OutputDebugString(_T("  "));
                        m_vecTableTitle.push_back(bstr);
                    }
                    hr = pcolDisp->Release();
                }
            }
            OutputDebugString(_T("\r\n"));
            int i = 0;
        }
        else
        {
            m_vecTableLog.push_back(bstr);
        }
        OutputDebugString(bstr);
        OutputDebugString(_T("\r\n"));
        SysFreeString(bstr);
    }
    return iRet;
}

int CMyAppScanCof::findTabControl(HWND h)
{
    int iRet = 0;
    CComQIPtr<IAccessible, &IID_IAccessible> m_pAcc;
    HRESULT hr = AccessibleObjectFromWindow(h, OBJID_WINDOW, IID_IAccessible, (void**)&m_pAcc);
    if (S_OK != hr)
    {
        LOG(ERROR) << "��ȡSysTabControl32 ʧ��[" << GetLastError() << "]" << endl;
        return -2;
    }

    CComQIPtr<IAccessible> pChild;
    VARIANT variant;
    VariantInit(&variant);
    variant.vt = VT_I4;
    variant.lVal = CHILDID_SELF;
    IDispatch* pDisp = NULL;

    clearUp();
    FindChild(m_pAcc, "", "", "", &pChild, &variant, m_vecWndData, 0);

    VariantClear(&variant);
    return iRet;
}

int CMyAppScanCof::detectTabCache()
{
    std::string strData;
    m_vecTabChild.clear();
    // ��ȡ��Ӧ������ ���ר�Ŵ���AppScan tab��ǩ�ڵ�����
    std::vector<ST_WndDef*>::iterator it = m_vecWndData.begin();
    int icount = m_vecWndData.size();

    int iDepth = -1;
    int iIndex = 0;
    for (; it != m_vecWndData.end(); it++)
    {
        ST_WndDef* st = *it;
        if (wcscmp(st->szObjName, _T("����/��Ӧ")) == 0 && st->dRole == 0x0A)
        {
            iDepth = st->iDepth;
            break;
        }
    }
    // ��λ������
    if (it == m_vecWndData.end())
    {
        return 0;
    }

    Json::Value jsonTab;
    Json::Value jsonAarray;
    std::vector<ST_WndDef*> vecDef;
    it++;
    ST_WndDef* stC = *it;
    stC->iDepth;
    WCHAR *parentName;
    for (; it != m_vecWndData.end(); it++)
    {
        ST_WndDef* st = *it;
        if (st->iDepth <= iDepth)
        {
            break;
        }
        if (wcslen(st->szObjName) > 0 && wcsstr(st->szObjName, _T("<null>")) == NULL
            && st->dRole == 0x0A)
        {
            m_vecTabChild.push_back(st);
        }
        if (wcsstr(st->szClassName, _T("WindowsForms10.RichEdit20W.app")) >= 0 && st->dRole == 0x2A)
        {
            m_vecTabChild.push_back(st);
        }
    }

    std::string strFile;
    strFile = CPublic::getWorkPath() + "\\Data.txt";
    std::fstream file(strFile, std::ios::out | std::ios::app);
    if (!file.is_open())
    {
        return 0;
    }

    it = m_vecWndData.begin();
    for (; it != m_vecWndData.end(); it++)
    {
        ST_WndDef* st = *it;
        strData.clear();
        if (st->iState != 0)
        {
            continue;
        }
        // web ҳ��
        if (wcscmp(st->szClassName, _T("Internet Explorer_Server")) == 0)
        {
            getWebCache(st, strData);
            jsonAarray.append(st->jsonValue);
        }

    }

    Json::Value rq;
    Json::Value rqChild;
    it = m_vecTabChild.begin();
    for (; it != m_vecTabChild.end(); it++)
    {
        strData.clear();
        ST_WndDef* st = *it;
        if (wcsstr(st->szClassName, _T("WindowsForms10.RichEdit20W.app")) != NULL && st->dRole == 0x2A)
        {
            getRichEditCache(st, strData);
            vecDef.push_back(st);
        }
        else
        {
            getEditCache(st, strData);
            vecDef.push_back(st);
        }
        if (strData.length() > 0)
        {
            file << strData << endl;
        }
        rqChild.append(st->jsonValue);
    }
    rq["rq"] = rqChild;
    jsonAarray.append(rq);
    jsonTab["tab"] = jsonAarray;
    Json::FastWriter write;
    file << write.write(jsonTab) << endl;

    if (file.is_open())
    {
        file.close();
    }
    return 0;
}

int CMyAppScanCof::detectTableCache()
{
    int iRet = 0;

    std::string strFile;
    strFile = CPublic::getWorkPath() + "\\Data2.txt";
    std::fstream file(strFile, std::ios::out | std::ios::app);
    if (!file.is_open())
    {
        return 0;
    }

    // ��װ����
    int col = m_vecTableTitle.size();
    Json::Value jsonTable;
    std::vector<CString>::iterator it = m_vecTableLog.begin();
    for (; it != m_vecTableLog.end(); it++)
    {
        CString &str = *it;
        CStringArray array;
        int count = splitString(str, ';', array);
        if (count != col)
        {
            LOG(ERROR) << "��־��Ϣ����:" << *(array.GetData()) << endl;
            continue;
        }
        for (int j = 0; j < count; j++)
        {
            //OutputDebugString(array.GetAt(j));
            //OutputDebugString(_T("_"));
            file << CPublic::TCharToString(CString(array.GetAt(j))) << "    ";
        }
        //OutputDebugString(_T("\r\n"));
        file << endl;
    }

    return iRet;
}

int CMyAppScanCof::printWndTree(ST_Node* stNode)
{
    if (NULL == stNode)
    {
        return -1;
    }

    OutputDebugString(stNode->szCtrName);
    OutputDebugString(_T("\r\n"));
    for (int i = 0; i < stNode->child.size(); i++)
    {
        ST_Node* node = stNode->child[i];
        OutputDebugString(node->szCtrName);
        OutputDebugString(_T("&&"));
        if ( stNode[i].child.size() > 0 )
        {
            printWndTree(node);
        }
    }
    return 0;
}



////////////////////////////////////////

//
//HRESULT CNavigation::NavFirst()
//{
//    HRESULT hr = E_FAIL;
//    if (NULL == m_pCurAcc)
//        return hr;
//
//    ResetVarStart(m_varStart);
//
//    VARIANT varFirst;
//    VariantInit(&varFirst);
//    hr = m_pCurAcc->accNavigate(NAVDIR_FIRSTCHILD, m_varStart, &varFirst);
//
//    if (SUCCEEDED(hr) && varFirst.vt != VT_EMPTY)
//    {
//        IDispatch* pDisp = NULL;
//        if (VT_DISPATCH == varFirst.vt)
//        {
//            pDisp = varFirst.pdispVal;
//        }
//        else
//        {
//            hr = m_pCurAcc->get_accChild(varFirst, &pDisp);
//            m_varStart = varFirst;
//        }
//
//        IAccessible *paccChild = NULL;
//        if (pDisp)
//        {
//            hr = pDisp->QueryInterface(IID_IAccessible, (void**)&paccChild);
//            hr = pDisp->Release();
//        }
//
//        //////////////////////////////////////////////////////////////////////////
//        if (paccChild)
//        {
//            hr = m_pCurAcc->Release();
//            m_pCurAcc = paccChild;
//            varFirst.vt = VT_I4;
//            varFirst.lVal = CHILDID_SELF;
//        }
//
//        if (SUCCEEDED(hr) && m_pCurAcc)
//        {
//            hr = SetFocus(m_pCurAcc, &varFirst);
//
//            PlayTxt(m_pCurAcc, &varFirst);
//
//        }
//    }
//    VariantClear(&varFirst);
//
//    return hr;
//}

//HRESULT CNavigation::NavNext()
//{
//    HRESULT hr = E_FAIL;
//    if (NULL == m_pCurAcc)
//        return hr;
//
//    VARIANT varNext;
//    VariantInit(&varNext);
//    hr = m_pCurAcc->accNavigate(NAVDIR_NEXT, m_varStart, &varNext);
//
//    if (SUCCEEDED(hr) && varNext.vt != VT_EMPTY)
//    {
//        IDispatch* pDisp = NULL;
//        if (VT_DISPATCH == varNext.vt)
//        {
//            pDisp = varNext.pdispVal;
//        }
//        else if (VT_I4 == varNext.vt)
//        {
//            hr = m_pCurAcc->get_accChild(varNext, &pDisp);
//            m_varStart = varNext;
//        }
//
//        IAccessible *paccChild = NULL;
//        if (pDisp)
//        {
//            hr = pDisp->QueryInterface(IID_IAccessible, (void**)&paccChild);
//            hr = pDisp->Release();
//        }
//
//        //////////////////////////////////////////////////////////////////////////
//        if (paccChild)
//        {
//            hr = m_pCurAcc->Release();
//            m_pCurAcc = paccChild;
//            varNext.vt = VT_I4;
//            varNext.lVal = CHILDID_SELF;
//        }
//
//        if (SUCCEEDED(hr) && m_pCurAcc)
//        {
//            hr = SetFocus(m_pCurAcc, &varNext);
//
//            PlayTxt(m_pCurAcc, &varNext);
//        }
//    }
//    VariantClear(&varNext);
//
//    return hr;
//}
//
//HRESULT CNavigation::NavPrevious()
//{
//    HRESULT hr = E_FAIL;
//    if (NULL == m_pCurAcc)
//        return hr;
//
//    VARIANT varPre;
//    VariantInit(&varPre);
//    hr = m_pCurAcc->accNavigate(NAVDIR_PREVIOUS, m_varStart, &varPre);
//
//    if (SUCCEEDED(hr) && varPre.vt != VT_EMPTY)
//    {
//        IDispatch* pDisp = NULL;
//        if (VT_DISPATCH == varPre.vt)
//        {
//            pDisp = varPre.pdispVal;
//        }
//        else
//        {
//            hr = m_pCurAcc->get_accChild(varPre, &pDisp);
//            m_varStart = varPre;
//        }
//
//        IAccessible* paccChild = NULL;
//        if (pDisp)
//        {
//            hr = pDisp->QueryInterface(IID_IAccessible, (void**)&paccChild);
//            hr = pDisp->Release();
//        }
//
//        //////////////////////////////////////////////////////////////////////////
//        if (paccChild)
//        {
//            hr = m_pCurAcc->Release();
//            m_pCurAcc = paccChild;
//            varPre.vt = VT_I4;
//            varPre.lVal = CHILDID_SELF;
//        }
//
//        if (SUCCEEDED(hr) && m_pCurAcc)
//        {
//            hr = SetFocus(m_pCurAcc, &varPre);
//
//            PlayTxt(m_pCurAcc, &varPre);
//
//        }
//    }
//    VariantClear(&varPre);
//
//    return hr;
//}
//
//HRESULT CNavigation::NavParent()
//{
//    HRESULT hr = E_FAIL;
//    if (NULL == m_pCurAcc)
//        return hr;
//
//    IAccessible *paccChild = NULL;
//    if (VT_DISPATCH == m_varStart.vt || CHILDID_SELF == m_varStart.lVal)
//    {
//        IDispatch* pDisp = NULL;
//        hr = m_pCurAcc->get_accParent(&pDisp);
//        if (pDisp)
//        {
//            pDisp->QueryInterface(IID_IAccessible, (void**)&paccChild);
//        }
//        if (SUCCEEDED(hr) && paccChild)
//        {
//            m_pCurAcc->Release();
//            m_pCurAcc = paccChild;
//        }
//    }
//
//    ResetVarStart(m_varStart);
//    if (m_pCurAcc)
//    {
//        hr = SetFocus(m_pCurAcc, &m_varStart);
//
//        PlayTxt(m_pCurAcc, &m_varStart);
//    }
//
//    return hr;
//}


