#include "stdafx.h"
#include "MyHookCof.h"
#include "public/Public.h"
#include <TlHelp32.h>
#include <iostream>
#include <assert.h>
#include <atlimage.h >
#include "function.h"


CMyHookCof::CMyHookCof()
{
    TCHAR Path[MAX_PATH];
    GetModuleFileName(NULL, Path, MAX_PATH);//�õ�Ӧ�ó����ȫ·��   
    m_strExePath = Path;

    int lf = m_strExePath.ReverseFind(_T('\\'));
    int iIndex = m_strExePath.GetLength() - lf;
    m_strDllPath.Format(_T("%s\\hookdetours.dll"), m_strExePath.Left(lf  ) );
    m_strDllMsgPath.Format(_T("%s\\hookmessage.dll"), m_strExePath.Left(lf));

    m_iHookType = 0;

    m_bIsHook = false;
}

CMyHookCof::~CMyHookCof()
{

}

int CMyHookCof::hookAll()
{
    if (m_iHookType != 0)
    {
        LOG(ERROR) << "Ŀ���Ѿ���hook " << "type = " << m_iHookType << endl;
        return 0;
    }
    m_hInst = ::LoadLibrary(m_strDllPath);//����dll�ļ�  
    if (m_hInst == NULL)
    {
        DWORD d = GetLastError();
        LOG(ERROR) << "Load HookMessageBox.dll Failed:" << m_strDllPath << endl;
        return -1;
    }
    typedef BOOL(*StartHook)(HWND hWnd);//����ԭ�Ͷ���  
    StartHook Hook;
    Hook = (StartHook)::GetProcAddress(m_hInst, "StartHook");//��ȡ������ַ  
    if (Hook == NULL)
    {
        LOG(ERROR) << "GetFunction StartHook Failed: StartHook" << GetLastError() << endl;
        return  -1;
    }
    DWORD d = GetCurrentProcessId();
    HWND h = ::GetTopWindow(0);
    ::GetTopWindow(h);
    if ( !Hook(h) )//���ú���  
    {
        LOG(ERROR) << "hook ʧ��" << endl;
        return  -1;
    }

    m_bIsHook = true;
    m_iHookType = 2;
    LOG(ERROR) << "hook �ɹ�:" << m_iHookType << endl;
    return 0;
}

int CMyHookCof::hookSingle(CString &strProcessName)
{
    if (m_iHookType != 0 )
    {
        LOG(ERROR) << "��ǰ�Ѿ���ע����" << "type = " << m_iHookType << endl;
        return 0;
    }
    TCHAR Path[MAX_PATH];
    GetModuleFileName(NULL, Path, MAX_PATH);//�õ�Ӧ�ó����ȫ·��   
    m_strExePath = Path;

    std::string name = CPublic::TCharToString(strProcessName);
    std::string str = CPublic::TCharToString(m_strExePath);
    str = str.substr(0, str.find_last_of("\\"));
    char szPath[MAX_PATH] = { 0 };
    sprintf(szPath, "%s\\hookdetours.dll", str.c_str());
    int isInject = InjectDllToRemoteProcess(szPath, NULL, name.c_str() );
    if (isInject != 0)
    {
        LOG(ERROR) << "ע�뵽Զ�̽���ʧ��[" << isInject << "]" <<  endl;
        return false;
    }

    m_strDllMsgPath = szPath;
    m_bIsHook = true;
    m_iHookType = 1;
    return 0;
}

int CMyHookCof::unHookSigle()
{
    DWORD dwPid = m_dTargetPid;
    TCHAR* szDllName = NULL;
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, dwPid);
    MODULEENTRY32 me32;
    me32.dwSize = sizeof(me32);
    //����ƥ��Ľ�������  
    BOOL bRet = Module32First(hSnap, &me32);
    CString strDllNames = m_strDllName;
    while (bRet)
    {
        CString strExePath = me32.szExePath;
        if (strExePath.Compare(strDllNames) == 0)
        {
            break;
        }
        bRet = Module32Next(hSnap, &me32);
    }

    CloseHandle(hSnap);

    char *pFunName = "FreeLibrary";

    HANDLE hProcess = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwPid);

    if (hProcess == NULL)
    {
        return false;
    }

    FARPROC pFunAddr = GetProcAddress(GetModuleHandle(_T("kernel32.dll")), pFunName);
    HANDLE hThread = CreateRemoteThread(hProcess, NULL, 0, (LPTHREAD_START_ROUTINE)pFunAddr, me32.hModule, 0, NULL);
    WaitForSingleObject(hThread, INFINITE);
    CloseHandle(hThread);
    CloseHandle(hProcess);

    m_bIsHook = false;

    return true;
}

int CMyHookCof::unHook()
{
    if (m_iHookType != 0)
    {
        if (1 == m_iHookType)
        {
            this->unHookSigle();
        }
        else
            this->unHookAll();
    }
    if (m_bIsHook)
    {
        this->mouseUnHook();
    }
    m_iHookType = 0;
    return 0;
}

int CMyHookCof::unHookAll()
{
    if (0 == m_iHookType)
    {
        return 0;
    }
    int iRet = 0;
    if (m_hInst == NULL)
    {
        // δ��hook
        LOG(ERROR) << "dll ���Ϊ��,unhook ʧ��" << endl;
        return -1;
    }
    typedef VOID(WINAPI* StopHook)();//����ԭ�Ͷ���  
    StopHook UnHook;
    UnHook = (StopHook)::GetProcAddress(m_hInst, "StopHook");//��ȡ������ַ  
    if (UnHook == NULL)
    {
        LOG(ERROR) << "GetFunction StopHook Failed" << endl;
        FreeLibrary(m_hInst);
        m_hInst = NULL;
        return -1;
    }

    UnHook();//���ú���  
    FreeLibrary(m_hInst);
    m_hInst = NULL;

    m_iHookType = 0;
    return 0;
}


int CMyHookCof::mouseHook(CString &strProcessName)
{
    if (m_bIsHook)
    {
        return 0;
    }
    HWND h = GetXHandle(strProcessName);
    DWORD ProcessID;
    DWORD ThreadID;
    ThreadID = GetWindowThreadProcessId(h, &ProcessID);

    int iRet = 0;
    bool bHook = false; 
    m_hInst = ::LoadLibrary( m_strDllMsgPath );
    if (m_hInst == NULL)
    {
        DWORD d = GetLastError();
        LOG(ERROR) << "Load hookmessage.dll Failed[" << d << "]" << endl;
        return bHook;
    }
    LOG(ERROR) << "Load hookmessage.dll Succ " << endl;
    typedef BOOL(*StartHook)(DWORD type, UINT32 id);
    StartHook Hook;
    Hook = (StartHook)::GetProcAddress(m_hInst, "StartHook");
    if (Hook == NULL)
    {
        LOG(ERROR) << "GetFunction StartHook Failed![" << GetLastError() << "]" << endl;
        return bHook;
    }
    
    if ( Hook(WH_MOUSE, ThreadID) )//���ú���  
    {
        bHook = true;
    }

    typedef void(*SetMsgWnd)(HWND wnd);//����ԭ�Ͷ���  
    SetMsgWnd setWnd;
    setWnd = (SetMsgWnd)::GetProcAddress(m_hInst, "SetMsgWnd");
    if (NULL != setWnd)
    {
        HWND h = ::FindWindow(NULL, _T("hookUI"));
        if (NULL != h )
        {
            setWnd(h);
        }
        else
        {
            LOG(ERROR) << "find callback wnd failed![" << GetLastError() << "]" << endl;
            return 1;
        }
    }

    m_bIsHook = true;

    return iRet;
}

int CMyHookCof::mouseUnHook()
{
    int iRet = 0;
    if (!m_bIsHook)
    {
        LOG(INFO) << "�Ѿ�������ж��!" << endl;
        return 0;
    }
    if (m_hInst == NULL)
    {
        // δ��hook
        LOG(ERROR) << "dll ���Ϊ��,unhook ʧ��" << endl;
        return -1;
    }
    typedef VOID(WINAPI* StopHook)();//����ԭ�Ͷ���  
    StopHook UnHook;
    UnHook = (StopHook)::GetProcAddress(m_hInst, "StopHook");//��ȡ������ַ  
    if (UnHook == NULL)
    {
        LOG(ERROR) << "GetFunction StopHook Failed" << endl;
        FreeLibrary(m_hInst);
        m_hInst = NULL;
        return -1;
    }

    UnHook();//���ú���  
    FreeLibrary(m_hInst);
    m_hInst = NULL;
    m_bIsHook = false;
    return iRet;
}

// ���ô�������
int CMyHookCof::setProcess(HWND hwnd)
{
    int iRet = 0;
    m_hwndProcess = hwnd;
    return iRet;
}

BOOL CMyHookCof::setCallBack()
{
    HINSTANCE hInst = ::LoadLibrary(m_strDllMsgPath);//����dll�ļ�  
    if (hInst == NULL)
    {
        DWORD d = GetLastError();
        LOG(ERROR) << "load library failed![" << GetLastError() << "]" << endl;
        return false;
    }

    typedef void(*SetMsgWnd)(HWND wnd);//����ԭ�Ͷ���  
    SetMsgWnd setWnd;
    setWnd = (SetMsgWnd)::GetProcAddress(hInst, "SetMsgWnd");
    if (NULL != setWnd)
    {
        HWND h = ::FindWindow(NULL, _T("hookUI"));
        if (NULL != h)
        {
            setWnd(h);
        }
        else
        {
            LOG(ERROR) << "find callback wnd failed![" << GetLastError() << "]" << endl;
            return 1;
        }
    }
    ::FreeLibrary(hInst);
    hInst = NULL;
    return TRUE;
}

int CMyHookCof::InjectDllToRemoteProcess(const char* lpDllName, const char* lpPid, const char* lpProcName)
{
    DWORD dwPid = 0;
    string strProcName = lpProcName;
    CString strProcNameW = CPublic::stringToTChar(strProcName);
    if (NULL == lpPid || 0 == strlen(lpPid))
    {
        if (NULL != lpProcName && 0 != strlen(lpProcName))
        {
            if (!GetPidByProcessName(strProcNameW, dwPid))
            {
                LOG(ERROR) << "GetPidByProcessName failed![" << GetLastError() << "]" << endl;
                return 1;
            }
        }
        else
        {
            return 2;
        }
    }
    else
    {
        dwPid = atoi(lpPid);
    }

    m_dTargetPid = dwPid;

    string str = lpDllName;
    m_strDllName = CPublic::stringToTChar(str);
    //m_strDllName.Format(_T("%s"), lpDllName );
    //����Pid�õ����̾��(ע�����Ȩ��)
    HANDLE hRemoteProcess = OpenProcess(PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE, FALSE, dwPid);
    if (INVALID_HANDLE_VALUE == hRemoteProcess)
    {
        return 3;
    }

    //����DLL·������Ҫ���ڴ�ռ�
    DWORD dwSize = (1 + lstrlenA(lpDllName)) * sizeof(char);

    //ʹ��VirtualAllocEx������Զ�̽��̵��ڴ��ַ�ռ����DLL�ļ���������,�ɹ����ط����ڴ���׵�ַ.
    LPVOID lpRemoteBuff = (char *)VirtualAllocEx(hRemoteProcess, NULL, dwSize, MEM_COMMIT, PAGE_READWRITE);
    if (NULL == lpRemoteBuff)
    {
        CString str;
        str.Format(_T("��Զ�̽���ʧ��,%d, %d"), GetLastError(), dwSize);
        ::MessageBox(NULL, str, _T("error"), MB_OK);

        CloseHandle(hRemoteProcess);
        return 4;
    }

    //ʹ��WriteProcessMemory������DLL��·�������Ƶ�Զ�̽��̵��ڴ�ռ�,�ɹ�����TRUE.
    DWORD dwHasWrite = 0;
    BOOL bRet = WriteProcessMemory(hRemoteProcess, lpRemoteBuff, lpDllName, dwSize, &dwHasWrite);
    if (!bRet || dwHasWrite != dwSize)
    {
        VirtualFreeEx(hRemoteProcess, lpRemoteBuff, dwSize, MEM_COMMIT);
        CloseHandle(hRemoteProcess);
        return 5;
    }
    DWORD  dwRemoteThread = 0;
    HANDLE hRemoteThread = CreateRemoteThread(hRemoteProcess, NULL, 0, (LPTHREAD_START_ROUTINE)LoadLibraryA, lpRemoteBuff, 0, &dwRemoteThread);
    if (INVALID_HANDLE_VALUE == hRemoteThread)
    {
        VirtualFreeEx(hRemoteProcess, lpRemoteBuff, dwSize, MEM_COMMIT);
        CloseHandle(hRemoteProcess);
        return 6;
    }

    //ע��ɹ��ͷž��
    WaitForSingleObject(hRemoteThread, INFINITE);
    CloseHandle(hRemoteThread);
    CloseHandle(hRemoteProcess);

    return 0;
}

//���̿��գ�ö�ٸ����̣�
BOOL CMyHookCof::GetPidByProcessName(LPCTSTR lpszProcessName, DWORD &dwPid)
{
    HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (INVALID_HANDLE_VALUE == hSnapshot)
    {
        return FALSE;
    }

    PROCESSENTRY32 pe;
    pe.dwSize = sizeof(PROCESSENTRY32);
    if (!Process32First(hSnapshot, &pe))
    {
        ::CloseHandle(hSnapshot);
        return FALSE;
    }

    while (Process32Next(hSnapshot, &pe))
    {
        if (!lstrcmp(lpszProcessName, pe.szExeFile))
        {
            ::CloseHandle(hSnapshot);
            dwPid = pe.th32ProcessID;
            return TRUE;
        }
    }

    ::CloseHandle(hSnapshot);
    return FALSE;
}

