#pragma once

#include <afxinet.h>
#include <afxhtml.h>
#include <OleAcc.h>
#include <comdef.h>
#include <iostream>
#include <fstream>
#include <vector>
#include "json.h"

class CMyIjiamiHelper
{
public:
    CMyIjiamiHelper();
    ~CMyIjiamiHelper();

public:
    int init();
    int UserSend(WPARAM wParam, LPARAM lParam);
    int UserRecv(WPARAM wParam, LPARAM lParam);
    int UserDrawImg(WPARAM wParam, LPARAM lParam);
    int UserBitblt(WPARAM wParam, LPARAM lParam);
    int UserExtTextOut(WPARAM wParam, LPARAM lParam);

protected:
    // �����ڴ����
    int setShareMemory();
    int closeShareMemery();

    // �����ڴ�
    HANDLE m_hMapFile;
    LPCTSTR m_pShareBuf;
    BYTE* m_BitBuffer;
    unsigned char * m_dataDesc;
    unsigned char * m_dataSocket;

};

