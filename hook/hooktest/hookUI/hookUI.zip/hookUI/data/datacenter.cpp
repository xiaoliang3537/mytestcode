﻿#include "StdAfx.h"

#include "datacenter.h"


CDataCenter::CDataCenter(void)
{

}

CDataCenter::~CDataCenter(void)
{
}
