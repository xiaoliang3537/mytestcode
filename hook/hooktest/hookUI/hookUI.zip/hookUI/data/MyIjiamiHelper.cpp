#include "stdafx.h"
#include "MyIjiamiHelper.h"
#include "public/Public.h"
#include "public/function.h"

TCHAR szName[] = TEXT("Global\\MyFileMappingObject");                     //ָ��ͬһ�鹲���ڴ������  
TCHAR szNameBitMap[] = TEXT("Global\\MyFileMappingObjectBitMap");         //ָ��ͬһ�鹲���ڴ������  
TCHAR szNameDataDesc[] = TEXT("Global\\MyFileMappingDataDesc");           //��������  ����������Ϣ �豸��Ϣ����  
TCHAR szNameDataSocket[] = TEXT("Global\\MyFileMappingDataSocket");       //socket����  ����������Ϣ �豸��Ϣ����  

CMyIjiamiHelper::CMyIjiamiHelper()
{

}


CMyIjiamiHelper::~CMyIjiamiHelper()
{
    //this->closeShareMemery();
}

int CMyIjiamiHelper::init()
{
    this->setShareMemory();
    return 0;
}

int CMyIjiamiHelper::UserExtTextOut(WPARAM wParam, LPARAM lParam)
{
    int i = 0;
    DWORD iDescLen = (DWORD)lParam;
    int iCurrLen = (int)wParam;
    if (NULL == m_pShareBuf)
        return TRUE;

    // ��ȡ��������
    std::string strDesc = (char*)m_dataDesc;
    /*
        if (NULL == m_fTextOut)
        {
            char szFile[512] = { 0 };
            std::string str = CPublic::TCharToString(m_strExePath);
            str = str.substr(0, str.find_last_of("\\"));
            sprintf(szFile, "%s\\textout.log", str.c_str());
            m_fTextOut = fopen(szFile, "ab+");
            if (NULL == m_fTextOut)
            {
                return true;
            }
        }

        CString strData((LPCTSTR)m_pShareBuf);
        std::string sdata = CPublic::TCharToString(strData);
        char szDesc[128] = { 0 };
        sprintf(szDesc, "[%s]", m_dataDesc);
        fwrite(szDesc, strlen(szDesc), 1, m_fTextOut);

        fwrite(sdata.c_str(), sdata.length(), 1, m_fTextOut);
        fwrite("\r\n", 2, 1, m_fTextOut);
        fflush(m_fTextOut);*/

    //std::string strDelim = ",";
    //std::vector<int> vecRect = split(strDesc, strDelim);

    //if (NULL != m_myTestDialog && vecRect.size() == 11 )
    //{
    //    HWND hwnd = FindMainWindow(m_dTargetPid);
    //    ::GetWindowRect(hwnd, &m_injectRect);

    //    ST_ImgInfo img;
    //    img.rectImg.X = vecRect[0];
    //    img.rectImg.Y = vecRect[1];
    //    img.rectImg.Width = 100;
    //    img.rectImg.Height = 33;

    //    Gdiplus::RectF rect;
    //    rect.X = vecRect[6];
    //    rect.Y = vecRect[7];
    //    rect.Width = vecRect[8] - rect.X ;
    //    rect.Height = vecRect[9] - rect.Y;

    //    img.rectReal.X = rect.X - m_injectRect.left + vecRect[0];
    //    img.rectReal.Y = rect.Y - m_injectRect.top + vecRect[1];
    //    img.rectReal.Width = img.rectImg.Width;
    //    img.rectReal.Height = img.rectImg.Height;

    //    int id = vecRect[10];
    //    img.strInfo = m_pShareBuf;
    //    img.wnd = getWnd(id);
    //    CMyTestDialog *dlg = (CMyTestDialog*)(img.wnd);
    //    dlg->updateString(img);
    //    //m_myTestDialog->updateString(img);

    //    // ͳһ���ݸ߶�
    //    //if (id == 1009 || id = 2000 + 1009)
    //    //{
    //    //    int x = img.rectImg.X;
    //    //    int y = img.rectImg.Y - 9 = 0;
    //    //}

    //}

    //std::string stdStr = (char*)m_dataDesc;
    //CString str;
    //str.Format(_T("t_%s[%s]\n"), CPublic::stringToTChar(stdStr), m_pShareBuf);
    //OutputDebugString(str);

    return TRUE;
}

int CMyIjiamiHelper::UserBitblt(WPARAM wParam, LPARAM lParam)
{
    int i = 0;
    DWORD iTrs = (DWORD)wParam;
    DWORD m = (DWORD)lParam;
    int len = (int)wParam;
    if (NULL == m_BitBuffer)
        return TRUE;

    // ��ȡλͼ����
    HGLOBAL mem = GlobalAlloc(GHND, len);
    HRESULT hr;
    IStream* stream = 0;
    hr = CreateStreamOnHGlobal(mem, TRUE, &stream);
    stream->Write(m_BitBuffer, len, NULL);

    // ��ȡ��������
    std::string strDesc = (char*)m_dataDesc;
    std::string strDelim = ",";
    std::vector<int> vecRect = split(strDesc, strDelim);

    std::vector<int>::iterator it = vecRect.begin();

    char szFile[512] = { 0 };
    TCHAR Path[MAX_PATH];

    GetModuleFileName(NULL, Path, MAX_PATH);//�õ�Ӧ�ó����ȫ·��   
    CString m_strExePath = Path;

    std::string str = CPublic::TCharToString(m_strExePath);
    str = str.substr(0, str.find_last_of("\\"));

    CString strFile;
    strFile.Format(_T("%s\\temp\\b_%d_%d_%d_%d_%d_%d_%d_%d_%d_%d.png"), CPublic::stringToTChar(str), vecRect[0], vecRect[1], vecRect[2], vecRect[3], vecRect[4], vecRect[5],
        vecRect[6], vecRect[7], vecRect[8], vecRect[9]);
    FILE* fp = 0;
    errno_t err = _wfopen_s(&fp, strFile, L"wb");
    assert(err == 0 && fp != 0);
    fwrite(m_BitBuffer, 1, len, fp);
    fclose(fp);
    //
    //if (NULL != m_myTestDialog)
    //{
    //    HWND hwnd = FindMainWindow(m_dTargetPid);
    //    ::GetWindowRect(hwnd, &m_injectRect);

    //    ST_ImgInfo img;

    //    img.rectImg.X = vecRect[4];
    //    img.rectImg.Y = vecRect[5];
    //    img.rectImg.Width = vecRect[2];
    //    img.rectImg.Height = vecRect[3];

    //    Gdiplus::RectF rect;
    //    rect.X = vecRect[6];
    //    rect.Y = vecRect[7];
    //    rect.Width = vecRect[8] - rect.X ;
    //    rect.Height = vecRect[9] - rect.Y;
    //    
    //    img.rectReal.X = vecRect[0];
    //    img.rectReal.Y = vecRect[1];
    //    img.rectReal.Width = vecRect[2];
    //    img.rectReal.Height = vecRect[3];

    //    img.stream = stream;
    //    int id = vecRect[10];
    //    img.wnd = getWnd(id);

    //    CMyTestDialog *dlg = (CMyTestDialog*)(img.wnd);
    //    dlg->updateImg(img);

    //    if (id == 1009+2000 || id == 1009)
    //    {
    //        CImage image;
    //        image.Load(stream);
    //        CString strFile;
    //        strFile.Format(_T("E:\\code\\vs_test\\testhook\\Debug\\temp\\%d_%d.png"), vecRect[0],vecRect[1]);
    //        saveBitmapToFile(strFile, image, img.rectReal,img.rectImg);
    //    }

    //    //m_myTestDialog->updateImg(img);

    //    //CString str;
    //    //str.Format(_T("b_%d\n"), id);
    //    //OutputDebugString(str);
    //}

    //CString str;
    //std::string stdStr = (char*)m_dataDesc;
    //str.Format(_T("b_%s\n"), stringToTChar(stdStr));
    //OutputDebugString(str);

    return TRUE;
}

int CMyIjiamiHelper::UserDrawImg(WPARAM wParam, LPARAM lParam)
{
    int i = 0;
    DWORD iTrs = (DWORD)wParam;
    DWORD m = (DWORD)lParam;
    int len = (int)wParam;
    if (NULL == m_BitBuffer || NULL == m_dataDesc)
        return TRUE;

    if (len == 0 || m == 0)
        return TRUE;
    // ��ȡλͼ����
    HGLOBAL mem = GlobalAlloc(GHND, len);
    HRESULT hr;
    IStream* stream = 0;
    hr = CreateStreamOnHGlobal(mem, TRUE, &stream);
    stream->Write(m_BitBuffer, len, NULL);


    // ��ȡ��������
    std::string strDesc = (char*)m_dataDesc;
    std::string strDelim = ",";
    std::vector<int> vecRect = split(strDesc, strDelim);
    std::vector<int>::iterator it = vecRect.begin();
    CString str;
    vecRect[0];
    str.Format(_T("E:\\code\\vs_test\\testhook\\Debug\\temp\\%d_%d_%d_%d_%d_%d_%d_%d_%d_%d_%d_%d.png"), vecRect[0], vecRect[1], vecRect[2], vecRect[3],
        vecRect[4], vecRect[5], vecRect[6], vecRect[7], vecRect[8], vecRect[9], vecRect[10], vecRect[11]);
    FILE* fp = 0;
    errno_t err = _wfopen_s(&fp, str, L"wb");
    assert(err == 0 && fp != 0);
    fwrite(m_BitBuffer, 1, len, fp);
    fclose(fp);


    //CImage img;
    //img.Load(stream);
    //if (img.GetBits() != 0x0)
    //{
    //    m_hBmp =img.Detach();
    //}
    //m_hBmp =(HBITMAP)img.operator HBITMAP();


    //m_pImageD = Gdiplus::Image::FromStream(stream);

    //Invalidate(true);
    //ST_ImgInfo img;
    //img.stream = stream;
    //m_myTestDialog->updateImg(img);

    return TRUE;
}

int CMyIjiamiHelper::UserRecv(WPARAM wParam, LPARAM lParam)
{
    int i = 0;
    int iCurrLen = (int)wParam;
    int iSocket = (int)lParam;

    if (NULL == m_dataSocket)
        return TRUE;

    // ���� http�ַ���

    //CString str;
    //str.Format(_T("recv_%s\r\n"), CPublic::stringToTChar(ch));
    //OutputDebugString(str);

    bool bWrite = false;
    char* ch = (char*)m_dataSocket;
    int iStart = 0;                         // ��ʼλ��
    int iLen = 0;                           // �ַ�������

    //if (NULL == m_fTextOut)
    //{
    //    char szFile[512] = { 0 };
    //    std::string str = CPublic::TCharToString(m_strExePath);
    //    str = str.substr(0, str.find_last_of("\\"));
    //    sprintf(szFile, "%s\\textout.log", str.c_str());
    //    m_fTextOut = fopen(szFile, "ab+");
    //    if (NULL == m_fTextOut)
    //    {
    //        return true;
    //    }
    //}

    //CString strData((LPCTSTR)m_pShareBuf);
    //std::string sdata = CPublic::TCharToString(strData);
    //fwrite(ch, iCurrLen, 1, m_fTextOut);
    //fwrite("\r\n", 2, 1, m_fTextOut);
    //fflush(m_fTextOut);


    //do 
    //{
    //    if(ch == NULL || strlen(ch) <= 0)
    //    {
    //        break;
    //    }

    //    // ���ҽ�����־
    //    char * pszFind = strstr(ch,"\r\n\r\n"); 
    //    char* iIndexEnd = NULL;
    //    char *iIndexStart = NULL;
    //    
    //    if (pszFind != NULL )
    //    {
    //        iIndexEnd = strstr(pszFind,"]");
    //        iIndexStart = strstr(pszFind,"[");

    //        if (NULL != iIndexEnd)          // ����
    //        {
    //            iStart = pszFind - ch;
    //            if (NULL != iIndexStart)
    //            {
    //                iStart = +1;
    //            }
    //            char *p = ch+iStart;
    //            iLen = iCurrLen - (pszFind - ch) - 1;
    //            bWrite = true;
    //            memcpy((void*)(g_recvData + g_recvLen), (void*)(ch+iStart), iLen );
    //            g_recvLen += iLen;
    //        }
    //        else
    //        {
    //            iStart = pszFind - ch;
    //            if (NULL != iIndexStart)
    //            {
    //                iStart = +1;
    //            }
    //            char *p = ch+iStart;
    //            iLen = iCurrLen - (pszFind - ch) - 1;
    //            bWrite = false;
    //            memcpy((void*)(g_recvData + g_recvLen), (void*)(ch+iStart), iLen );
    //            g_recvLen += iLen;
    //        }
    //    }
    //    else
    //    {
    //        iIndexEnd = strstr(ch,"]");
    //        iIndexStart = strstr(ch,"[");

    //        if (NULL != iIndexEnd)          // ����
    //        {
    //            iStart = 0;
    //            iLen = iCurrLen;
    //            bWrite = true;
    //            char *p = ch+iStart;

    //            memcpy((void*)(g_recvData + g_recvLen), (void*)(ch+iStart), iLen );
    //            g_recvLen += iLen;
    //        }
    //        else
    //        {
    //            iStart = 0;
    //            iLen = iCurrLen;
    //            bWrite = false;
    //            char *p = ch+iStart;
    //            memcpy((void*)(g_recvData + g_recvLen), (void*)(ch+iStart), iLen );
    //            g_recvLen += iLen;
    //        }
    //    }

    //if (NULL != iIndexEnd)                  // �����ַ���
    //{
    //    // ������ʼλ��
    //    memcpy((void*)g_recvData + g_recvLen, (void*)ch, g_recvLen );
    //    if (NULL == pszFind)
    //    {
    //        char *sStart = strstr(pszFind,"{");

    //        iStart = sStart - ch;
    //        iLen = iCurrLen - (sStart - ch) - 1;
    //    }
    //    else
    //    {
    //        
    //    }
    //}
    //else                                    // ������
    //{
    //    
    //}
    //
    //if(pszFind != NULL)
    //{

    //    if (NULL != iIndexEnd)
    //    {
    //        pszFind = strstr(pszFind,"{");
    //        if (NULL == pszFind)
    //        {
    //            break;
    //        }
    //        iStart = pszFind - ch;
    //        iLen = iCurrLen - (pszFind - ch) - 1;


    //    }
    //    else
    //    {
    //        memcpy((void*)g_recvData, (void*)ch, )
    //    }
    //}
    //else
    //{
    //    iStart = 0;
    //    iLen = iCurrLen - 1;
    //    
    //}

    //} while (0);

    //if (1)
    //{
    //    char szTemp[64] = {0};
    //    std::string str = CPublic::TCharToString(m_strExePath);
    //    str = str.substr(0,str.find_last_of("\\"));
    //    char szFile[512] = {0};
    //    sprintf(szFile, "%s\\temp.log", str.c_str());
    //    FILE *f = fopen(szFile, "ab+");
    //    if (NULL != f)
    //    {
    //        sprintf(szTemp, "%d<\r\n\r\n", iSocket);
    //        fwrite(szTemp,strlen(szTemp),1,f);

    //        fwrite(ch,iCurrLen,1,f);
    //        fwrite("\r\n",2,1,f);
    //    }
    //    if (iCurrLen == 0)
    //    {
    //        sprintf(szTemp, "%d>\r\n\r\n", iSocket);
    //        fwrite(szTemp,strlen(szTemp),1,f);
    //    }
    //    fclose(f);
    //}
    //if (iCurrLen == 0)
    //{
    //    processRecvData(iSocket);
    //}
    //else
    //{
    //    updateRecvData(iSocket, ch, iCurrLen);
    //}
    return TRUE;
}

int CMyIjiamiHelper::UserSend(WPARAM wParam, LPARAM lParam)
{
    int i = 0;
    int iCurrLen = (int)wParam;
    int iSocket = (int)lParam;
    if (NULL == m_dataSocket)
        return TRUE;

    char* ch = (char*)m_dataSocket;
    //CString str;
    //str.Format(_T("send_%s\r\n"), CPublic::stringToTChar(ch));
    //OutputDebugString(str);

    //if (NULL == m_fTextOut)
    //{
    //    char szFile[512] = { 0 };
    //    std::string str = CPublic::TCharToString(m_strExePath);
    //    str = str.substr(0, str.find_last_of("\\"));
    //    sprintf(szFile, "%s\\textout.log", str.c_str());
    //    m_fTextOut = fopen(szFile, "ab+");
    //    if (NULL == m_fTextOut)
    //    {
    //        return true;
    //    }
    //}

    ////CString strData((LPCTSTR)m_dataSocket);
    ////std::string sdata = CPublic::TCharToString(strData);
    //fwrite(ch, iCurrLen, 1, m_fTextOut);
    //fwrite("\r\n", 2, 1, m_fTextOut);
    //fflush(m_fTextOut);


    return TRUE;
}



int CMyIjiamiHelper::setShareMemory()
{
    // ���ݹ����ڴ�
    HANDLE hMapFile;
    hMapFile = CreateFileMapping(
        INVALID_HANDLE_VALUE,    // use paging file  
        NULL,                    // default security  
        PAGE_READWRITE,          // read/write access  
        0,                       // maximum object size (high-order DWORD)  
        BUF_SIZE,                // maximum object size (low-order DWORD)  
        szName);                 // name of mapping object  

    if (hMapFile == NULL)
    {
        _tprintf(TEXT("Could not create file mapping object (%d).\n"),
            GetLastError());
        return 1;
    }
    m_pShareBuf = (LPTSTR)MapViewOfFile(hMapFile,   // handle to map object  
        FILE_MAP_ALL_ACCESS, // read/write permission  
        0,
        0,
        BUF_SIZE);

    if (m_pShareBuf == NULL)
    {
        _tprintf(TEXT("Could not map view of file (%d).\n"),
            GetLastError());
        CloseHandle(hMapFile);
        return 1;
    }

    // λͼ�����ڴ�
    HANDLE hMapBit;
    hMapBit = CreateFileMapping(
        INVALID_HANDLE_VALUE,    // use paging file  
        NULL,                    // default security  
        PAGE_READWRITE,          // read/write access  
        0,                       // maximum object size (high-order DWORD)  
        1024 * 1024,                // maximum object size (low-order DWORD)  
        szNameBitMap);                 // name of mapping object  

    if (hMapBit == NULL)
    {
        _tprintf(TEXT("Could not create file mapping object (%d).\n"),
            GetLastError());
        return 1;
    }
    m_BitBuffer = (BYTE*)MapViewOfFile(hMapBit,   // handle to map object  
        FILE_MAP_ALL_ACCESS, // read/write permission  
        0,
        0,
        1024 * 1024);

    if (m_BitBuffer == NULL)
    {
        _tprintf(TEXT("Could not map view of file (%d).\n"),
            GetLastError());
        CloseHandle(hMapBit);
        return 1;
    }

    // ������Ϣ
    HANDLE hMapDesc;
    hMapDesc = CreateFileMapping(
        INVALID_HANDLE_VALUE,    // use paging file  
        NULL,                    // default security  
        PAGE_READWRITE,          // read/write access  
        0,                       // maximum object size (high-order DWORD)  
        512,                // maximum object size (low-order DWORD)  
        szNameDataDesc);                 // name of mapping object  

    if (hMapDesc == NULL)
    {
        _tprintf(TEXT("Could not create file mapping object (%d).\n"),
            GetLastError());
        return 1;
    }
    m_dataDesc = (BYTE*)MapViewOfFile(hMapDesc,   // handle to map object  
        FILE_MAP_ALL_ACCESS, // read/write permission  
        0,
        0,
        512);

    if (m_dataDesc == NULL)
    {
        _tprintf(TEXT("Could not map view of file (%d).\n"),
            GetLastError());
        CloseHandle(hMapDesc);
        return 1;
    }

    // socket ��������
    HANDLE hMapSocket;
    hMapSocket = CreateFileMapping(
        INVALID_HANDLE_VALUE,    // use paging file  
        NULL,                    // default security  
        PAGE_READWRITE,          // read/write access  
        0,                       // maximum object size (high-order DWORD)  
        BUF_SOCKET,                // maximum object size (low-order DWORD)  
        szNameDataSocket);                 // name of mapping object  

    if (hMapSocket == NULL)
    {
        _tprintf(TEXT("Could not create file mapping object (%d).\n"),
            GetLastError());
        return 1;
    }
    m_dataSocket = (BYTE*)MapViewOfFile(hMapSocket,   // handle to map object  
        FILE_MAP_ALL_ACCESS, // read/write permission  
        0,
        0,
        BUF_SOCKET);

    if (m_dataSocket == NULL)
    {
        _tprintf(TEXT("Could not map view of file (%d).\n"),
            GetLastError());
        CloseHandle(hMapSocket);
        return 1;
    }

    return 0;
}

int CMyIjiamiHelper::closeShareMemery()
{
    if (NULL != m_pShareBuf)
        UnmapViewOfFile(m_pShareBuf);
    if (NULL != m_hMapFile)
        CloseHandle(m_hMapFile);
    return 0;
}
