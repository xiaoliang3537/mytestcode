#include "stdafx.h"
#include "loger.h"
#include <iostream>
#include "public/Public.h"
#include "Public.h"
#include "function.h"

#define MAX_LEN 4096

#ifdef I_OS_WINDOWS
#define FILE_NAME(x) strrchr(x,'\\')?strrchr(x,'\\')+1:x
#else
#define FILE_NAME(x) strrchr(x,'/')?strrchr(x,'/')+1:x
#endif

extern int g_outinfo;



bool checkIsParam(char* info)
{
    if (NULL == info)
        return false;

    if (1 >= strlen(info))
    {
        return false;
    }

    if (info[0] == '-')
    {
        return true;
    }
    return false;
}

const char* tr(const char* p, std::string &str)
{
    str = p;
    str = KS_UTF8_to_ANSI(p);
    return str.c_str();

}

const char* tr(unsigned long p, std::string &str)
{
    char sz[64] = { 0 };
    sprintf(sz, "%ld", p);
    str = sz;
    return sz;
}

const char* tr(CString &p, std::string &str)
{
    str = TCHAR2char( p.GetBuffer() ) ;
    return str.c_str();
}


char* QXUtf82Unicode(const char* utf, size_t *unicode_number)
{
    if (!utf || !strlen(utf))
    {
        *unicode_number = 0;
        return NULL;
    }
    int dwUnicodeLen = MultiByteToWideChar(CP_UTF8, 0, utf, -1, NULL, 0);
    size_t num = dwUnicodeLen * sizeof(wchar_t);
    wchar_t *pwText = (wchar_t*)malloc(num);
    memset(pwText, 0, num);
    MultiByteToWideChar(CP_UTF8, 0, utf, -1, pwText, dwUnicodeLen);
    *unicode_number = dwUnicodeLen - 1;
    return (char*)pwText;
}

char* QXUnicode2Utf8(const char* unicode)
{
    int len;
    len = WideCharToMultiByte(CP_UTF8, 0, (const wchar_t*)unicode, -1, NULL, 0, NULL, NULL);
    char *szUtf8 = (char*)malloc(len + 1);
    memset(szUtf8, 0, len + 1);
    WideCharToMultiByte(CP_UTF8, 0, (const wchar_t*)unicode, -1, szUtf8, len, NULL, NULL);
    return szUtf8;
}

std::string KS_ANSI_to_UTF8(const char* szAnsi)
{
    if (szAnsi == NULL)
        return NULL;

    _bstr_t   bstrTmp(szAnsi);
    int  nLen = ::WideCharToMultiByte(CP_UTF8, 0, (LPCWSTR)bstrTmp, -1, NULL, 0, NULL, NULL);
    char * pUTF8 = new char[nLen + 1];
    ZeroMemory(pUTF8, nLen + 1);
    ::WideCharToMultiByte(CP_UTF8, 0, (LPCWSTR)bstrTmp, -1, pUTF8, nLen, NULL, NULL);
    std::string strUtf8 = pUTF8;
    delete[] pUTF8;
    return strUtf8;
}

std::string KS_UTF8_to_ANSI(const char* szUTF8)
{
    if (szUTF8 == NULL)
        return "";
    int     nLen = ::MultiByteToWideChar(CP_UTF8, 0, szUTF8, -1, NULL, 0);
    WCHAR   * pWstr = new WCHAR[nLen + 1];
    ZeroMemory(pWstr, sizeof(WCHAR) * (nLen + 1));
    ::MultiByteToWideChar(CP_UTF8, 0, szUTF8, -1, pWstr, nLen);
    std::string  strAnsi(_bstr_t((wchar_t*)pWstr));
    delete[] pWstr;
    return strAnsi;
}


loger::loger()
{
    g_pFile = NULL;
    p_str = NULL;
    p_str = new char[MAX_LEN];
    len = 0;
}


int loger::init()
{
    int iRet = 0;
    do
    {
        if(NULL != g_pFile)
            break;
#ifdef I_OS_WINDOWS
        SYSTEMTIME sy;
        memset(&sy,0,sizeof(sy));
        GetLocalTime(&sy);
        char szTemp[128];
        memset(szTemp, 0x0, sizeof(szTemp));
        sprintf(szTemp,"%04d-%02d-%02d.log",
            sy.wYear,sy.wMonth,sy.wDay,sy.wHour,sy.wMinute,sy.wSecond);
        g_strLogFile = CPublic::getWorkPath() + "\\"+ szTemp ;
        
        g_pFile = fopen(g_strLogFile.c_str(), "a");
        if (NULL == g_pFile)
        {
            // 日志文件打开错误
            std::string strError = g_strLogFile + ".error";
            FILE *f = fopen(strError.c_str(), "a");
            if (NULL != f )
            {
                fclose(f);
            }
            iRet = -1;
            break;
        }
#else
//        time_t tNow =time(NULL);
//        time_t tEnd = tNow + 1800;

        struct tm  *ptm;
        long ts;
        ts = time(NULL);
        ptm = localtime(&ts);
        char szTemp[128];
        memset(szTemp, 0x0, sizeof(szTemp));
        sprintf(szTemp,"%04d-%02d-%02d.log",
            ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday );
        g_strLogFile = CPubVar::GetInstance().getWorkPath() + _SYMBOL_PATH_ + "log" + _SYMBOL_PATH_ +szTemp;
        g_pFile = fopen(g_strLogFile.c_str(), "a");
        if (NULL == g_pFile)
        {
            // 日志文件打开错误
            //LOG(ERROR) << tr("file open error !") << endl;
            iRet = -1;
            break;
        }

#endif
    } while (0);
    return iRet;
}


loger& loger::operator<<(int value)
{
    char sz[32] = {0};
    sprintf(sz, "%d" , value);
    this->operator <<(sz);
    return *this;
}


loger& loger::operator<<(const char* value)
{
    int vlen = strlen(value);
    if(len + vlen < MAX_LEN )
    {
        sprintf(p_str+len, "%s", value );
        len += vlen;
    }
    else
    {
        output(p_str, len);
        memset(p_str, 0x0, MAX_LEN);
        sprintf(p_str+len, "%s", value );
        len += vlen;
    }

    return *this;
}

loger& loger::operator<<(std::string &value)
{
    if(len + value.length() < MAX_LEN )
    {
        sprintf(p_str+len, "%s", value.c_str() );
        len += value.length();
    }
    else
    {
        output(p_str, len);
        memset(p_str, 0x0, MAX_LEN);
        sprintf(p_str+len, "%s", value.c_str() );
        len += value.length();
    }
    return *this;
}

loger& loger::operator<<(std::string ( *ops)(const char* p) )
{
    //return *this->operator <<(ops(*p));
    return *this;
}

loger& loger::operator<<(std::ostream& ( *op)(std::ostream&))
{
    sprintf(p_str+len, "\r\n" );
    len += 1;
    output(p_str, len);
    return *this;
}


loger& loger::operator<<(CString &value)
{
    std::string str;
    tr(value, str);
    if (len + str.length() < MAX_LEN)
    {
        sprintf(p_str + len, "%s", str.c_str());
        len += str.length();
    }
    else
    {
        output(p_str, len);
        sprintf(p_str + len, "%s", str.c_str());
        len += str.length();
    }
    return *this;
}

loger& loger::out(int p, const char* file, int line)
{
    if(0 != len )
    {
        sprintf(p_str+len,
                "\r\n");
        output(p_str, len+1);
        memset(p_str, 0x0, MAX_LEN );
        len = 0;
    }
    if (p == ERROR)
    {
        sprintf(p_str, "[error %s %s %s %d] ", __DATE__, __TIME__, FILE_NAME(file), line);
    }
    else if(p == INFO)
    {
        sprintf(p_str, "[info %s %s %s %d] ", __DATE__, __TIME__, FILE_NAME(file), line);
    }
    else if(p == DEBUG)
    {
        sprintf(p_str, "[debug %s %s %s %d] ", __DATE__, __TIME__, FILE_NAME(file), line);
    }
    else if (p == WARING)
    {
        sprintf(p_str, "[waring %s %s %s %d] ", __DATE__, __TIME__, FILE_NAME(file), line);
    }

    len = strlen(p_str);
    return *this;
}

loger& loger::out(int p, const char* file, int line, const char* time)
{
    if (0 != len)
    {
        sprintf(p_str + len,
            "\r\n");
        output(p_str, len + 1);
        memset(p_str, 0x0, MAX_LEN);
        len = 0;
    }
    sprintf(p_str, "[%s %s %d] ", time, FILE_NAME(file), line);
    len = strlen(p_str);
    return *this;
}

int loger::output(const char* p, int len)
{
    int iRet = 0;
    do
    {
        if (0 > iRet )
        {
            return -1;
        }
        iRet = fwrite(p, sizeof(char), len, g_pFile);
        if (0 > iRet)
        {
            return -1;
        }
        fflush(g_pFile);
    } while (0);
    memset(p_str, 0x0, MAX_LEN);
    this->len = 0;
    return iRet;
}


