#ifndef LOGER_H
#define LOGER_H

#ifdef WIN32
# ifndef I_OS_WINDOWS
# define I_OS_WINDOWS
# endif
#elif unix
# ifndef I_OS_LINUX
# define I_OS_LINUX
# endif
#endif

#include <iostream>
#include <ostream>
#include <stdio.h>
#include <iosfwd>
#include "define.h"


#ifdef I_OS_WINDOWS
#include <Windows.h>
#else
#endif

#ifdef I_OS_WINDOWS
#define MTR_STR std::string
#else
#define MTR_STR std::string
#endif

using namespace std;

#define DEBUG           0
#define INFO            1
#define WARING          2
#define ERROR           3


class loger;
class _Elem;
class _Traits;


#ifdef I_OS_WINDOWS
typedef std::ostream& (__cdecl *op)(std::ostream&);
#else
typedef std::ostream& ( *op)(std::ostream&);
typedef std::string& ( *ops)(const char*);
#endif


// ���������Ƿ�Ϊ����
bool checkIsParam(char* info);
const char* tr(const char* p, std::string &str);
const char* tr(unsigned long p, std::string &str);
const char* tr(CString &p, std::string &str);
// windows �����ַ�ת��

char* QXUtf82Unicode(const char* utf, size_t *unicode_number);
char* QXUnicode2Utf8(const char* unicode);
std::string KS_ANSI_to_UTF8(const char* szAnsi);
std::string KS_UTF8_to_ANSI(const char* szUTF8);


class loger
{
public:
    loger() ;
    int init();
    loger& operator<<(int value);
    loger& operator<<(const char* value);
    loger& operator<<(std::string &value);
    loger& operator<<(std::string ( *ops)(const char*) );
    loger& operator<<(std::ostream& ( *op)(std::ostream&) );

    loger& operator<<(CString &value);

    loger& out(int p, const char* file, int line);
    loger& out(int p, const char* file, int line, const char* time);
private:
    int output(const char* p, int len);
private:
    FILE* g_pFile;
    string g_strLogFile;
    char* p_str;
    int len;
};

extern loger *g_loger;
#define LOG(p) g_loger->out(p, __FILE__, __LINE__ )

inline std::string& tr(const char* p)
{
    static std::string str;
    tr(p, str);
    return str;
}

inline std::string& tr(unsigned long p)
{
    static std::string str;
    tr(p, str);
    return str;
}

inline std::string& tr(CString p)
{
    static std::string str;
    tr(p, str);
    return str;
}

#endif // LOGER_H
